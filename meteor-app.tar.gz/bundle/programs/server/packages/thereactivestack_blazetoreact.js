(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var BlazeToReact;

var require = meteorInstall({"node_modules":{"meteor":{"thereactivestack:blazetoreact":{"lib":{"BlazeToReact.jsx":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// packages/thereactivestack_blazetoreact/lib/BlazeToReact.jsx                            //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
let checkNpmVersions;
module.watch(require("meteor/tmeasday:check-npm-versions"), {
  checkNpmVersions(v) {
    checkNpmVersions = v;
  }

}, 0);
checkNpmVersions({
  react: '15.x'
}, 'thereactivestack:blazetoreact');

if (Meteor.isServer) {
  BlazeToReact = require('./BlazeToReact-server.jsx').default;
} else {
  BlazeToReact = require('./BlazeToReact-client.jsx').default;
}

module.exportDefault(BlazeToReact);
////////////////////////////////////////////////////////////////////////////////////////////

},"BlazeToReact-client.jsx":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// packages/thereactivestack_blazetoreact/lib/BlazeToReact-client.jsx                     //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
module.export({
  default: () => BlazeToReact
});
let React;
module.watch(require("react"), {
  default(v) {
    React = v;
  }

}, 0);
let Blaze;
module.watch(require("meteor/blaze"), {
  Blaze(v) {
    Blaze = v;
  }

}, 1);

function BlazeToReact(name, options) {
  if (!options) {
    options = {};
  }

  if (!options.container) {
    options.container = React.createElement("span", null);
  }

  return React.createClass({
    shouldComponentUpdate() {
      // Blaze has the full control once started
      return false;
    },

    componentWillUnmount() {
      Blaze.remove(this.blazeView);
    },

    componentWillReceiveProps(props) {
      this.blazeView.dataVar.set(props);
    },

    render() {
      return React.cloneElement(options.container, {
        ref: function (el) {
          if (el && !this.blazeView) {
            this.blazeView = Blaze.renderWithData(global.Template[name], this.props, el);
          }
        }.bind(this)
      });
    }

  });
}

;
////////////////////////////////////////////////////////////////////////////////////////////

},"BlazeToReact-server.jsx":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// packages/thereactivestack_blazetoreact/lib/BlazeToReact-server.jsx                     //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
module.export({
  default: () => BlazeToReact
});
let React;
module.watch(require("react"), {
  default(v) {
    React = v;
  }

}, 0);
// Blaze templates are not loaded server-side, we cannot do server-rendering
// We make sure the render is the same as on the client initially
const DummyElement = React.createClass({
  displayName: "DummyElement",

  render() {
    return React.createElement("span", null);
  }

});

function BlazeToReact(name, options) {
  if (!options) {
    options = {};
  }

  if (!options.container) {
    options.container = React.createElement("span", null);
  }

  return React.createClass({
    render() {
      return options.container;
    }

  });
}

;
////////////////////////////////////////////////////////////////////////////////////////////

}}}}}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx"
  ]
});
var exports = require("./node_modules/meteor/thereactivestack:blazetoreact/lib/BlazeToReact.jsx");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['thereactivestack:blazetoreact'] = exports, {
  BlazeToReact: BlazeToReact
});

})();

//# sourceURL=meteor://💻app/packages/thereactivestack_blazetoreact.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvdGhlcmVhY3RpdmVzdGFjazpibGF6ZXRvcmVhY3QvbGliL0JsYXplVG9SZWFjdC5qc3giLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL3RoZXJlYWN0aXZlc3RhY2s6YmxhemV0b3JlYWN0L2xpYi9CbGF6ZVRvUmVhY3QtY2xpZW50LmpzeCIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvdGhlcmVhY3RpdmVzdGFjazpibGF6ZXRvcmVhY3QvbGliL0JsYXplVG9SZWFjdC1zZXJ2ZXIuanN4Il0sIm5hbWVzIjpbImNoZWNrTnBtVmVyc2lvbnMiLCJtb2R1bGUiLCJ3YXRjaCIsInJlcXVpcmUiLCJ2IiwicmVhY3QiLCJNZXRlb3IiLCJpc1NlcnZlciIsIkJsYXplVG9SZWFjdCIsImRlZmF1bHQiLCJleHBvcnREZWZhdWx0IiwiZXhwb3J0IiwiUmVhY3QiLCJCbGF6ZSIsIm5hbWUiLCJvcHRpb25zIiwiY29udGFpbmVyIiwiY3JlYXRlQ2xhc3MiLCJzaG91bGRDb21wb25lbnRVcGRhdGUiLCJjb21wb25lbnRXaWxsVW5tb3VudCIsInJlbW92ZSIsImJsYXplVmlldyIsImNvbXBvbmVudFdpbGxSZWNlaXZlUHJvcHMiLCJwcm9wcyIsImRhdGFWYXIiLCJzZXQiLCJyZW5kZXIiLCJjbG9uZUVsZW1lbnQiLCJyZWYiLCJlbCIsInJlbmRlcldpdGhEYXRhIiwiZ2xvYmFsIiwiVGVtcGxhdGUiLCJiaW5kIiwiRHVtbXlFbGVtZW50Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBSUEsZ0JBQUo7QUFBcUJDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxvQ0FBUixDQUFiLEVBQTJEO0FBQUNILG1CQUFpQkksQ0FBakIsRUFBbUI7QUFBQ0osdUJBQWlCSSxDQUFqQjtBQUFtQjs7QUFBeEMsQ0FBM0QsRUFBcUcsQ0FBckc7QUFFckJKLGlCQUFpQjtBQUNmSyxTQUFPO0FBRFEsQ0FBakIsRUFFRywrQkFGSDs7QUFJQSxJQUFJQyxPQUFPQyxRQUFYLEVBQXFCO0FBQ25CQyxpQkFBZUwsUUFBUSwyQkFBUixFQUFxQ00sT0FBcEQ7QUFDRCxDQUZELE1BRU87QUFDTEQsaUJBQWVMLFFBQVEsMkJBQVIsRUFBcUNNLE9BQXBEO0FBQ0Q7O0FBVkRSLE9BQU9TLGFBQVAsQ0FZZUYsWUFaZixFOzs7Ozs7Ozs7OztBQ0FBUCxPQUFPVSxNQUFQLENBQWM7QUFBQ0YsV0FBUSxNQUFJRDtBQUFiLENBQWQ7QUFBMEMsSUFBSUksS0FBSjtBQUFVWCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsT0FBUixDQUFiLEVBQThCO0FBQUNNLFVBQVFMLENBQVIsRUFBVTtBQUFDUSxZQUFNUixDQUFOO0FBQVE7O0FBQXBCLENBQTlCLEVBQW9ELENBQXBEO0FBQXVELElBQUlTLEtBQUo7QUFBVVosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDVSxRQUFNVCxDQUFOLEVBQVE7QUFBQ1MsWUFBTVQsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDs7QUFHdEcsU0FBU0ksWUFBVCxDQUFzQk0sSUFBdEIsRUFBNEJDLE9BQTVCLEVBQXFDO0FBQ2xELE1BQUksQ0FBQ0EsT0FBTCxFQUFjO0FBQ1pBLGNBQVUsRUFBVjtBQUNEOztBQUVELE1BQUksQ0FBQ0EsUUFBUUMsU0FBYixFQUF3QjtBQUN0QkQsWUFBUUMsU0FBUixHQUFvQixpQ0FBcEI7QUFDRDs7QUFFRCxTQUFPSixNQUFNSyxXQUFOLENBQWtCO0FBQ3ZCQyw0QkFBd0I7QUFDdEI7QUFDQSxhQUFPLEtBQVA7QUFDRCxLQUpzQjs7QUFNdkJDLDJCQUF1QjtBQUNyQk4sWUFBTU8sTUFBTixDQUFhLEtBQUtDLFNBQWxCO0FBQ0QsS0FSc0I7O0FBVXZCQyw4QkFBMEJDLEtBQTFCLEVBQWlDO0FBQy9CLFdBQUtGLFNBQUwsQ0FBZUcsT0FBZixDQUF1QkMsR0FBdkIsQ0FBMkJGLEtBQTNCO0FBQ0QsS0Fac0I7O0FBY3ZCRyxhQUFTO0FBQ1AsYUFBT2QsTUFBTWUsWUFBTixDQUFtQlosUUFBUUMsU0FBM0IsRUFBc0M7QUFDM0NZLGFBQUssVUFBU0MsRUFBVCxFQUFhO0FBQ2hCLGNBQUlBLE1BQU0sQ0FBQyxLQUFLUixTQUFoQixFQUEyQjtBQUN6QixpQkFBS0EsU0FBTCxHQUFpQlIsTUFBTWlCLGNBQU4sQ0FBcUJDLE9BQU9DLFFBQVAsQ0FBZ0JsQixJQUFoQixDQUFyQixFQUE0QyxLQUFLUyxLQUFqRCxFQUF3RE0sRUFBeEQsQ0FBakI7QUFDRDtBQUNGLFNBSkksQ0FJSEksSUFKRyxDQUlFLElBSkY7QUFEc0MsT0FBdEMsQ0FBUDtBQU9EOztBQXRCc0IsR0FBbEIsQ0FBUDtBQXdCRDs7QUFBQSxDOzs7Ozs7Ozs7OztBQ3BDRGhDLE9BQU9VLE1BQVAsQ0FBYztBQUFDRixXQUFRLE1BQUlEO0FBQWIsQ0FBZDtBQUEwQyxJQUFJSSxLQUFKO0FBQVVYLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxPQUFSLENBQWIsRUFBOEI7QUFBQ00sVUFBUUwsQ0FBUixFQUFVO0FBQUNRLFlBQU1SLENBQU47QUFBUTs7QUFBcEIsQ0FBOUIsRUFBb0QsQ0FBcEQ7QUFFcEQ7QUFDQTtBQUVBLE1BQU04QixlQUFldEIsTUFBTUssV0FBTixDQUFrQjtBQUFBOztBQUNyQ1MsV0FBUztBQUNQLFdBQU8saUNBQVA7QUFDRDs7QUFIb0MsQ0FBbEIsQ0FBckI7O0FBTWUsU0FBU2xCLFlBQVQsQ0FBc0JNLElBQXRCLEVBQTRCQyxPQUE1QixFQUFxQztBQUNsRCxNQUFJLENBQUNBLE9BQUwsRUFBYztBQUNaQSxjQUFVLEVBQVY7QUFDRDs7QUFFRCxNQUFJLENBQUNBLFFBQVFDLFNBQWIsRUFBd0I7QUFDdEJELFlBQVFDLFNBQVIsR0FBb0IsaUNBQXBCO0FBQ0Q7O0FBRUQsU0FBT0osTUFBTUssV0FBTixDQUFrQjtBQUN2QlMsYUFBUztBQUNQLGFBQU9YLFFBQVFDLFNBQWY7QUFDRDs7QUFIc0IsR0FBbEIsQ0FBUDtBQUtEOztBQUFBLEMiLCJmaWxlIjoiL3BhY2thZ2VzL3RoZXJlYWN0aXZlc3RhY2tfYmxhemV0b3JlYWN0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY2hlY2tOcG1WZXJzaW9ucyB9IGZyb20gJ21ldGVvci90bWVhc2RheTpjaGVjay1ucG0tdmVyc2lvbnMnO1xuXG5jaGVja05wbVZlcnNpb25zKHtcbiAgcmVhY3Q6ICcxNS54J1xufSwgJ3RoZXJlYWN0aXZlc3RhY2s6YmxhemV0b3JlYWN0Jyk7XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgQmxhemVUb1JlYWN0ID0gcmVxdWlyZSgnLi9CbGF6ZVRvUmVhY3Qtc2VydmVyLmpzeCcpLmRlZmF1bHQ7XG59IGVsc2Uge1xuICBCbGF6ZVRvUmVhY3QgPSByZXF1aXJlKCcuL0JsYXplVG9SZWFjdC1jbGllbnQuanN4JykuZGVmYXVsdDtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQmxhemVUb1JlYWN0O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEJsYXplIH0gZnJvbSAnbWV0ZW9yL2JsYXplJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQmxhemVUb1JlYWN0KG5hbWUsIG9wdGlvbnMpIHtcbiAgaWYgKCFvcHRpb25zKSB7XG4gICAgb3B0aW9ucyA9IHt9O1xuICB9XG5cbiAgaWYgKCFvcHRpb25zLmNvbnRhaW5lcikge1xuICAgIG9wdGlvbnMuY29udGFpbmVyID0gPHNwYW4gLz47XG4gIH1cblxuICByZXR1cm4gUmVhY3QuY3JlYXRlQ2xhc3Moe1xuICAgIHNob3VsZENvbXBvbmVudFVwZGF0ZSgpIHtcbiAgICAgIC8vIEJsYXplIGhhcyB0aGUgZnVsbCBjb250cm9sIG9uY2Ugc3RhcnRlZFxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0sXG5cbiAgICBjb21wb25lbnRXaWxsVW5tb3VudCgpIHtcbiAgICAgIEJsYXplLnJlbW92ZSh0aGlzLmJsYXplVmlldyk7XG4gICAgfSxcblxuICAgIGNvbXBvbmVudFdpbGxSZWNlaXZlUHJvcHMocHJvcHMpIHtcbiAgICAgIHRoaXMuYmxhemVWaWV3LmRhdGFWYXIuc2V0KHByb3BzKTtcbiAgICB9LFxuXG4gICAgcmVuZGVyKCkge1xuICAgICAgcmV0dXJuIFJlYWN0LmNsb25lRWxlbWVudChvcHRpb25zLmNvbnRhaW5lciwge1xuICAgICAgICByZWY6IGZ1bmN0aW9uKGVsKSB7XG4gICAgICAgICAgaWYgKGVsICYmICF0aGlzLmJsYXplVmlldykge1xuICAgICAgICAgICAgdGhpcy5ibGF6ZVZpZXcgPSBCbGF6ZS5yZW5kZXJXaXRoRGF0YShnbG9iYWwuVGVtcGxhdGVbbmFtZV0sIHRoaXMucHJvcHMsIGVsKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0uYmluZCh0aGlzKVxuICAgICAgfSk7XG4gICAgfVxuICB9KTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuXG4vLyBCbGF6ZSB0ZW1wbGF0ZXMgYXJlIG5vdCBsb2FkZWQgc2VydmVyLXNpZGUsIHdlIGNhbm5vdCBkbyBzZXJ2ZXItcmVuZGVyaW5nXG4vLyBXZSBtYWtlIHN1cmUgdGhlIHJlbmRlciBpcyB0aGUgc2FtZSBhcyBvbiB0aGUgY2xpZW50IGluaXRpYWxseVxuXG5jb25zdCBEdW1teUVsZW1lbnQgPSBSZWFjdC5jcmVhdGVDbGFzcyh7XG4gIHJlbmRlcigpIHtcbiAgICByZXR1cm4gPHNwYW4gLz47XG4gIH1cbn0pO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBCbGF6ZVRvUmVhY3QobmFtZSwgb3B0aW9ucykge1xuICBpZiAoIW9wdGlvbnMpIHtcbiAgICBvcHRpb25zID0ge307XG4gIH1cblxuICBpZiAoIW9wdGlvbnMuY29udGFpbmVyKSB7XG4gICAgb3B0aW9ucy5jb250YWluZXIgPSA8c3BhbiAvPjtcbiAgfVxuXG4gIHJldHVybiBSZWFjdC5jcmVhdGVDbGFzcyh7XG4gICAgcmVuZGVyKCkge1xuICAgICAgcmV0dXJuIG9wdGlvbnMuY29udGFpbmVyO1xuICAgIH1cbiAgfSk7XG59O1xuIl19
