(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var BlazeToReact = Package['thereactivestack:blazetoreact'].BlazeToReact;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var Accounts = Package['accounts-base'].Accounts;
var HTML = Package.htmljs.HTML;

var require = meteorInstall({"node_modules":{"meteor":{"okgrow:accounts-ui-react":{"accounts-ui-react.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/okgrow_accounts-ui-react/accounts-ui-react.js                                        //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
module.export({
  LoginButtons: () => LoginButtons
});
let BlazeToReact;
module.watch(require("meteor/thereactivestack:blazetoreact"), {
  default(v) {
    BlazeToReact = v;
  }

}, 0);
let React;
module.watch(require("react"), {
  default(v) {
    React = v;
  }

}, 1);
let Session;
module.watch(require("meteor/session"), {
  Session(v) {
    Session = v;
  }

}, 2);
let classNames;
module.watch(require("classnames"), {
  default(v) {
    classNames = v;
  }

}, 3);
let composeWithTracker;
module.watch(require("./composeWithTracker"), {
  default(v) {
    composeWithTracker = v;
  }

}, 4);

const composer = (props, onData) => {
  const {
    state,
    visible,
    hideLinks
  } = props; // Generate classnames that identify the props and the flow

  let className = '';
  className = classNames({
    'accounts-ui-react': true,
    visible,
    hideLinks,
    changePassword: Session.get('Meteor.loginButtons.inChangePasswordFlow')
  }); // If visible is set, keep the Session value as true

  if (visible && !Session.get('Meteor.loginButtons.dropdownVisible')) {
    Session.set('Meteor.loginButtons.dropdownVisible', true);
  } // Set a specific state based on props


  if (state === 'signUp') Session.set('Meteor.loginButtons.inSignupFlow', true);
  if (state === 'forgotPassword') Session.set('Meteor.loginButtons.inForgotPasswordFlow', true);
  onData(null, {
    className
  });
};

const LoginButtonsComponent = props => {
  const {
    className
  } = props;
  const BlazeLoginButtons = BlazeToReact('loginButtons');
  return React.createElement(
    "div",
    {
      className: className
    },
    React.createElement(BlazeLoginButtons, props)
  );
};

LoginButtonsComponent.propTypes = {
  className: React.PropTypes.string
};
const LoginButtons = composeWithTracker(composer)(LoginButtonsComponent);
///////////////////////////////////////////////////////////////////////////////////////////////////

},"composeWithTracker.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/okgrow_accounts-ui-react/composeWithTracker.js                                       //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
let Tracker;
module.watch(require("meteor/tracker"), {
  Tracker(v) {
    Tracker = v;
  }

}, 0);
let compose;
module.watch(require("react-komposer"), {
  compose(v) {
    compose = v;
  }

}, 1);

const getTrackerLoader = reactiveMapper => (props, onData, env) => {
  let trackerCleanup = null;
  const handler = Tracker.nonreactive(() => Tracker.autorun(() => {
    // assign the custom clean-up function.
    trackerCleanup = reactiveMapper(props, onData, env);
  }));
  return () => {
    if (typeof trackerCleanup === 'function') trackerCleanup();
    return handler.stop();
  };
};

const composeWithTracker = data => compose(getTrackerLoader(data));

module.exportDefault(composeWithTracker);
///////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
var exports = require("./node_modules/meteor/okgrow:accounts-ui-react/accounts-ui-react.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['okgrow:accounts-ui-react'] = exports;

})();

//# sourceURL=meteor://💻app/packages/okgrow_accounts-ui-react.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2tncm93OmFjY291bnRzLXVpLXJlYWN0L2FjY291bnRzLXVpLXJlYWN0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9va2dyb3c6YWNjb3VudHMtdWktcmVhY3QvY29tcG9zZVdpdGhUcmFja2VyLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydCIsIkxvZ2luQnV0dG9ucyIsIkJsYXplVG9SZWFjdCIsIndhdGNoIiwicmVxdWlyZSIsImRlZmF1bHQiLCJ2IiwiUmVhY3QiLCJTZXNzaW9uIiwiY2xhc3NOYW1lcyIsImNvbXBvc2VXaXRoVHJhY2tlciIsImNvbXBvc2VyIiwicHJvcHMiLCJvbkRhdGEiLCJzdGF0ZSIsInZpc2libGUiLCJoaWRlTGlua3MiLCJjbGFzc05hbWUiLCJjaGFuZ2VQYXNzd29yZCIsImdldCIsInNldCIsIkxvZ2luQnV0dG9uc0NvbXBvbmVudCIsIkJsYXplTG9naW5CdXR0b25zIiwicHJvcFR5cGVzIiwiUHJvcFR5cGVzIiwic3RyaW5nIiwiVHJhY2tlciIsImNvbXBvc2UiLCJnZXRUcmFja2VyTG9hZGVyIiwicmVhY3RpdmVNYXBwZXIiLCJlbnYiLCJ0cmFja2VyQ2xlYW51cCIsImhhbmRsZXIiLCJub25yZWFjdGl2ZSIsImF1dG9ydW4iLCJzdG9wIiwiZGF0YSIsImV4cG9ydERlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLE9BQU9DLE1BQVAsQ0FBYztBQUFDQyxnQkFBYSxNQUFJQTtBQUFsQixDQUFkO0FBQStDLElBQUlDLFlBQUo7QUFBaUJILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxzQ0FBUixDQUFiLEVBQTZEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDSixtQkFBYUksQ0FBYjtBQUFlOztBQUEzQixDQUE3RCxFQUEwRixDQUExRjtBQUE2RixJQUFJQyxLQUFKO0FBQVVSLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxPQUFSLENBQWIsRUFBOEI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNDLFlBQU1ELENBQU47QUFBUTs7QUFBcEIsQ0FBOUIsRUFBb0QsQ0FBcEQ7QUFBdUQsSUFBSUUsT0FBSjtBQUFZVCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZ0JBQVIsQ0FBYixFQUF1QztBQUFDSSxVQUFRRixDQUFSLEVBQVU7QUFBQ0UsY0FBUUYsQ0FBUjtBQUFVOztBQUF0QixDQUF2QyxFQUErRCxDQUEvRDtBQUFrRSxJQUFJRyxVQUFKO0FBQWVWLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxZQUFSLENBQWIsRUFBbUM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNHLGlCQUFXSCxDQUFYO0FBQWE7O0FBQXpCLENBQW5DLEVBQThELENBQTlEO0FBQWlFLElBQUlJLGtCQUFKO0FBQXVCWCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsc0JBQVIsQ0FBYixFQUE2QztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ0kseUJBQW1CSixDQUFuQjtBQUFxQjs7QUFBakMsQ0FBN0MsRUFBZ0YsQ0FBaEY7O0FBT25aLE1BQU1LLFdBQVcsQ0FBQ0MsS0FBRCxFQUFRQyxNQUFSLEtBQW1CO0FBQ2xDLFFBQU07QUFBRUMsU0FBRjtBQUFTQyxXQUFUO0FBQWtCQztBQUFsQixNQUFnQ0osS0FBdEMsQ0FEa0MsQ0FHbEM7O0FBQ0EsTUFBSUssWUFBWSxFQUFoQjtBQUNBQSxjQUFZUixXQUFXO0FBQ3JCLHlCQUFxQixJQURBO0FBRXJCTSxXQUZxQjtBQUdyQkMsYUFIcUI7QUFJckJFLG9CQUFnQlYsUUFBUVcsR0FBUixDQUFZLDBDQUFaO0FBSkssR0FBWCxDQUFaLENBTGtDLENBWWxDOztBQUNBLE1BQUlKLFdBQVcsQ0FBQ1AsUUFBUVcsR0FBUixDQUFZLHFDQUFaLENBQWhCLEVBQW9FO0FBQ2xFWCxZQUFRWSxHQUFSLENBQVkscUNBQVosRUFBbUQsSUFBbkQ7QUFDRCxHQWZpQyxDQWlCbEM7OztBQUNBLE1BQUlOLFVBQVUsUUFBZCxFQUF3Qk4sUUFBUVksR0FBUixDQUFZLGtDQUFaLEVBQWdELElBQWhEO0FBQ3hCLE1BQUlOLFVBQVUsZ0JBQWQsRUFBZ0NOLFFBQVFZLEdBQVIsQ0FBWSwwQ0FBWixFQUF3RCxJQUF4RDtBQUVoQ1AsU0FBTyxJQUFQLEVBQWE7QUFBRUk7QUFBRixHQUFiO0FBQ0QsQ0F0QkQ7O0FBd0JBLE1BQU1JLHdCQUF5QlQsS0FBRCxJQUFXO0FBQ3ZDLFFBQU07QUFBRUs7QUFBRixNQUFnQkwsS0FBdEI7QUFFQSxRQUFNVSxvQkFBb0JwQixhQUFhLGNBQWIsQ0FBMUI7QUFDQSxTQUNFO0FBQUE7QUFBQTtBQUFLLGlCQUFXZTtBQUFoQjtBQUNFLHdCQUFDLGlCQUFELEVBQXVCTCxLQUF2QjtBQURGLEdBREY7QUFLRCxDQVREOztBQVdBUyxzQkFBc0JFLFNBQXRCLEdBQWtDO0FBQ2hDTixhQUFXVixNQUFNaUIsU0FBTixDQUFnQkM7QUFESyxDQUFsQztBQUlPLE1BQU14QixlQUFlUyxtQkFBbUJDLFFBQW5CLEVBQTZCVSxxQkFBN0IsQ0FBckIsQzs7Ozs7Ozs7Ozs7QUM5Q1AsSUFBSUssT0FBSjtBQUFZM0IsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGdCQUFSLENBQWIsRUFBdUM7QUFBQ3NCLFVBQVFwQixDQUFSLEVBQVU7QUFBQ29CLGNBQVFwQixDQUFSO0FBQVU7O0FBQXRCLENBQXZDLEVBQStELENBQS9EO0FBQWtFLElBQUlxQixPQUFKO0FBQVk1QixPQUFPSSxLQUFQLENBQWFDLFFBQVEsZ0JBQVIsQ0FBYixFQUF1QztBQUFDdUIsVUFBUXJCLENBQVIsRUFBVTtBQUFDcUIsY0FBUXJCLENBQVI7QUFBVTs7QUFBdEIsQ0FBdkMsRUFBK0QsQ0FBL0Q7O0FBRzFGLE1BQU1zQixtQkFBbUJDLGtCQUN2QixDQUFDakIsS0FBRCxFQUFRQyxNQUFSLEVBQWdCaUIsR0FBaEIsS0FBd0I7QUFDdEIsTUFBSUMsaUJBQWlCLElBQXJCO0FBQ0EsUUFBTUMsVUFBVU4sUUFBUU8sV0FBUixDQUFvQixNQUNsQ1AsUUFBUVEsT0FBUixDQUFnQixNQUFNO0FBQ3BCO0FBQ0FILHFCQUFpQkYsZUFBZWpCLEtBQWYsRUFBc0JDLE1BQXRCLEVBQThCaUIsR0FBOUIsQ0FBakI7QUFDRCxHQUhELENBRGMsQ0FBaEI7QUFPQSxTQUFPLE1BQU07QUFDWCxRQUFJLE9BQU9DLGNBQVAsS0FBMEIsVUFBOUIsRUFBMENBO0FBQzFDLFdBQU9DLFFBQVFHLElBQVIsRUFBUDtBQUNELEdBSEQ7QUFJRCxDQWRIOztBQWlCQSxNQUFNekIscUJBQXFCMEIsUUFDekJULFFBQVFDLGlCQUFpQlEsSUFBakIsQ0FBUixDQURGOztBQXBCQXJDLE9BQU9zQyxhQUFQLENBd0JlM0Isa0JBeEJmLEUiLCJmaWxlIjoiL3BhY2thZ2VzL29rZ3Jvd19hY2NvdW50cy11aS1yZWFjdC5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIGltcG9ydC9uby11bnJlc29sdmVkICovXG5pbXBvcnQgQmxhemVUb1JlYWN0IGZyb20gJ21ldGVvci90aGVyZWFjdGl2ZXN0YWNrOmJsYXpldG9yZWFjdCc7XG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgU2Vzc2lvbiB9IGZyb20gJ21ldGVvci9zZXNzaW9uJztcbmltcG9ydCBjbGFzc05hbWVzIGZyb20gJ2NsYXNzbmFtZXMnO1xuaW1wb3J0IGNvbXBvc2VXaXRoVHJhY2tlciBmcm9tICcuL2NvbXBvc2VXaXRoVHJhY2tlcic7XG5cbmNvbnN0IGNvbXBvc2VyID0gKHByb3BzLCBvbkRhdGEpID0+IHtcbiAgY29uc3QgeyBzdGF0ZSwgdmlzaWJsZSwgaGlkZUxpbmtzIH0gPSBwcm9wcztcblxuICAvLyBHZW5lcmF0ZSBjbGFzc25hbWVzIHRoYXQgaWRlbnRpZnkgdGhlIHByb3BzIGFuZCB0aGUgZmxvd1xuICBsZXQgY2xhc3NOYW1lID0gJyc7XG4gIGNsYXNzTmFtZSA9IGNsYXNzTmFtZXMoe1xuICAgICdhY2NvdW50cy11aS1yZWFjdCc6IHRydWUsXG4gICAgdmlzaWJsZSxcbiAgICBoaWRlTGlua3MsXG4gICAgY2hhbmdlUGFzc3dvcmQ6IFNlc3Npb24uZ2V0KCdNZXRlb3IubG9naW5CdXR0b25zLmluQ2hhbmdlUGFzc3dvcmRGbG93JyksXG4gIH0pO1xuXG4gIC8vIElmIHZpc2libGUgaXMgc2V0LCBrZWVwIHRoZSBTZXNzaW9uIHZhbHVlIGFzIHRydWVcbiAgaWYgKHZpc2libGUgJiYgIVNlc3Npb24uZ2V0KCdNZXRlb3IubG9naW5CdXR0b25zLmRyb3Bkb3duVmlzaWJsZScpKSB7XG4gICAgU2Vzc2lvbi5zZXQoJ01ldGVvci5sb2dpbkJ1dHRvbnMuZHJvcGRvd25WaXNpYmxlJywgdHJ1ZSk7XG4gIH1cblxuICAvLyBTZXQgYSBzcGVjaWZpYyBzdGF0ZSBiYXNlZCBvbiBwcm9wc1xuICBpZiAoc3RhdGUgPT09ICdzaWduVXAnKSBTZXNzaW9uLnNldCgnTWV0ZW9yLmxvZ2luQnV0dG9ucy5pblNpZ251cEZsb3cnLCB0cnVlKTtcbiAgaWYgKHN0YXRlID09PSAnZm9yZ290UGFzc3dvcmQnKSBTZXNzaW9uLnNldCgnTWV0ZW9yLmxvZ2luQnV0dG9ucy5pbkZvcmdvdFBhc3N3b3JkRmxvdycsIHRydWUpO1xuXG4gIG9uRGF0YShudWxsLCB7IGNsYXNzTmFtZSB9KTtcbn07XG5cbmNvbnN0IExvZ2luQnV0dG9uc0NvbXBvbmVudCA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7IGNsYXNzTmFtZSB9ID0gcHJvcHM7XG5cbiAgY29uc3QgQmxhemVMb2dpbkJ1dHRvbnMgPSBCbGF6ZVRvUmVhY3QoJ2xvZ2luQnV0dG9ucycpO1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtjbGFzc05hbWV9PlxuICAgICAgPEJsYXplTG9naW5CdXR0b25zIHsuLi5wcm9wc30gLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbkxvZ2luQnV0dG9uc0NvbXBvbmVudC5wcm9wVHlwZXMgPSB7XG4gIGNsYXNzTmFtZTogUmVhY3QuUHJvcFR5cGVzLnN0cmluZyxcbn07XG5cbmV4cG9ydCBjb25zdCBMb2dpbkJ1dHRvbnMgPSBjb21wb3NlV2l0aFRyYWNrZXIoY29tcG9zZXIpKExvZ2luQnV0dG9uc0NvbXBvbmVudCk7XG4iLCJpbXBvcnQgeyBUcmFja2VyIH0gZnJvbSAnbWV0ZW9yL3RyYWNrZXInO1xuaW1wb3J0IHsgY29tcG9zZSB9IGZyb20gJ3JlYWN0LWtvbXBvc2VyJztcblxuY29uc3QgZ2V0VHJhY2tlckxvYWRlciA9IHJlYWN0aXZlTWFwcGVyID0+IChcbiAgKHByb3BzLCBvbkRhdGEsIGVudikgPT4ge1xuICAgIGxldCB0cmFja2VyQ2xlYW51cCA9IG51bGw7XG4gICAgY29uc3QgaGFuZGxlciA9IFRyYWNrZXIubm9ucmVhY3RpdmUoKCkgPT5cbiAgICAgIFRyYWNrZXIuYXV0b3J1bigoKSA9PiB7XG4gICAgICAgIC8vIGFzc2lnbiB0aGUgY3VzdG9tIGNsZWFuLXVwIGZ1bmN0aW9uLlxuICAgICAgICB0cmFja2VyQ2xlYW51cCA9IHJlYWN0aXZlTWFwcGVyKHByb3BzLCBvbkRhdGEsIGVudik7XG4gICAgICB9KVxuICAgICk7XG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgaWYgKHR5cGVvZiB0cmFja2VyQ2xlYW51cCA9PT0gJ2Z1bmN0aW9uJykgdHJhY2tlckNsZWFudXAoKTtcbiAgICAgIHJldHVybiBoYW5kbGVyLnN0b3AoKTtcbiAgICB9O1xuICB9XG4pO1xuXG5jb25zdCBjb21wb3NlV2l0aFRyYWNrZXIgPSBkYXRhID0+IChcbiAgY29tcG9zZShnZXRUcmFja2VyTG9hZGVyKGRhdGEpKVxuKTtcblxuZXhwb3J0IGRlZmF1bHQgY29tcG9zZVdpdGhUcmFja2VyO1xuIl19
