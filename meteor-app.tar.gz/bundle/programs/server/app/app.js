var require = meteorInstall({"imports":{"api":{"Items.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/Items.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
const Items = new Mongo.Collection('items');
const ItemSchema = new SimpleSchema({
  text: String,
  value: SimpleSchema.Integer
});
const ItemsSchema = new SimpleSchema({
  itemOne: ItemSchema,
  itemTwo: ItemSchema,
  lastUpdated: {
    type: Date,
    optional: true
  }
});
Items.attachSchema(ItemsSchema);

if (Meteor.isServer) {
  Meteor.publish('allItems', function () {
    return Items.find({}, {
      // limits the number of return json items from DB
      limit: 50,
      // value 1 (OLDEST) or -1 (NEWEST) determines directions of lastUpdated
      sort: {
        lastUpdated: -1
      }
    });
  });
  Meteor.methods({
    insertNewItem(itemOne, itemTwo) {
      Items.insert({
        itemOne: {
          text: itemOne,
          value: 0
        },
        itemTwo: {
          text: itemTwo,
          value: 0
        }
      });
      Roles.addUsersToRoles(Meteor.userId(), 'sumitter');
    },

    voteOnItem(item, position) {
      check(item, Object);
      let lastUpdated = new Date();

      if (Meteor.userId()) {
        if (position == 'itemOne') {
          Items.update(item._id, {
            $inc: {
              'itemOne.value': 1
            },
            $set: {
              lastUpdated
            }
          });
        } else {
          Items.update(item._id, {
            $inc: {
              'itemTwo.value': 1
            },
            $set: {
              lastUpdated
            }
          });
        }

        Roles.addUsersToRoles(Meteor.userId(), 'voter');
      }
    }

  });
}

module.exportDefault(Items);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"apic.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/apic.js                                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let HTTP;
module.watch(require("meteor/http"), {
  HTTP(v) {
    HTTP = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 2);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 3);
let request;
module.watch(require("request"), {
  default(v) {
    request = v;
  }

}, 4);
let https;
module.watch(require("https"), {
  default(v) {
    https = v;
  }

}, 5);
let tempData;
module.watch(require("../../server/tempData"), {
  default(v) {
    tempData = v;
  }

}, 6);
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
// apic
const ItemsApicDevices = new Mongo.Collection('itemapicdevices'); // simple schema debug

SimpleSchema.debug = true;
const ItemTransferRateSchema = new SimpleSchema({
  dataObj: {
    type: Object,
    blackbox: true
  },
  requestTime: SimpleSchema.Integer,
  dateTime: {
    type: Date
  }
});
const ItemsApicDevicesSchema = new SimpleSchema({
  siteData: ItemTransferRateSchema
});
ItemsApicDevices.attachSchema(ItemsApicDevicesSchema);

if (Meteor.isServer) {
  Meteor.methods({
    apicTicket(type, url, options) {
      this.unblock();

      try {
        const result = HTTP.call(type, url, options); // console.log(result); // debug

        return result;
      } catch (e) {
        // Got a network error, timeout, or HTTP error in the 400 or 500 range.
        console.log(e); // debug

        return e;
      }
    },

    apicHttpRequest(type, url, options) {
      this.unblock();

      try {
        return new Promise((resolve, reject) => {
          const result = HTTP.call(type, url, options); // console.log(result); // debug

          resolve(result);
        });
      } catch (e) {
        reject(e); // Got a network error, timeout, or HTTP error in the 400 or 500 range.

        console.log(e); // debugs
      }
    },

    apicDbRemove(dbID, uuid) {
      try {
        const result = ItemsApicDevices.remove(dbID); // console.log(result); // debug

        return result;
      } catch (e) {
        // Got a network error, timeout, or HTTP error in the 400 or 500 range.
        console.log(e); // debug

        return e;
      }

      ;
    },

    apicShowCommands(showCommand, uuid, dbId) {
      try {
        showObj = {
          "name": "frostShowCommand",
          "tieout": 0,
          "description": "",
          "commands": [showCommand],
          "deviceUuids": [uuid]
        };

        const timeNow = divisor => {
          return Math.round(new Date().getTime() / divisor);
        };

        const dateTime = new Date();
        const baseUrl = Meteor.settings.private.apicEM.uName ? Meteor.settings.private.apicEM.baseUrl : Meteor.settings.public.ciscoApicEM.baseUrl;
        const uName = Meteor.settings.private.apicEM.uName ? Meteor.settings.private.apicEM.uName : Meteor.settings.public.ciscoApicEM.uName;
        const uPass = Meteor.settings.private.apicEM.uName ? Meteor.settings.private.apicEM.uPass : Meteor.settings.public.ciscoApicEM.uPass;
        const apicRoleUrn = '/api/v1/user/role';
        const roleUrl = baseUrl + apicRoleUrn;
        const apicTicketUrn = '/api/v1/ticket';
        const ticketUrl = baseUrl + apicTicketUrn;
        const apicTicketOptions = {
          headers: {
            'content-type': 'application/json'
          },
          data: {
            username: uName,
            password: uPass
          }
        };
        const networkDevicePoller = baseUrl + "/api/v1/network-device-poller/cli/read-request";
        let ticketIdleTimeout = 0;
        let ticketSessionTimeout = 0;
        let oldApicTicket = ""; // creates dataBlob for an HTTPs request. creates and reuses apicTickets, tickets for the same request are reused.

        const apicOptions = bodyObj => {
          const apicTicket = () => {
            const setTimeouts = (idleTimeout, sessionTimeout) => {
              ticketIdleTimeout = timeNow(1000) + idleTimeout;
              ticketSessionTimeout = timeNow(1000) + sessionTimeout; //console.log("Ticket timeout <Time Now: Idle/Session> ",timeNow(1000)+": "+ticketIdleTimeout+"/"+ticketSessionTimeout);
              //console.log("Requesting New ticket: ", oldApicTicket)
            };

            if (ticketIdleTimeout === 0 && ticketSessionTimeout === 0) {
              let httpRequest = Meteor.call('apicTicket', "POST", ticketUrl, apicTicketOptions);

              if (httpRequest.data.response.serviceTicket !== undefined) {
                oldApicTicket = httpRequest.data.response.serviceTicket;
                setTimeouts(1800, 21600);
                console.log("###-New Ticket: ", oldApicTicket);
                console.log("###-Ticket timeout <Time Now: Idle/Session> ", timeNow(1000) + ": " + ticketIdleTimeout + "/" + ticketSessionTimeout);
                return httpRequest.data.response.serviceTicket;
              } else {
                return null;
              }
            } else if (timeNow(1000) >= ticketIdleTimeout || timeNow(1000) >= ticketSessionTimeout) {
              let httpRequest = Meteor.call('apicTicket', "POST", ticketUrl, apicTicketOptions);
              oldApicTicket = httpRequest.data.response.serviceTicket;
              setTimeouts(1800, 21600);
              console.log("***-Ticket expired requesting new Ticket: ", oldApicTicket);
              console.log("***-Ticket timeout <Time Now: Idle/Session> ", timeNow(1000) + ": " + ticketIdleTimeout + "/" + ticketSessionTimeout);
              return httpRequest.data.response.serviceTicket;
            } else {
              //console.log("Using Existing Ticket: ",oldApicTicket)
              //console.log("Ticket timeout <Time Now: Idle/Session> ",timeNow(1000)+": "+ticketIdleTimeout+"/"+ticketSessionTimeout);
              return oldApicTicket;
            }
          }; // this is the request body


          const requestObj = {
            headers: {
              'content-type': 'application/json',
              'x-auth-token': apicTicket()
            },
            data: bodyObj
          };
          return requestObj;
        };

        console.log(apicOptions(showObj));
        console.log();
        let responseTaskID = Meteor.call('apicHttpRequest', "POST", networkDevicePoller, apicOptions(showObj));
        let responseTaskURL = baseUrl + responseTaskID.data.response.url;
        console.log("*****" + responseTaskURL);
        let responseFileURL = ""; // initial state of the while loop

        let undefinedCounter = 0; // the while loop runs until this condition is met

        while (undefinedCounter < 300) {
          undefinedCounter++; // debug
          //console.log("waiting... Try:", undefinedCounter)

          const x = () => {
            let promise = new Promise((resolve, reject) => {
              let responseFileId = Meteor.call('apicHttpRequest', "GET", responseTaskURL, apicOptions(showObj));
              resolve(responseFileId);
            });
            return promise;
          };

          x().then(data => {
            //console.log(data.data.response.progress);
            if (data.data.response.progress != undefined && data.data.response.progress != "CLI Runner request creation") {
              // this breaks the while loop
              undefinedCounter = 800;
              console.log("This took this may requests: ", undefinedCounter);
              console.log("***AAA** ", data.data.response.progress);
              console.log("***BBB** ", JSON.parse(data.data.response.progress));
              let stringToJSON = JSON.parse(data.data.response.progress); //console.log("***** ",data.data.response);

              responseFileURL = baseUrl + "/api/v1/file/" + stringToJSON.fileId; //console.log(responseFileURL)
              //return Meteor.call('apicHttpRequest',"GET",responseFileURL,apicOptions(showObj));
            }
          });
        }

        console.log("responseFileURL", responseFileURL);
        let httpResponseFile = Meteor.call('apicHttpRequest', "GET", responseFileURL, apicOptions(showObj));
        console.log(httpResponseFile);
        console.log("*****", JSON.parse(httpResponseFile.content));
        let man2 = JSON.parse(httpResponseFile.content);
        console.log(man2[0].commandResponses);
        console.log("DBid", dbId);
        ItemsApicDevices.update(dbId, {
          $set: {
            'siteData.dataObj.commandRunner': man2[0].commandResponses
          }
        });
        return dbId; //console.log(httpResponseFile)
        //console.log(Meteor.call('apicHttpRequest',"GET",responseFileURL,""))
        //return apicOptions(showObj)
      } catch (e) {
        // Got a network error, timeout, or HTTP error in the 400 or 500 range.
        console.log(JSON.stringify(e)); // debug

        return e;
      }
    },

    apicClearShowCommands(dbID) {
      try {
        const result = Meteor.setTimeout(function () {
          ItemsApicDevices.update(dbID, {
            $set: {
              'siteData.dataObj.commandRunner': null
            }
          });
        }, 300000); // console.log(result); // debug

        return result;
      } catch (e) {
        // Got a network error, timeout, or HTTP error in the 400 or 500 range.
        console.log(e); // debug

        return e;
      }

      ;
    }

  });
}

module.exportDefault(ItemsApicDevices);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"prime.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/prime.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let HTTP;
module.watch(require("meteor/http"), {
  HTTP(v) {
    HTTP = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 2);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 3);
let request;
module.watch(require("request"), {
  default(v) {
    request = v;
  }

}, 4);
let https;
module.watch(require("https"), {
  default(v) {
    https = v;
  }

}, 5);
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
// prtg
const ItemsPrimeHosts = new Mongo.Collection('itemprimehosts');
const ItemPrimeHostsSchema = new SimpleSchema({
  dataObj: {
    type: Object,
    blackbox: true
  },
  requestTime: SimpleSchema.Integer,
  dateTime: {
    type: Date
  }
});
const ItemsPrimeHostsSchema = new SimpleSchema({
  hostData: ItemPrimeHostsSchema
});
ItemsPrimeHosts.attachSchema(ItemsPrimeHostsSchema);

if (Meteor.isServer) {
  Meteor.methods({
    primeHttpRequest(type, url, options) {
      this.unblock();

      try {
        const result = HTTP.call(type, url, options); // console.log(result); // debug

        return result;
      } catch (e) {
        // Got a network error, timeout, or HTTP error in the 400 or 500 range.
        console.log(e); // debug

        return e;
      }
    }

  });
}

module.exportDefault(ItemsPrimeHosts);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"prtg.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/prtg.js                                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let HTTP;
module.watch(require("meteor/http"), {
  HTTP(v) {
    HTTP = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 2);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 3);
let request;
module.watch(require("request"), {
  default(v) {
    request = v;
  }

}, 4);
let https;
module.watch(require("https"), {
  default(v) {
    https = v;
  }

}, 5);
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
// prtg
const ItemsPrtg = new Mongo.Collection('itemsprtg');
const ItemPrtgSchema = new SimpleSchema({
  dataObj: {
    type: Object,
    blackbox: true
  },
  requestTime: SimpleSchema.Integer,
  dateTime: {
    type: Date
  }
});
const ItemsPrtgSchema = new SimpleSchema({
  prtgData: ItemPrtgSchema
});
ItemsPrtg.attachSchema(ItemsPrtgSchema);

if (Meteor.isServer) {
  Meteor.publish('allApicItems', function () {
    return ItemsApic.find({}, {
      // limits the number of return json items from DB
      //limit: 50,
      // value 1 (OLDEST) or -1 (NEWEST) determines directions of lastUpdated
      sort: {
        "apicData.dateTime": -1
      }
    });
  });
  Meteor.publish('allPrtgItems', function () {
    return ItemsPrtg.find({}, {
      sort: {
        "prtgData.dataObj.group": 1,
        "prtgData.dataObj.device": 1
      }
    });
  });
  Meteor.methods({
    'getPrtgData': function () {
      return ItemsPrtg.find({}, {
        sort: {
          "prtgData.dataObj.group": 1,
          "prtgData.dataObj.device": 1
        }
      }).fetch();
    },
    'getPrtgDataFiltered': function () {
      const self = this;
      self.added('itemsprtg', Random.id(), {
        data
      });
      self.ready();
      let more = num;
      const intervalID = Meteor.setInterval(() => {
        more++;
        self.added('itemsprtg', Random.id(), {
          more
        });
      }, 5000);
      self.onStop(() => {
        Meteor.clearInterval(intervalID);
      });
    }
  });
}

module.exportDefault(ItemsPrtg);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"request.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/request.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let HTTP;
module.watch(require("meteor/http"), {
  HTTP(v) {
    HTTP = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 2);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 3);
let request;
module.watch(require("request"), {
  default(v) {
    request = v;
  }

}, 4);
let https;
module.watch(require("https"), {
  default(v) {
    https = v;
  }

}, 5);
let dns;
module.watch(require("dns"), {
  default(v) {
    dns = v;
  }

}, 6);
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
// apic
const ItemsApic = new Mongo.Collection('itemsapic');
const ItemApicSchema = new SimpleSchema({
  text: String,
  dataObj: {
    type: Object,
    blackbox: true
  },
  requestTime: SimpleSchema.Integer,
  dateTime: {
    type: Date
  }
});
const ItemsApicSchema = new SimpleSchema({
  apicData: ItemApicSchema
});
ItemsApic.attachSchema(ItemsApicSchema);

if (Meteor.isServer) {
  /*
    Meteor.publish('allApicItems', function() {
      return ItemsApic.find({}, {
        // limits the number of return json items from DB
        //limit: 50,
        // value 1 (OLDEST) or -1 (NEWEST) determines directions of lastUpdated
        sort: {"apicData.dateTime" : -1}
      });
    });
  */Meteor.methods({
    httpRequest(type, url, options) {
      this.unblock();

      try {
        return new Promise((resolve, reject) => {
          const result = HTTP.call(type, url, options); // console.log(result); // debug

          resolve(result);
        });
      } catch (e) {
        reject(e); // Got a network error, timeout, or HTTP error in the 400 or 500 range.

        console.log(e); // debugs
      }
    },

    checkApic(type, url, options) {
      this.unblock();

      try {
        const result = HTTP.call(type, url, options); // console.log(result); // debug

        return result;
      } catch (e) {
        // Got a network error, timeout, or HTTP error in the 400 or 500 range.
        console.log(e); // debug

        return e;
      }
    },

    insertNewApic(apicTicket, dataObj) {
      let timeNow = Math.round(new Date().getTime() / 1000);
      let dateTime = new Date();
      ItemsApic.insert({
        apicData: {
          text: apicTicket,
          dataObj: dataObj,
          requestTime: timeNow,
          dateTime: dateTime
        }
      });
      Roles.addUsersToRoles(Meteor.userId(), 'sumitter');
    },

    voteOnItemApic(item, position) {
      check(item, Object);
      let lastUpdated = new Date();

      if (Meteor.userId()) {
        if (position == 'itemOne') {
          ItemsApic.update(item._id, {
            $inc: {
              'itemOne.value': 1
            },
            $set: {
              lastUpdated
            }
          });
        }

        Roles.addUsersToRoles(Meteor.userId(), 'voter');
      }
    },

    'getDateISO': function () {
      let dateRange = () => {
        convertDays = function (d) {
          //Convert days into MilliSeconds
          return d * 86400000;
        };

        let dateISO = dateNum => {
          let newToday = new Date();
          let newLookupDate = new Date(newToday - convertDays(dateNum));
          newLookupDate = newLookupDate.toISOString().split('T');
          return newLookupDate[0];
        };

        let a = new Date();
        let today = dateISO(0);
        let yesterday = dateISO(1);
        let lastWeekStart = dateISO(a.getDay() + 7);
        let lastWeekEnd = dateISO(7 - a.getDay());
        var dateRangeLabels = {
          today: {
            start: today,
            end: today
          },
          yesterday: {
            start: yesterday,
            end: today
          },
          lastWeek: {
            start: lastWeekStart,
            end: lastWeekEnd
          }
        };
        return dateRangeLabels;
      };

      return dateRange();
    },
    'getDnsLookup': function (hostName) {
      let lookup = Meteor.wrapAsync(dns.lookup),
          ip = lookup(hostName);
      console.log(ip);
      return ip;
    }
  });
}

module.exportDefault(ItemsApic);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"transferRate.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/transferRate.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let HTTP;
module.watch(require("meteor/http"), {
  HTTP(v) {
    HTTP = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 2);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 3);
let request;
module.watch(require("request"), {
  default(v) {
    request = v;
  }

}, 4);
let https;
module.watch(require("https"), {
  default(v) {
    https = v;
  }

}, 5);
let tempData;
module.watch(require("../../server/tempData"), {
  default(v) {
    tempData = v;
  }

}, 6);
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
// prtg
const ItemsTransferRate = new Mongo.Collection('itemstransferrate');
const ItemTransferRateSchema = new SimpleSchema({
  dataObj: {
    type: Object,
    blackbox: true
  },
  requestTime: SimpleSchema.Integer,
  dateTime: {
    type: Date
  }
});
const ItemsTransferRateSchema = new SimpleSchema({
  siteData: ItemTransferRateSchema
});
ItemsTransferRate.attachSchema(ItemsTransferRateSchema);

if (Meteor.isServer) {
  Meteor.methods({});
}

module.exportDefault(ItemsTransferRate);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"webserverStatus.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/webserverStatus.js                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let HTTP;
module.watch(require("meteor/http"), {
  HTTP(v) {
    HTTP = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 2);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 3);
let request;
module.watch(require("request"), {
  default(v) {
    request = v;
  }

}, 4);
let https;
module.watch(require("https"), {
  default(v) {
    https = v;
  }

}, 5);
let dns;
module.watch(require("dns"), {
  default(v) {
    dns = v;
  }

}, 6);
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
// apic
const ItemsWebServerStatus = new Mongo.Collection('itemswebserverstatus');
const ItemWebServerStatusSchema = new SimpleSchema({
  dataObj: {
    type: Object,
    blackbox: true
  },
  requestTime: SimpleSchema.Integer,
  dateTime: {
    type: Date
  }
});
const ItemsWebServerStatusSchema = new SimpleSchema({
  webServerData: ItemWebServerStatusSchema
});
ItemsWebServerStatus.attachSchema(ItemsWebServerStatusSchema);

if (Meteor.isServer) {
  /*
    Meteor.publish('allApicItems', function() {
      return ItemsApic.find({}, {
        // limits the number of return json items from DB
        //limit: 50,
        // value 1 (OLDEST) or -1 (NEWEST) determines directions of lastUpdated
        sort: {"apicData.dateTime" : -1}
      });
    });
  */Meteor.methods({});
}

module.exportDefault(ItemsWebServerStatus);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"accounts.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/server/accounts.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Accounts.onCreateUser((options, user) => {
  // console.log(options, user);
  if (Meteor.settings.admins.indexOf(options.email) > -1) {
    user.roles = ['admin'];
  }

  return user;
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"apicDevices.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/server/apicDevices.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _this = this;

module.export({
  apicDevices: () => apicDevices
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ItemsApicDevices;
module.watch(require("../api/apic"), {
  default(v) {
    ItemsApicDevices = v;
  }

}, 1);

let apicDevices = () => {
  let clientId = false;
  let counter = 0;
  const self = _this;

  const timeNow = divisor => {
    return Math.round(new Date().getTime() / divisor);
  };

  const dateTime = new Date();
  const baseUrl = Meteor.settings.private.apicEM.uName ? Meteor.settings.private.apicEM.baseUrl : Meteor.settings.public.ciscoApicEM.baseUrl;
  const uName = Meteor.settings.private.apicEM.uName ? Meteor.settings.private.apicEM.uName : Meteor.settings.public.ciscoApicEM.uName;
  const uPass = Meteor.settings.private.apicEM.uName ? Meteor.settings.private.apicEM.uPass : Meteor.settings.public.ciscoApicEM.uPass;
  const clientIdent = {
    clientIp: "",
    clientId: false,
    setIp: function (ip) {
      if (this.clientId === false) {
        this.clientId = ip + " : " + Random.id(); //console.log("data",this.clientId);

        return this.clientId;
      } else {
        //console.log("data",this.clientId);
        return this.clientId;
      }
    }
  };

  const findItem = value => {
    return ItemsApicDevices.findOne({
      "siteData.dataObj.id": value
    });
  };

  const countCollections = () => {
    return ItemsApicDevices.find().count();
  };

  console.log("apicDevices Count: ", countCollections());
  const apicRoleUrn = '/api/v1/user/role';
  const roleUrl = baseUrl + apicRoleUrn;
  const apicTicketUrn = '/api/v1/ticket';
  const ticketUrl = baseUrl + apicTicketUrn;
  const apicTicketOptions = {
    headers: {
      'content-type': 'application/json'
    },
    data: {
      username: uName,
      password: uPass
    } // commands to be run against apic device. No more than 5  per arrays e.g. [0,1,2,3,4]

  };
  const downPortCommandArray = ["show int | i proto.*notconnect|proto.*administratively down|Last in.* [6-9]w|Last in.*[0-9][0-9]w|[0-9]y|disabled|Last input never, output never, output hang never"];
  let apicDevicesUrn = "/api/v1/network-device";
  let devicesUrl = baseUrl + apicDevicesUrn;
  let ticketIdleTimeout = 0;
  let ticketSessionTimeout = 0;
  let oldApicTicket = "";

  const statusCodeParser = statusCode => {
    if (statusCode === 200) {
      return 0;
    } else {
      return 1;
    }
  };

  const getTimeNow = () => {
    return new Date().getTime();
  };

  const convertDateTime = dateString => {
    let someDate = new Date(dateString); //console.log(someDate.getTime());

    return someDate.getTime();
  };

  const apicOptions = bodyObj => {
    const apicTicket = () => {
      const setTimeouts = (idleTimeout, sessionTimeout) => {
        ticketIdleTimeout = timeNow(1000) + idleTimeout;
        ticketSessionTimeout = timeNow(1000) + sessionTimeout; //console.log("Ticket timeout <Time Now: Idle/Session> ",timeNow(1000)+": "+ticketIdleTimeout+"/"+ticketSessionTimeout);
        //console.log("Requesting New ticket: ", oldApicTicket)
      };

      if (ticketIdleTimeout === 0 && ticketSessionTimeout === 0) {
        let httpRequest = Meteor.call('apicTicket', "POST", ticketUrl, apicTicketOptions);

        if (httpRequest.data.response.serviceTicket !== undefined) {
          oldApicTicket = httpRequest.data.response.serviceTicket;
          setTimeouts(1800, 21600);
          console.log("###-New Ticket: ", oldApicTicket);
          console.log("###-Ticket timeout <Time Now: Idle/Session> ", timeNow(1000) + ": " + ticketIdleTimeout + "/" + ticketSessionTimeout);
          return httpRequest.data.response.serviceTicket;
        } else {
          return null;
        }
      } else if (timeNow(1000) >= ticketIdleTimeout || timeNow(1000) >= ticketSessionTimeout) {
        let httpRequest = Meteor.call('apicTicket', "POST", ticketUrl, apicTicketOptions);
        oldApicTicket = httpRequest.data.response.serviceTicket;
        setTimeouts(1800, 21600);
        console.log("***-Ticket expired requesting new Ticket: ", oldApicTicket);
        console.log("***-Ticket timeout <Time Now: Idle/Session> ", timeNow(1000) + ": " + ticketIdleTimeout + "/" + ticketSessionTimeout);
        return httpRequest.data.response.serviceTicket;
      } else {
        //console.log("Using Existing Ticket: ",oldApicTicket)
        //console.log("Ticket timeout <Time Now: Idle/Session> ",timeNow(1000)+": "+ticketIdleTimeout+"/"+ticketSessionTimeout);
        return oldApicTicket;
      }
    };

    const requestObj = {
      headers: {
        'content-type': 'application/json',
        'x-auth-token': apicTicket()
      },
      data: bodyObj
    };
    return requestObj;
  };

  const checkUserRole = (method, url, options) => {
    const httpUserRole = Meteor.call('httpRequest', method, url, options);
    const userRole = httpUserRole;

    if (userRole.statusCode === 200) {
      //console.log("hit")
      //console.log(userRole.data.response)
      return userRole.data.response;
    } else {
      return userRole;
    }
  }; // gets user roles as Array
  //const roleStatus = checkUserRole("GET",roleUrl,apicOptions(""));


  function httpRequest(method, url, options) {
    return Promise.asyncApply(() => {
      const httpDevices = Promise.await(Meteor.call('httpRequest', method, url, options));
      const apicDevices = Promise.await(httpDevices); // error checking REST request. If not 200 do nothing and log

      if (Promise.await(apicDevices.statusCode) === 200) {
        // itterate over object
        return Promise.await(Promise.all(apicDevices.data.response.map((data, index) => {
          // debug
          //console.log(apicDevices)
          const managementIpAddress = data.managementIpAddress;
          const deviceId = data.id;
          const lastUpdateTime = data.lastUpdateTime;
          const dataCheck = ItemsApicDevices.find({
            "siteData.dataObj.managementIpAddress": managementIpAddress
          }).fetch();
          const normalize = data.hostname ? data.hostname.toLowerCase() : "Null"; // adds normalized name for easier searching

          data.normalizeHostName = normalize;

          const vlanDetail = () => {
            if (data.family == "Unified AP") {
              return data.vlanDetail = null;
            } else {
              const devicesVlanUrl = baseUrl + "/api/v1/network-device" + "/" + data.id + "/vlan";
              const vlanDetail = Meteor.call('apicHttpRequest', "GET", devicesVlanUrl, options);

              if (vlanDetail.statusCode == 200) {
                if (vlanDetail.data.response.length <= 0) {
                  return data.vlanDetail = null;
                } else {
                  return data.vlanDetail = vlanDetail.data.response;
                }
              } else {
                return data.vlanDetail = null;
              }
            }
          };

          const interfaceInfo = () => {
            if ((data.family == "Switches and Hubs" || data.family == "Routers") && data.errorCode === null || data.errorCode == "DEV-UNREACHED") {
              const interfaceInfoUrl = baseUrl + "/api/v1/interface/network-device" + "/" + data.id;
              const interfaceInfoCall = Meteor.call('apicHttpRequest', "GET", interfaceInfoUrl, options);

              if (interfaceInfoCall.statusCode == 200) {
                // creates a record of when the interface has gone down, and how long it has been down
                interfaceInfoCall.data.response.map((data, index) => {
                  if (data.status == "down") {
                    // debug
                    //console.log("Apic Says it's ",data.status);
                    if (dataCheck[0]) {
                      // debug
                      //console.log("Mongo Says it's ", dataCheck[0].siteData.dataObj.interfaceDetail[index].status);
                      if (dataCheck[0].siteData.dataObj.interfaceDetail[index].status == "up") {
                        // debug
                        //console.log("Mongo says UP, and APIC says it's DOWN. Setting downAsOf to current time");
                        //set downAsOf to Date Time in miliseconds
                        data.downAsOf = timeNow(1);
                      } else if (dataCheck[0].siteData.dataObj.interfaceDetail[index].status == "down") {
                        // debug
                        //console.log("Mongo says DOWN, and APIC says it's DOWN. Checking if field exists");
                        if (typeof dataCheck[0].siteData.dataObj.interfaceDetail[index].downAsOf == "number") {
                          // debug
                          //console.log("Number Detected, Doing nothing", dataCheck[0].siteData.dataObj.interfaceDetail[index].downAsOf)
                          // DO NOTHING, leave the existing time stamp
                          data.downAsOf = dataCheck[0].siteData.dataObj.interfaceDetail[index].downAsOf;
                        } else if (dataCheck[0].siteData.dataObj.interfaceDetail[index].downAsOf == null) {
                          // debug
                          /*console.log(data.id)
                          //console.log(dataCheck[0].siteData.dataObj.interfaceDetail[index].id);
                          console.log("The field does NOT exist setting downAsOf to current time", dataCheck[0].siteData.dataObj.interfaceDetail[index].downAsOf);
                          */ //set downAsOf to Date Time in miliseconds
                          data.downAsOf = timeNow(1);
                        } else {
                          // debug
                          //console.log("The field is DOES exist. NO CHANGE ***")
                          //set downAsOf to Date Time in miliseconds
                          data.downAsOf = timeNow(1);
                        }
                      }
                    }
                  } else {
                    // takes care of any other state
                    // debug
                    //console.log("Interface is up, markind downAsOf to NULL")
                    //set downAsOf to NULL
                    data.downAsOf = null;
                  }
                });
                return data.interfaceDetail = interfaceInfoCall.data.response;
              }
            }
          };

          const licenseInfo = () => {
            if ((data.family == "Switches and Hubs" || data.family == "Routers") && data.errorCode === null) {
              const licenseInfoUrl = baseUrl + "/api/v1/license-info/network-device" + "/" + data.id;
              const licenseInfoCall = Meteor.call('apicHttpRequest', "GET", licenseInfoUrl, options);

              if (licenseInfoCall.statusCode == 200) {
                return data.licenseDetail = licenseInfoCall.data.response;
              }
            }
          };

          const showCommands = (commandArray, uUids) => {
            let testCounter = 0;

            if (data.family == "Switches and Hubs" && data.errorCode === null) {
              const taskStatus = taskUrl => {
                let taskStausCall = Meteor.call('apicHttpRequest', "GET", taskUrl, apicOptions(""));
                console.log(taskStatusCall.data.response);
                return taskStatusCall.data.response;
              };

              if (roleStatus[0].role == "ROLE_ADMIN") {
                //console.log(roleStatus[0].role)
                //console.log(commandArray,uUids)
                const commandRunnerDTO = {
                  "name": "test",
                  "commands": commandArray,
                  "deviceUuids": [uUids]
                };
                const networkDevicePoller = baseUrl + "/api/v1/network-device-poller/cli/read-request"; //console.log(networkDevicePoller)
                //console.log(commandRunnerDTO)
                //console.log(networkDevicePoller)
                //console.log(apicOptions(commandRunnerDTO))

                const networkDevicePollerCall = Meteor.call('apicHttpRequest', "POST", networkDevicePoller, apicOptions(commandRunnerDTO)); //console.log(networkDevicePollerCall)
                //console.log(networkDevicePollerCall.statusCode)

                if (networkDevicePollerCall.statusCode == 202) {
                  //console.log(networkDevicePollerCall.data.response)
                  //console.log(networkDevicePollerCall.data.response.url)
                  const networkDevicePollerStatus = baseUrl + networkDevicePollerCall.data.response.url; //console.log(networkDevicePollerStatus)

                  return data.networkDevicePoller = taskStatus(networkDevicePollerStatus);
                } /*const licenseInfoUrl = baseUrl + "/api/v1/license-info/network-device" +"/"+ data.id;
                  const licenseInfoCall = Meteor.call('apicHttpRequest',"GET",licenseInfoUrl,options);
                  */
              }
            }
          };

          const dbInsert = dbData => {
            // debug
            //console.log("dbInsert index Hit: ",index)
            ItemsApicDevices.insert({
              siteData: {
                dataObj: dbData,
                requestTime: timeNow(1000),
                dateTime: dateTime
              }
            });
          };

          const dbUpdate = (ddCheck, dbData, cTime, cdTime) => {
            console.log("updating", ddCheck);
            console.log("current time", cTime);
            console.log("current date time", cdTime);
            ItemsApicDevices.update(ddCheck, {
              $set: {
                'siteData.dataObj': dbData,
                'siteData.requestTime': cTime,
                'siteData.dateTime': cdTime
              }
            });
          };

          const dbTasks = () => {
            function restDataHandler() {
              return Promise.asyncApply(() => {
                const dbMatch = Promise.await(findItem(deviceId));

                if (Promise.await(dbMatch) === undefined) {
                  // debug
                  //console.log("undefined")
                  ItemsApicDevices.remove({
                    "siteData.dataObj.id": deviceId
                  });
                  vlanDetail();
                  interfaceInfo();
                  licenseInfo();
                  dbInsert(data); // if there is a match compare the lastUpdateTimes, if they match it skips
                } else if (dbMatch.siteData.dataObj.lastUpdateTime == lastUpdateTime) {// debug
                  //console.log("Match Found",dbMatch.siteData.dataObj.lastUpdateTime);
                  //console.log("equality")
                  // remove matches that fail the lastUpdateTime comparison
                } else {
                  // database Item ID
                  const dbDataID = dbMatch._id; // debug
                  //console.log("unequal")

                  vlanDetail();
                  interfaceInfo();
                  licenseInfo(); // disabled, but it works
                  //showCommands(downPortCommandArray,deviceId);

                  dbUpdate(dbDataID, data, timeNow(1000), dateTime);
                }
              });
            }

            ; //ItemsApicDevices.remove({"siteData.dataObj.managementIpAddress":managementIpAddress,"siteData.dataObj.lastUpdateTime":{"$lte":lastUpdateTime}});

            restDataHandler();
          };

          dbTasks();
        })));
      } else {
        console.log("REST FAILURE: ", apicDevices);
      }
    });
  }

  const poll = () => {
    console.log("requesting upto 500 objects from APIC-EM");
    console.log();
    httpRequest("GET", devicesUrl, apicOptions(""));

    if (countCollections() >= 300) {
      console.log("over 9000!!! actually it's only only over 300 Devices!!!", countCollections());
      console.log("requesting upto ANOTHER 500 objects from APIC-EM");
      apicDevicesUrn500 = baseUrl + "/api/v1/network-device/501/500";
      httpRequest("GET", apicDevicesUrn500, apicOptions(""));
    }
  };

  const intervalId = Meteor.setInterval(() => {
    counter++;
    console.log("Apic Data Publish on client Counter: %s", counter);
    return poll();
  }, 300000);
  poll();
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"webServerStatus.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/server/webServerStatus.js                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  webServerStatus: () => webServerStatus,
  blah: () => blah
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ItemsWebServerStatus;
module.watch(require("../api/webserverStatus"), {
  default(v) {
    ItemsWebServerStatus = v;
  }

}, 1);

let webServerStatus = webServerObj => {
  const statusCodeParser = statusCode => {
    if (statusCode === 200) {
      return 0;
    } else {
      return 1;
    }
  };

  const getTimeNow = () => {
    return new Date().getTime();
  };

  const convertDateTime = dateString => {
    let someDate = new Date(dateString); //console.log(someDate.getTime());

    return someDate.getTime();
  };

  const delayCalculator = (startTime, endTime) => {
    let requestTime = endTime - startTime;
    return requestTime;
  };

  const totalTimeCalculator = (oldTime, newTime) => {
    let totalTime = oldTime + newTime;
    return totalTime;
  };

  const highestTimeCalculator = (oldTime, newTime) => {
    if (newTime > oldTime) {
      return newTime;
    } else {
      return oldTime;
    }
  };

  const lowestTimeCalculator = (oldTime, newTime) => {
    if (newTime < oldTime) {
      return newTime;
    } else {
      return oldTime;
    }
  };

  let databaseObj = (name, description, url, rTime, rCode, fCode) => {
    let tango = {
      name: name,
      description: description,
      url: url,
      statistics: {
        responseTimeTotal: rTime,
        responseTimeLast: rTime,
        responseTimeCount: 1,
        responseTimeHighest: rTime,
        responseTimeLowest: rTime
      },
      httpRequest: {
        responseStatusCode: rCode,
        webServerFailureStatus: fCode,
        webServerFailurecount: 0
      }
    };
    return tango;
  };

  const poll = () => {
    webServerObj.map(data => {
      //console.log(JSON.stringify(data, null, 2));
      const webServerMethod = "GET";
      const webServerUrl = data.url;
      const webServerOptions = {};
      const currentTime = getTimeNow();
      const currentDateTime = new Date();
      const startTime = getTimeNow();

      function httpRequest(method, url, options) {
        return Promise.asyncApply(() => {
          const httpDevices = Promise.await(Meteor.call('httpRequest', method, url, options));
          const httpReturn = Promise.await(httpDevices);

          if (Promise.await(httpReturn)) {
            const endTime = getTimeNow(); //console.log("httpResonse " + data.name , httpReturn.headers);
            //console.log(httpReturn.headers.date);

            const httpReturnTime = convertDateTime(httpReturn.headers.date); //console.log(statusCodeParser(httpReturn.statusCode));

            const failureCode = statusCodeParser(httpReturn.statusCode);
            const httpResponseCode = httpReturn.statusCode;
            const currentResponseTime = delayCalculator(startTime, endTime); //console.log(httpReturnTime+" "+currentTime)
            //console.log(data.name)
            //console.log(data.url)
            //console.log(data.description)
            //console.log(httpReturn.statusCode)
            //console.log(failureCode)
            //console.log(delayCalculator(currentTime,httpReturnTime))
            //console.log("StartRaw endRaw: ", startTime+" "+endTime)
            //console.log("Start and Endtime ",delayCalculator(startTime,endTime))
            // error checking REST request. If not 200 do nothing and log
            // http status code
            // webServers name
            // language discribing the server
            // 0 returned on status code 200, 1 returned on all else

            const dbDataCheck = ItemsWebServerStatus.find({
              "webServerData.dataObj.name": data.name
            }).fetch(); //console.log("dataCheck : ",dbDataCheck);

            const dbInsert = (dData, cTime, dTime) => {
              //console.log("insert Attempt")
              ItemsWebServerStatus.insert({
                webServerData: {
                  dataObj: dData,
                  requestTime: cTime,
                  dateTime: dTime
                }
              });
            };

            const dbUpdate = (ddCheck, trTime, crTime, hrTime, lrTime, httpCode, fCode, cwfCount, cTime, cdTime) => {
              ItemsWebServerStatus.update(ddCheck["0"]._id, {
                $inc: {
                  'webServerData.dataObj.statistics.responseTimeCount': 1
                },
                $set: {
                  'webServerData.dataObj.statistics.responseTimeTotal': trTime,
                  'webServerData.dataObj.statistics.responseTimeLast': crTime,
                  'webServerData.dataObj.statistics.responseTimeHighest': hrTime,
                  'webServerData.dataObj.statistics.responseTimeLowest': lrTime,
                  'webServerData.dataObj.httpRequest.responseStatusCode': httpCode,
                  'webServerData.dataObj.httpRequest.webServerFailureStatus': fCode,
                  'webServerData.dataObj.httpRequest.webServerFailurecount': cwfCount,
                  'webServerData.requestTime': cTime,
                  'webServerData.dateTime': cdTime
                }
              });
            };

            if (dbDataCheck.length >= 1) {
              //console.log("Check Passed")
              const dbResponseTimeTotal = dbDataCheck["0"].webServerData.dataObj.statistics.responseTimeTotal;
              const dbHighestTime = dbDataCheck["0"].webServerData.dataObj.statistics.responseTimeHighest;
              const dbLowestTime = dbDataCheck["0"].webServerData.dataObj.statistics.responseTimeLowest;
              const currentWebServerFailurecount = dbDataCheck["0"].webServerData.dataObj.httpRequest.webServerFailurecount + failureCode;
              const totalResponseTime = totalTimeCalculator(dbResponseTimeTotal, currentResponseTime);
              const highestReponseTime = highestTimeCalculator(dbHighestTime, currentResponseTime);
              const lowestResponseTime = lowestTimeCalculator(dbLowestTime, currentResponseTime);
              dbUpdate(dbDataCheck, totalResponseTime, currentResponseTime, highestReponseTime, lowestResponseTime, httpResponseCode, failureCode, currentWebServerFailurecount, currentTime, currentDateTime);
            } else {
              //console.log("Check Failed")
              const dBdata = databaseObj(data.name, data.description, data.url, currentResponseTime, httpResponseCode, failureCode);
              dbInsert(dBdata, currentTime, currentDateTime);
            }
          }
        });
      }

      httpRequest(webServerMethod, webServerUrl, webServerOptions);
    });
  };

  const intervalId = Meteor.setInterval(() => {
    //console.log("poll hit");
    return poll();
  }, 15000);
  poll();
  let debugHelper1 = "Debug helper";
  return debugHelper1;
};

const blah = text => {
  let text1 = "this is blah default";
  let text2 = text;
  return text1 += text2;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"tempData.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/tempData.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.exports = {
  tempData0: () => {
    let data = "";
    return data;
  },
  tempData1: () => {
    let data = "";
    return data;
  },
  tempData2: () => {
    let data = "";
    return data;
  },
  tempData3: () => {
    let data = "";
    return data;
  }
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Random;
module.watch(require("meteor/random"), {
  Random(v) {
    Random = v;
  }

}, 1);
let Items;
module.watch(require("../imports/api/Items"), {
  default(v) {
    Items = v;
  }

}, 2);
let ItemsPrtg;
module.watch(require("../imports/api/prtg"), {
  default(v) {
    ItemsPrtg = v;
  }

}, 3);
let ItemsApicDevices;
module.watch(require("../imports/api/apic"), {
  default(v) {
    ItemsApicDevices = v;
  }

}, 4);
let ItemsTransferRate;
module.watch(require("../imports/api/transferRate"), {
  default(v) {
    ItemsTransferRate = v;
  }

}, 5);
let ItemsPrimeHosts;
module.watch(require("../imports/api/prime"), {
  default(v) {
    ItemsPrimeHosts = v;
  }

}, 6);
let ItemsWebServerStatus;
module.watch(require("../imports/api/webserverStatus"), {
  default(v) {
    ItemsWebServerStatus = v;
  }

}, 7);
let tempData;
module.watch(require("./tempData"), {
  default(v) {
    tempData = v;
  }

}, 8);
let webServerStatus, blah;
module.watch(require("../imports/server/webServerStatus"), {
  webServerStatus(v) {
    webServerStatus = v;
  },

  blah(v) {
    blah = v;
  }

}, 9);
let apicDevices;
module.watch(require("../imports/server/apicDevices"), {
  apicDevices(v) {
    apicDevices = v;
  }

}, 10);
module.watch(require("../imports/api/webserverStatus"));
module.watch(require("../imports/server/accounts"));
module.watch(require("../imports/api/request"));
module.watch(require("../imports/api/prtg"));
module.watch(require("../imports/api/transferRate"));
module.watch(require("../imports/api/apic"));
module.watch(require("../imports/api/prime"));
webServerStatus(Meteor.settings.webServerList);
Meteor.publish('webServerStatus', function () {
  let clientId = false;
  let counter = 0;
  const self = this;
  const clientIdent = {
    clientIp: "",
    clientId: false,
    setIp: function (ip) {
      if (this.clientId === false) {
        this.clientId = ip + " : " + Random.id(); //console.log("data",this.clientId);

        return this.clientId;
      } else {
        //console.log("data",this.clientId);
        return this.clientId;
      }
    }
  };

  const countCollections = () => {
    return ItemsWebServerStatus.find().count();
  };

  const miniMongo = () => {
    return ItemsWebServerStatus.find();
  };

  console.log("ItemsWebServerStatus Count: ", countCollections());

  const poll = () => {
    return miniMongo();
  };

  const intervalId = Meteor.setInterval(() => {
    counter++;
    console.log("ItemsWebServerStatus Data Publish on client %s Counter: %s", clientIdent.setIp(this.connection.clientAddress), counter);
    return poll();
  }, 300000);
  self.onStop(() => {
    console.log("Terminating ItemsWebServerStatus Publish on client %s Counter After: %s", clientIdent.setIp(this.connection.clientAddress), counter);
    Meteor.clearInterval(intervalId);
  });
  return poll();
}); //publish user data in mini mongo

Meteor.publish('currentUser', function () {
  return Meteor.users.find({
    _id: this.userID
  }, {
    fields: {
      roles: 1
    }
  });
});
Meteor.publish('primeHosts', function () {
  let countCollections = ItemsPrimeHosts.find().count();
  let timeNow = Math.round(new Date().getTime() / 1000);
  let dateTime = new Date();
  let baseUrl = Meteor.settings.private.prime.uName ? Meteor.settings.private.prime.baseUrl : Meteor.settings.public.ciscoApicEM.baseUrl;
  let uName = Meteor.settings.private.prime.uName ? Meteor.settings.private.prime.uName : Meteor.settings.public.ciscoApicEM.uName;
  let uPass = Meteor.settings.private.prime.uName ? Meteor.settings.private.prime.uPass : Meteor.settings.public.ciscoApicEM.uPass;
  let primeLookupUrn = '/webacs/api/v1/data/Clients.json?.full=true&securityPolicyStatus=eq("FAILED")&.maxResults=400';
  let devicesUrl = baseUrl + primeLookupUrn;
  let primeOptions = {
    headers: {
      'authorization': uName + " " + uPass,
      "accept": "application/json"
    }
  };
  let httpReturn = Meteor.call('primeHttpRequest', "GET", devicesUrl, primeOptions); //let apicTicket = httpTicket.data.response.serviceTicket;

  let primeHosts = httpReturn.content; //console.log(httpReturn)
  // for whatever reason it's returned as a string from prime...

  primeHosts = JSON.parse(httpReturn.content);

  if (countCollections <= 0) {
    primeHosts.queryResponse.entity.map(data => {
      ItemsPrimeHosts.insert({
        hostData: {
          dataObj: data,
          requestTime: timeNow,
          dateTime: dateTime
        }
      });
    });
    return ItemsPrimeHosts.find();
  } else {
    let currentTimeEpoch = Math.round(new Date().getTime() / 1000); // returns the oldest DB items epoch timestamp

    let oldestDocument = ItemsPrimeHosts.find({}, {
      sort: {
        "hostData.requestTime": -1
      },
      fields: {
        "hostData.requestTime": 1,
        _id: 0
      },
      limit: 1
    }).fetch();
    let oldestDocumentEpoch = oldestDocument[0].hostData.requestTime;

    if (currentTimeEpoch - oldestDocumentEpoch > 120) {
      ItemsPrimeHosts.remove({
        "hostData.requestTime": {
          "$lte": Math.round(new Date().getTime() / 1000 - 30)
        }
      });
      console.log("Prime Devices DB STALE Requesting NEW data");
      primeHosts.queryResponse.entity.map(data => {
        ItemsPrimeHosts.insert({
          hostData: {
            dataObj: data,
            requestTime: timeNow,
            dateTime: dateTime
          }
        });
      });
      return ItemsPrimeHosts.find();
    }

    return ItemsPrimeHosts.find();
  }
});
apicDevices();
Meteor.publish('apicDevices', function () {
  let clientId = false;
  let counter = 0;
  const self = this;
  const clientIdent = {
    clientIp: "",
    clientId: false,
    setIp: function (ip) {
      if (this.clientId === false) {
        this.clientId = ip + " : " + Random.id(); //console.log("data",this.clientId);

        return this.clientId;
      } else {
        //console.log("data",this.clientId);
        return this.clientId;
      }
    }
  };

  const countCollections = () => {
    return ItemsApicDevices.find().count();
  };

  const miniMongo = () => {
    return ItemsApicDevices.find({}, {
      fields: {
        "siteData.dataObj.family": 1,
        "siteData.dataObj.hostname": 1,
        "siteData.dataObj.role": 1,
        "siteData.dataObj.lastUpdated": 1,
        "siteData.dataObj.managementIpAddress": 1,
        "siteData.dataObj.softwareVersion": 1,
        "siteData.dataObj.upTime": 1,
        "siteData.dataObj.interfaceCount": 1,
        "siteData.dataObj.series": 1,
        "siteData.dataObj.serialNumber": 1,
        "siteData.dataObj.reachabilityStatus": 1,
        "siteData.dataObj.normalizeHostName": 1,
        "siteData.dataObj.id": 1,
        "siteData.dataObj.vlanDetail": 1,
        "siteData.dataObj.reachabilityFailureReason": 1,
        "siteData.dataObj.interfaceDetail": 1,
        "siteData.dataObj.licenseDetail": 1,
        "siteData.dataObj.commandRunner": 1
      }
    });
  };

  console.log("apicDevices Count: ", countCollections());

  const poll = () => {
    return miniMongo();
  };

  const intervalId = Meteor.setInterval(() => {
    counter++;
    console.log("Apic Data Publish on client %s Counter: %s", clientIdent.setIp(this.connection.clientAddress), counter);
    return poll();
  }, 300000);
  self.onStop(() => {
    console.log("Terminating Apic Publish on client %s Counter After: %s", clientIdent.setIp(this.connection.clientAddress), counter);
    Meteor.clearInterval(intervalId);
  });
  return poll();
});
Meteor.publish('siteCircuitInfo', function () {
  let countCollections = ItemsTransferRate.find().count();
  console.log(Meteor.call('getDateISO'));

  if (countCollections <= 0) {
    let sitesObj = tempData; //debug
    //console.log(sitesObj.tempData0())

    let temp = sitesObj.tempData0();
    let timeNow = Math.round(new Date().getTime() / 1000);
    let dateTime = new Date(); //console.log(newData.sensors[value].objid)
    //console.log(typeof(newData.sensors[value].objid))
    //console.log("DATA ID ",data._id)

    temp.map(data => {
      ItemsTransferRate.insert({
        siteData: {
          dataObj: data,
          requestTime: timeNow,
          dateTime: dateTime
        }
      });
    }); // return ready to load page, does not check data validity

    return ItemsTransferRate.find();
  } else {
    return ItemsTransferRate.find();
  }
});
Meteor.publish('prtgDeviceList', function () {
  let countCollections = ItemsPrtg.find().count();
  console.log(countCollections); /*
                                   data contains the entire return object
                                   data.content contains the contents
                                   headers contains the headers
                                   data.data.sensors contains an array of objects
                                   data.statusCode contains status code
                                   prtg data returns the following:
                                   statusCode: 200,
                                   content: '{"prtg-version":"17.2.30.1767","treesize":719,"sensors":[]}
                                 */
  let type = "GET";
  let baseUrl = Meteor.settings.private.prtgRest.baseUrl;
  let uName = Meteor.settings.private.prtgRest.uName;
  let uPass = Meteor.settings.private.prtgRest.uPass;
  let uCreds = "&username=" + uName + "&passhash=" + uPass;
  let url = baseUrl + "/api/table.json?content=sensors&output=json&columns=objid,probe,group,device,sensor,status,message,lastvalue,priority,favorite&count=20000" + uCreds;
  let options;
  let agent;
  const publishedKeys = {};

  if (countCollections <= 0) {
    console.log("HIT COUNT COLLECTION FAILURE <= 0");

    const poll = () => {
      // Let's assume the data comes back as an array of JSON documents, with an _id field, for simplicity
      const data = HTTP.get(url, options);
      let newData = JSON.parse(data.content); //console.log("DATAAAA  NEW",newData)
      //console.log("SENSORS",newData.sensors)
      //console.log("TREE",newData.treesize)
      //console.log("PUBLISHED KEYS",publishedKeys)

      newData.sensors.map((data, value) => {
        let newUri = baseUrl + "/chart.png?type=graph&graphid=0&width=925&height=300&id=" + newData.sensors[value].objid + uCreds;
        let timeNow = Math.round(new Date().getTime() / 1000);
        let dateTime = new Date(); //console.log(newData.sensors[value].objid)
        //console.log(typeof(newData.sensors[value].objid))
        //console.log("DATA ID ",data._id)

        data.graph = newUri;
        ItemsPrtg.insert({
          prtgData: {
            dataObj: data,
            requestTime: timeNow,
            dateTime: dateTime
          }
        });
      });
    };

    poll(); //this.ready();

    return ItemsPrtg.find({}, {
      sort: {
        "prtgData.dataObj.group": 1,
        "prtgData.dataObj.device": 1
      }
    });
  } else {
    console.log("HIT COLLECTION EXISTS!!!"); // gets the current time epoch

    let currentTimeEpoch = Math.round(new Date().getTime() / 1000); // returns the oldest DB items epoch timestamp

    let oldestDocument = ItemsPrtg.find({}, {
      sort: {
        "prtgData.requestTime": -1
      },
      fields: {
        "prtgData.requestTime": 1,
        _id: 0
      },
      limit: 1
    }).fetch(); // sets var to be only the epoch

    let oldestDocumentEpoch = oldestDocument[0].prtgData.requestTime;
    console.log("Document Epoch", oldestDocumentEpoch, " == ", "Elapsed Time", currentTimeEpoch - oldestDocumentEpoch);

    if (currentTimeEpoch - oldestDocumentEpoch > 3600) {
      console.log("HIT COLLECTION EXISTS!!! BUT IS OLD!!!!"); // removes old DB collection documents

      ItemsPrtg.remove({
        "prtgData.requestTime": {
          "$lte": Math.round(new Date().getTime() / 1000 - 30)
        }
      });

      const poll = () => {
        // Let's assume the data comes back as an array of JSON documents, with an _id field, for simplicity
        const data = HTTP.get(url, options);
        let newData = JSON.parse(data.content); //console.log("DATAAAA  NEW",newData)
        //console.log("SENSORS",newData.sensors)
        //console.log("TREE",newData.treesize)
        //console.log("PUBLISHED KEYS",publishedKeys)

        newData.sensors.map((data, value) => {
          let newUri = baseUrl + "/chart.png?type=graph&graphid=0&width=925&height=300&id=" + newData.sensors[value].objid + uCreds;
          let timeNow = Math.round(new Date().getTime() / 1000);
          let dateTime = new Date(); //console.log(newData.sensors[value].objid)
          //console.log(typeof(newData.sensors[value].objid))
          //console.log("DATA ID ",data._id)

          data.graph = newUri;
          ItemsPrtg.insert({
            prtgData: {
              dataObj: data,
              requestTime: timeNow,
              dateTime: dateTime
            }
          });
        });
      };

      poll(); //this.ready();

      return ItemsPrtg.find({}, {
        sort: {
          "prtgData.dataObj.group": 1,
          "prtgData.dataObj.device": 1
        }
      });
    } else {
      //this.ready();
      return ItemsPrtg.find({}, {
        sort: {
          "prtgData.dataObj.group": 1,
          "prtgData.dataObj.device": 1
        }
      });
    }
  }
});
Meteor.startup(() => {// code to run on server at startup
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx"
  ]
});
require("./server/tempData.js");
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvSXRlbXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2FwaWMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3ByaW1lLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9wcnRnLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9yZXF1ZXN0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS90cmFuc2ZlclJhdGUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3dlYnNlcnZlclN0YXR1cy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2ZXIvYWNjb3VudHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmVyL2FwaWNEZXZpY2VzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZlci93ZWJTZXJ2ZXJTdGF0dXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci90ZW1wRGF0YS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiTW9uZ28iLCJtb2R1bGUiLCJ3YXRjaCIsInJlcXVpcmUiLCJ2IiwiU2ltcGxlU2NoZW1hIiwiZGVmYXVsdCIsIkl0ZW1zIiwiQ29sbGVjdGlvbiIsIkl0ZW1TY2hlbWEiLCJ0ZXh0IiwiU3RyaW5nIiwidmFsdWUiLCJJbnRlZ2VyIiwiSXRlbXNTY2hlbWEiLCJpdGVtT25lIiwiaXRlbVR3byIsImxhc3RVcGRhdGVkIiwidHlwZSIsIkRhdGUiLCJvcHRpb25hbCIsImF0dGFjaFNjaGVtYSIsIk1ldGVvciIsImlzU2VydmVyIiwicHVibGlzaCIsImZpbmQiLCJsaW1pdCIsInNvcnQiLCJtZXRob2RzIiwiaW5zZXJ0TmV3SXRlbSIsImluc2VydCIsIlJvbGVzIiwiYWRkVXNlcnNUb1JvbGVzIiwidXNlcklkIiwidm90ZU9uSXRlbSIsIml0ZW0iLCJwb3NpdGlvbiIsImNoZWNrIiwiT2JqZWN0IiwidXBkYXRlIiwiX2lkIiwiJGluYyIsIiRzZXQiLCJleHBvcnREZWZhdWx0IiwiSFRUUCIsInJlcXVlc3QiLCJodHRwcyIsInRlbXBEYXRhIiwicHJvY2VzcyIsImVudiIsIk5PREVfVExTX1JFSkVDVF9VTkFVVEhPUklaRUQiLCJJdGVtc0FwaWNEZXZpY2VzIiwiZGVidWciLCJJdGVtVHJhbnNmZXJSYXRlU2NoZW1hIiwiZGF0YU9iaiIsImJsYWNrYm94IiwicmVxdWVzdFRpbWUiLCJkYXRlVGltZSIsIkl0ZW1zQXBpY0RldmljZXNTY2hlbWEiLCJzaXRlRGF0YSIsImFwaWNUaWNrZXQiLCJ1cmwiLCJvcHRpb25zIiwidW5ibG9jayIsInJlc3VsdCIsImNhbGwiLCJlIiwiY29uc29sZSIsImxvZyIsImFwaWNIdHRwUmVxdWVzdCIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVqZWN0IiwiYXBpY0RiUmVtb3ZlIiwiZGJJRCIsInV1aWQiLCJyZW1vdmUiLCJhcGljU2hvd0NvbW1hbmRzIiwic2hvd0NvbW1hbmQiLCJkYklkIiwic2hvd09iaiIsInRpbWVOb3ciLCJkaXZpc29yIiwiTWF0aCIsInJvdW5kIiwiZ2V0VGltZSIsImJhc2VVcmwiLCJzZXR0aW5ncyIsInByaXZhdGUiLCJhcGljRU0iLCJ1TmFtZSIsInB1YmxpYyIsImNpc2NvQXBpY0VNIiwidVBhc3MiLCJhcGljUm9sZVVybiIsInJvbGVVcmwiLCJhcGljVGlja2V0VXJuIiwidGlja2V0VXJsIiwiYXBpY1RpY2tldE9wdGlvbnMiLCJoZWFkZXJzIiwiZGF0YSIsInVzZXJuYW1lIiwicGFzc3dvcmQiLCJuZXR3b3JrRGV2aWNlUG9sbGVyIiwidGlja2V0SWRsZVRpbWVvdXQiLCJ0aWNrZXRTZXNzaW9uVGltZW91dCIsIm9sZEFwaWNUaWNrZXQiLCJhcGljT3B0aW9ucyIsImJvZHlPYmoiLCJzZXRUaW1lb3V0cyIsImlkbGVUaW1lb3V0Iiwic2Vzc2lvblRpbWVvdXQiLCJodHRwUmVxdWVzdCIsInJlc3BvbnNlIiwic2VydmljZVRpY2tldCIsInVuZGVmaW5lZCIsInJlcXVlc3RPYmoiLCJyZXNwb25zZVRhc2tJRCIsInJlc3BvbnNlVGFza1VSTCIsInJlc3BvbnNlRmlsZVVSTCIsInVuZGVmaW5lZENvdW50ZXIiLCJ4IiwicHJvbWlzZSIsInJlc3BvbnNlRmlsZUlkIiwidGhlbiIsInByb2dyZXNzIiwiSlNPTiIsInBhcnNlIiwic3RyaW5nVG9KU09OIiwiZmlsZUlkIiwiaHR0cFJlc3BvbnNlRmlsZSIsImNvbnRlbnQiLCJtYW4yIiwiY29tbWFuZFJlc3BvbnNlcyIsInN0cmluZ2lmeSIsImFwaWNDbGVhclNob3dDb21tYW5kcyIsInNldFRpbWVvdXQiLCJJdGVtc1ByaW1lSG9zdHMiLCJJdGVtUHJpbWVIb3N0c1NjaGVtYSIsIkl0ZW1zUHJpbWVIb3N0c1NjaGVtYSIsImhvc3REYXRhIiwicHJpbWVIdHRwUmVxdWVzdCIsIkl0ZW1zUHJ0ZyIsIkl0ZW1QcnRnU2NoZW1hIiwiSXRlbXNQcnRnU2NoZW1hIiwicHJ0Z0RhdGEiLCJJdGVtc0FwaWMiLCJmZXRjaCIsInNlbGYiLCJhZGRlZCIsIlJhbmRvbSIsImlkIiwicmVhZHkiLCJtb3JlIiwibnVtIiwiaW50ZXJ2YWxJRCIsInNldEludGVydmFsIiwib25TdG9wIiwiY2xlYXJJbnRlcnZhbCIsImRucyIsIkl0ZW1BcGljU2NoZW1hIiwiSXRlbXNBcGljU2NoZW1hIiwiYXBpY0RhdGEiLCJjaGVja0FwaWMiLCJpbnNlcnROZXdBcGljIiwidm90ZU9uSXRlbUFwaWMiLCJkYXRlUmFuZ2UiLCJjb252ZXJ0RGF5cyIsImQiLCJkYXRlSVNPIiwiZGF0ZU51bSIsIm5ld1RvZGF5IiwibmV3TG9va3VwRGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJhIiwidG9kYXkiLCJ5ZXN0ZXJkYXkiLCJsYXN0V2Vla1N0YXJ0IiwiZ2V0RGF5IiwibGFzdFdlZWtFbmQiLCJkYXRlUmFuZ2VMYWJlbHMiLCJzdGFydCIsImVuZCIsImxhc3RXZWVrIiwiaG9zdE5hbWUiLCJsb29rdXAiLCJ3cmFwQXN5bmMiLCJpcCIsIkl0ZW1zVHJhbnNmZXJSYXRlIiwiSXRlbXNUcmFuc2ZlclJhdGVTY2hlbWEiLCJJdGVtc1dlYlNlcnZlclN0YXR1cyIsIkl0ZW1XZWJTZXJ2ZXJTdGF0dXNTY2hlbWEiLCJJdGVtc1dlYlNlcnZlclN0YXR1c1NjaGVtYSIsIndlYlNlcnZlckRhdGEiLCJBY2NvdW50cyIsIm9uQ3JlYXRlVXNlciIsInVzZXIiLCJhZG1pbnMiLCJpbmRleE9mIiwiZW1haWwiLCJyb2xlcyIsImV4cG9ydCIsImFwaWNEZXZpY2VzIiwiY2xpZW50SWQiLCJjb3VudGVyIiwiY2xpZW50SWRlbnQiLCJjbGllbnRJcCIsInNldElwIiwiZmluZEl0ZW0iLCJmaW5kT25lIiwiY291bnRDb2xsZWN0aW9ucyIsImNvdW50IiwiZG93blBvcnRDb21tYW5kQXJyYXkiLCJhcGljRGV2aWNlc1VybiIsImRldmljZXNVcmwiLCJzdGF0dXNDb2RlUGFyc2VyIiwic3RhdHVzQ29kZSIsImdldFRpbWVOb3ciLCJjb252ZXJ0RGF0ZVRpbWUiLCJkYXRlU3RyaW5nIiwic29tZURhdGUiLCJjaGVja1VzZXJSb2xlIiwibWV0aG9kIiwiaHR0cFVzZXJSb2xlIiwidXNlclJvbGUiLCJodHRwRGV2aWNlcyIsImFsbCIsIm1hcCIsImluZGV4IiwibWFuYWdlbWVudElwQWRkcmVzcyIsImRldmljZUlkIiwibGFzdFVwZGF0ZVRpbWUiLCJkYXRhQ2hlY2siLCJub3JtYWxpemUiLCJob3N0bmFtZSIsInRvTG93ZXJDYXNlIiwibm9ybWFsaXplSG9zdE5hbWUiLCJ2bGFuRGV0YWlsIiwiZmFtaWx5IiwiZGV2aWNlc1ZsYW5VcmwiLCJsZW5ndGgiLCJpbnRlcmZhY2VJbmZvIiwiZXJyb3JDb2RlIiwiaW50ZXJmYWNlSW5mb1VybCIsImludGVyZmFjZUluZm9DYWxsIiwic3RhdHVzIiwiaW50ZXJmYWNlRGV0YWlsIiwiZG93bkFzT2YiLCJsaWNlbnNlSW5mbyIsImxpY2Vuc2VJbmZvVXJsIiwibGljZW5zZUluZm9DYWxsIiwibGljZW5zZURldGFpbCIsInNob3dDb21tYW5kcyIsImNvbW1hbmRBcnJheSIsInVVaWRzIiwidGVzdENvdW50ZXIiLCJ0YXNrU3RhdHVzIiwidGFza1VybCIsInRhc2tTdGF1c0NhbGwiLCJ0YXNrU3RhdHVzQ2FsbCIsInJvbGVTdGF0dXMiLCJyb2xlIiwiY29tbWFuZFJ1bm5lckRUTyIsIm5ldHdvcmtEZXZpY2VQb2xsZXJDYWxsIiwibmV0d29ya0RldmljZVBvbGxlclN0YXR1cyIsImRiSW5zZXJ0IiwiZGJEYXRhIiwiZGJVcGRhdGUiLCJkZENoZWNrIiwiY1RpbWUiLCJjZFRpbWUiLCJkYlRhc2tzIiwicmVzdERhdGFIYW5kbGVyIiwiZGJNYXRjaCIsImRiRGF0YUlEIiwicG9sbCIsImFwaWNEZXZpY2VzVXJuNTAwIiwiaW50ZXJ2YWxJZCIsIndlYlNlcnZlclN0YXR1cyIsImJsYWgiLCJ3ZWJTZXJ2ZXJPYmoiLCJkZWxheUNhbGN1bGF0b3IiLCJzdGFydFRpbWUiLCJlbmRUaW1lIiwidG90YWxUaW1lQ2FsY3VsYXRvciIsIm9sZFRpbWUiLCJuZXdUaW1lIiwidG90YWxUaW1lIiwiaGlnaGVzdFRpbWVDYWxjdWxhdG9yIiwibG93ZXN0VGltZUNhbGN1bGF0b3IiLCJkYXRhYmFzZU9iaiIsIm5hbWUiLCJkZXNjcmlwdGlvbiIsInJUaW1lIiwickNvZGUiLCJmQ29kZSIsInRhbmdvIiwic3RhdGlzdGljcyIsInJlc3BvbnNlVGltZVRvdGFsIiwicmVzcG9uc2VUaW1lTGFzdCIsInJlc3BvbnNlVGltZUNvdW50IiwicmVzcG9uc2VUaW1lSGlnaGVzdCIsInJlc3BvbnNlVGltZUxvd2VzdCIsInJlc3BvbnNlU3RhdHVzQ29kZSIsIndlYlNlcnZlckZhaWx1cmVTdGF0dXMiLCJ3ZWJTZXJ2ZXJGYWlsdXJlY291bnQiLCJ3ZWJTZXJ2ZXJNZXRob2QiLCJ3ZWJTZXJ2ZXJVcmwiLCJ3ZWJTZXJ2ZXJPcHRpb25zIiwiY3VycmVudFRpbWUiLCJjdXJyZW50RGF0ZVRpbWUiLCJodHRwUmV0dXJuIiwiaHR0cFJldHVyblRpbWUiLCJkYXRlIiwiZmFpbHVyZUNvZGUiLCJodHRwUmVzcG9uc2VDb2RlIiwiY3VycmVudFJlc3BvbnNlVGltZSIsImRiRGF0YUNoZWNrIiwiZERhdGEiLCJkVGltZSIsInRyVGltZSIsImNyVGltZSIsImhyVGltZSIsImxyVGltZSIsImh0dHBDb2RlIiwiY3dmQ291bnQiLCJkYlJlc3BvbnNlVGltZVRvdGFsIiwiZGJIaWdoZXN0VGltZSIsImRiTG93ZXN0VGltZSIsImN1cnJlbnRXZWJTZXJ2ZXJGYWlsdXJlY291bnQiLCJ0b3RhbFJlc3BvbnNlVGltZSIsImhpZ2hlc3RSZXBvbnNlVGltZSIsImxvd2VzdFJlc3BvbnNlVGltZSIsImRCZGF0YSIsImRlYnVnSGVscGVyMSIsInRleHQxIiwidGV4dDIiLCJleHBvcnRzIiwidGVtcERhdGEwIiwidGVtcERhdGExIiwidGVtcERhdGEyIiwidGVtcERhdGEzIiwid2ViU2VydmVyTGlzdCIsIm1pbmlNb25nbyIsImNvbm5lY3Rpb24iLCJjbGllbnRBZGRyZXNzIiwidXNlcnMiLCJ1c2VySUQiLCJmaWVsZHMiLCJwcmltZSIsInByaW1lTG9va3VwVXJuIiwicHJpbWVPcHRpb25zIiwicHJpbWVIb3N0cyIsInF1ZXJ5UmVzcG9uc2UiLCJlbnRpdHkiLCJjdXJyZW50VGltZUVwb2NoIiwib2xkZXN0RG9jdW1lbnQiLCJvbGRlc3REb2N1bWVudEVwb2NoIiwic2l0ZXNPYmoiLCJ0ZW1wIiwicHJ0Z1Jlc3QiLCJ1Q3JlZHMiLCJhZ2VudCIsInB1Ymxpc2hlZEtleXMiLCJnZXQiLCJuZXdEYXRhIiwic2Vuc29ycyIsIm5ld1VyaSIsIm9iamlkIiwiZ3JhcGgiLCJzdGFydHVwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUlBLEtBQUo7QUFBVUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSCxRQUFNSSxDQUFOLEVBQVE7QUFBQ0osWUFBTUksQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJQyxZQUFKO0FBQWlCSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNHLFVBQVFGLENBQVIsRUFBVTtBQUFDQyxtQkFBYUQsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUd2RixNQUFNRyxRQUFRLElBQUlQLE1BQU1RLFVBQVYsQ0FBcUIsT0FBckIsQ0FBZDtBQUVBLE1BQU1DLGFBQWEsSUFBSUosWUFBSixDQUFrQjtBQUNuQ0ssUUFBTUMsTUFENkI7QUFFbkNDLFNBQU9QLGFBQWFRO0FBRmUsQ0FBbEIsQ0FBbkI7QUFLQSxNQUFNQyxjQUFjLElBQUlULFlBQUosQ0FBa0I7QUFDcENVLFdBQVNOLFVBRDJCO0FBRXBDTyxXQUFTUCxVQUYyQjtBQUdwQ1EsZUFBYztBQUNaQyxVQUFNQyxJQURNO0FBRVpDLGNBQVU7QUFGRTtBQUhzQixDQUFsQixDQUFwQjtBQVNBYixNQUFNYyxZQUFOLENBQW1CUCxXQUFuQjs7QUFFQSxJQUFJUSxPQUFPQyxRQUFYLEVBQXFCO0FBRW5CRCxTQUFPRSxPQUFQLENBQWUsVUFBZixFQUEyQixZQUFXO0FBQ3BDLFdBQU9qQixNQUFNa0IsSUFBTixDQUFXLEVBQVgsRUFBZTtBQUNwQjtBQUNBQyxhQUFPLEVBRmE7QUFHcEI7QUFDQUMsWUFBTTtBQUFDVixxQkFBYSxDQUFDO0FBQWY7QUFKYyxLQUFmLENBQVA7QUFNRCxHQVBEO0FBVUFLLFNBQU9NLE9BQVAsQ0FBZTtBQUNiQyxrQkFBY2QsT0FBZCxFQUFzQkMsT0FBdEIsRUFBK0I7QUFDN0JULFlBQU11QixNQUFOLENBQWE7QUFDVGYsaUJBQVM7QUFDUEwsZ0JBQU1LLE9BREM7QUFFUEgsaUJBQU87QUFGQSxTQURBO0FBS1RJLGlCQUFTO0FBQ1BOLGdCQUFNTSxPQURDO0FBRVBKLGlCQUFPO0FBRkE7QUFMQSxPQUFiO0FBVUVtQixZQUFNQyxlQUFOLENBQXNCVixPQUFPVyxNQUFQLEVBQXRCLEVBQXVDLFVBQXZDO0FBQ0gsS0FiWTs7QUFjYkMsZUFBV0MsSUFBWCxFQUFpQkMsUUFBakIsRUFBMkI7QUFDekJDLFlBQU1GLElBQU4sRUFBWUcsTUFBWjtBQUNBLFVBQUlyQixjQUFjLElBQUlFLElBQUosRUFBbEI7O0FBQ0EsVUFBR0csT0FBT1csTUFBUCxFQUFILEVBQW9CO0FBQ2xCLFlBQUdHLFlBQVksU0FBZixFQUEwQjtBQUN4QjdCLGdCQUFNZ0MsTUFBTixDQUFhSixLQUFLSyxHQUFsQixFQUF1QjtBQUNyQkMsa0JBQU07QUFDSiwrQkFBaUI7QUFEYixhQURlO0FBSXJCQyxrQkFBTTtBQUNKekI7QUFESTtBQUplLFdBQXZCO0FBUUQsU0FURCxNQVNPO0FBQ0xWLGdCQUFNZ0MsTUFBTixDQUFhSixLQUFLSyxHQUFsQixFQUF1QjtBQUNyQkMsa0JBQU07QUFDSiwrQkFBaUI7QUFEYixhQURlO0FBSXJCQyxrQkFBTTtBQUNKekI7QUFESTtBQUplLFdBQXZCO0FBUUQ7O0FBQ0RjLGNBQU1DLGVBQU4sQ0FBc0JWLE9BQU9XLE1BQVAsRUFBdEIsRUFBdUMsT0FBdkM7QUFDRDtBQUNGOztBQXZDWSxHQUFmO0FBeUNEOztBQTFFRGhDLE9BQU8wQyxhQUFQLENBNkVlcEMsS0E3RWYsRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJcUMsSUFBSjtBQUFTM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDeUMsT0FBS3hDLENBQUwsRUFBTztBQUFDd0MsV0FBS3hDLENBQUw7QUFBTzs7QUFBaEIsQ0FBcEMsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSWtCLE1BQUo7QUFBV3JCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ21CLFNBQU9sQixDQUFQLEVBQVM7QUFBQ2tCLGFBQU9sQixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlKLEtBQUo7QUFBVUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSCxRQUFNSSxDQUFOLEVBQVE7QUFBQ0osWUFBTUksQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJQyxZQUFKO0FBQWlCSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNHLFVBQVFGLENBQVIsRUFBVTtBQUFDQyxtQkFBYUQsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJeUMsT0FBSjtBQUFZNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFNBQVIsQ0FBYixFQUFnQztBQUFDRyxVQUFRRixDQUFSLEVBQVU7QUFBQ3lDLGNBQVF6QyxDQUFSO0FBQVU7O0FBQXRCLENBQWhDLEVBQXdELENBQXhEO0FBQTJELElBQUkwQyxLQUFKO0FBQVU3QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsT0FBUixDQUFiLEVBQThCO0FBQUNHLFVBQVFGLENBQVIsRUFBVTtBQUFDMEMsWUFBTTFDLENBQU47QUFBUTs7QUFBcEIsQ0FBOUIsRUFBb0QsQ0FBcEQ7QUFBdUQsSUFBSTJDLFFBQUo7QUFBYTlDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNHLFVBQVFGLENBQVIsRUFBVTtBQUFDMkMsZUFBUzNDLENBQVQ7QUFBVzs7QUFBdkIsQ0FBOUMsRUFBdUUsQ0FBdkU7QUFBN2I0QyxRQUFRQyxHQUFSLENBQVlDLDRCQUFaLEdBQTJDLEdBQTNDO0FBU0E7QUFFQSxNQUFNQyxtQkFBbUIsSUFBSW5ELE1BQU1RLFVBQVYsQ0FBcUIsaUJBQXJCLENBQXpCLEMsQ0FDQTs7QUFDQUgsYUFBYStDLEtBQWIsR0FBcUIsSUFBckI7QUFDQSxNQUFNQyx5QkFBeUIsSUFBSWhELFlBQUosQ0FBa0I7QUFDL0NpRCxXQUFTO0FBQ1BwQyxVQUFNb0IsTUFEQztBQUVQaUIsY0FBVTtBQUZILEdBRHNDO0FBSy9DQyxlQUFhbkQsYUFBYVEsT0FMcUI7QUFNL0M0QyxZQUFXO0FBQ1R2QyxVQUFNQztBQURHO0FBTm9DLENBQWxCLENBQS9CO0FBWUEsTUFBTXVDLHlCQUF5QixJQUFJckQsWUFBSixDQUFrQjtBQUMvQ3NELFlBQVVOO0FBRHFDLENBQWxCLENBQS9CO0FBSUFGLGlCQUFpQjlCLFlBQWpCLENBQThCcUMsc0JBQTlCOztBQUdBLElBQUlwQyxPQUFPQyxRQUFYLEVBQXFCO0FBQ25CRCxTQUFPTSxPQUFQLENBQWU7QUFDYmdDLGVBQVcxQyxJQUFYLEVBQWlCMkMsR0FBakIsRUFBc0JDLE9BQXRCLEVBQStCO0FBQzdCLFdBQUtDLE9BQUw7O0FBQ0EsVUFBSTtBQUNGLGNBQU1DLFNBQVNwQixLQUFLcUIsSUFBTCxDQUFVL0MsSUFBVixFQUFnQjJDLEdBQWhCLEVBQXFCQyxPQUFyQixDQUFmLENBREUsQ0FFRjs7QUFDQSxlQUFPRSxNQUFQO0FBQ0QsT0FKRCxDQUlFLE9BQU9FLENBQVAsRUFBVTtBQUNWO0FBQ0FDLGdCQUFRQyxHQUFSLENBQVlGLENBQVosRUFGVSxDQUVLOztBQUNmLGVBQU9BLENBQVA7QUFDRDtBQUNGLEtBWlk7O0FBYWJHLG9CQUFnQm5ELElBQWhCLEVBQXNCMkMsR0FBdEIsRUFBMkJDLE9BQTNCLEVBQW9DO0FBQ2xDLFdBQUtDLE9BQUw7O0FBQ0EsVUFBSTtBQUNGLGVBQU8sSUFBSU8sT0FBSixDQUFZLENBQUNDLE9BQUQsRUFBVUMsTUFBVixLQUFvQjtBQUNyQyxnQkFBTVIsU0FBU3BCLEtBQUtxQixJQUFMLENBQVUvQyxJQUFWLEVBQWdCMkMsR0FBaEIsRUFBcUJDLE9BQXJCLENBQWYsQ0FEcUMsQ0FFckM7O0FBQ0FTLGtCQUFRUCxNQUFSO0FBQ0QsU0FKTSxDQUFQO0FBS0QsT0FORCxDQU1FLE9BQU9FLENBQVAsRUFBVTtBQUNWTSxlQUFPTixDQUFQLEVBRFUsQ0FFVjs7QUFDQUMsZ0JBQVFDLEdBQVIsQ0FBWUYsQ0FBWixFQUhVLENBR0s7QUFDaEI7QUFDRixLQTFCWTs7QUEyQmJPLGlCQUFhQyxJQUFiLEVBQWtCQyxJQUFsQixFQUF3QjtBQUN0QixVQUFJO0FBQ0YsY0FBTVgsU0FBU2IsaUJBQWlCeUIsTUFBakIsQ0FBd0JGLElBQXhCLENBQWYsQ0FERSxDQUVGOztBQUNBLGVBQU9WLE1BQVA7QUFDRCxPQUpELENBSUUsT0FBT0UsQ0FBUCxFQUFVO0FBQ1Y7QUFDQUMsZ0JBQVFDLEdBQVIsQ0FBWUYsQ0FBWixFQUZVLENBRUs7O0FBQ2YsZUFBT0EsQ0FBUDtBQUNEOztBQUFBO0FBQ0YsS0FyQ1k7O0FBc0NiVyxxQkFBaUJDLFdBQWpCLEVBQTZCSCxJQUE3QixFQUFrQ0ksSUFBbEMsRUFBd0M7QUFDdEMsVUFBSTtBQUNGQyxrQkFBVTtBQUNSLGtCQUFPLGtCQURDO0FBRVIsb0JBQVMsQ0FGRDtBQUdSLHlCQUFjLEVBSE47QUFJUixzQkFBVyxDQUNURixXQURTLENBSkg7QUFPUix5QkFBYyxDQUNaSCxJQURZO0FBUE4sU0FBVjs7QUFXQSxjQUFNTSxVQUFXQyxPQUFELElBQVk7QUFDMUIsaUJBQU9DLEtBQUtDLEtBQUwsQ0FBVyxJQUFJakUsSUFBSixHQUFXa0UsT0FBWCxLQUF1QkgsT0FBbEMsQ0FBUDtBQUNELFNBRkQ7O0FBR0EsY0FBTXpCLFdBQVcsSUFBSXRDLElBQUosRUFBakI7QUFDQSxjQUFNbUUsVUFBVWhFLE9BQU9pRSxRQUFQLENBQWdCQyxPQUFoQixDQUF3QkMsTUFBeEIsQ0FBK0JDLEtBQS9CLEdBQXVDcEUsT0FBT2lFLFFBQVAsQ0FBZ0JDLE9BQWhCLENBQXdCQyxNQUF4QixDQUErQkgsT0FBdEUsR0FBZ0ZoRSxPQUFPaUUsUUFBUCxDQUFnQkksTUFBaEIsQ0FBdUJDLFdBQXZCLENBQW1DTixPQUFuSTtBQUNBLGNBQU1JLFFBQVFwRSxPQUFPaUUsUUFBUCxDQUFnQkMsT0FBaEIsQ0FBd0JDLE1BQXhCLENBQStCQyxLQUEvQixHQUF1Q3BFLE9BQU9pRSxRQUFQLENBQWdCQyxPQUFoQixDQUF3QkMsTUFBeEIsQ0FBK0JDLEtBQXRFLEdBQThFcEUsT0FBT2lFLFFBQVAsQ0FBZ0JJLE1BQWhCLENBQXVCQyxXQUF2QixDQUFtQ0YsS0FBL0g7QUFDQSxjQUFNRyxRQUFRdkUsT0FBT2lFLFFBQVAsQ0FBZ0JDLE9BQWhCLENBQXdCQyxNQUF4QixDQUErQkMsS0FBL0IsR0FBdUNwRSxPQUFPaUUsUUFBUCxDQUFnQkMsT0FBaEIsQ0FBd0JDLE1BQXhCLENBQStCSSxLQUF0RSxHQUE4RXZFLE9BQU9pRSxRQUFQLENBQWdCSSxNQUFoQixDQUF1QkMsV0FBdkIsQ0FBbUNDLEtBQS9IO0FBQ0EsY0FBTUMsY0FBYyxtQkFBcEI7QUFDQSxjQUFNQyxVQUFVVCxVQUFVUSxXQUExQjtBQUNBLGNBQU1FLGdCQUFnQixnQkFBdEI7QUFDQSxjQUFNQyxZQUFZWCxVQUFVVSxhQUE1QjtBQUNBLGNBQU1FLG9CQUFvQjtBQUN4QkMsbUJBQVM7QUFBRSw0QkFBZ0I7QUFBbEIsV0FEZTtBQUV4QkMsZ0JBQU07QUFBQ0Msc0JBQVVYLEtBQVg7QUFBa0JZLHNCQUFVVDtBQUE1QjtBQUZrQixTQUExQjtBQUlBLGNBQU1VLHNCQUFzQmpCLFVBQVUsZ0RBQXRDO0FBQ0EsWUFBSWtCLG9CQUFvQixDQUF4QjtBQUNBLFlBQUlDLHVCQUF1QixDQUEzQjtBQUNBLFlBQUlDLGdCQUFnQixFQUFwQixDQTlCRSxDQStCRjs7QUFDQSxjQUFNQyxjQUFlQyxPQUFELElBQWE7QUFDL0IsZ0JBQU1oRCxhQUFhLE1BQUk7QUFDckIsa0JBQU1pRCxjQUFjLENBQUNDLFdBQUQsRUFBYUMsY0FBYixLQUErQjtBQUNqRFAsa0NBQW9CdkIsUUFBUSxJQUFSLElBQWdCNkIsV0FBcEM7QUFDQUwscUNBQXVCeEIsUUFBUSxJQUFSLElBQWdCOEIsY0FBdkMsQ0FGaUQsQ0FHakQ7QUFDQTtBQUNELGFBTEQ7O0FBTUEsZ0JBQUlQLHNCQUFzQixDQUF0QixJQUEyQkMseUJBQXlCLENBQXhELEVBQTJEO0FBQ3pELGtCQUFJTyxjQUFjMUYsT0FBTzJDLElBQVAsQ0FBWSxZQUFaLEVBQTBCLE1BQTFCLEVBQWlDZ0MsU0FBakMsRUFBMkNDLGlCQUEzQyxDQUFsQjs7QUFDQSxrQkFBSWMsWUFBWVosSUFBWixDQUFpQmEsUUFBakIsQ0FBMEJDLGFBQTFCLEtBQTRDQyxTQUFoRCxFQUEyRDtBQUN6RFQsZ0NBQWdCTSxZQUFZWixJQUFaLENBQWlCYSxRQUFqQixDQUEwQkMsYUFBMUM7QUFDQUwsNEJBQVksSUFBWixFQUFpQixLQUFqQjtBQUNBMUMsd0JBQVFDLEdBQVIsQ0FBWSxrQkFBWixFQUErQnNDLGFBQS9CO0FBQ0F2Qyx3QkFBUUMsR0FBUixDQUFZLDhDQUFaLEVBQTJEYSxRQUFRLElBQVIsSUFBYyxJQUFkLEdBQW1CdUIsaUJBQW5CLEdBQXFDLEdBQXJDLEdBQXlDQyxvQkFBcEc7QUFDQSx1QkFBT08sWUFBWVosSUFBWixDQUFpQmEsUUFBakIsQ0FBMEJDLGFBQWpDO0FBQ0QsZUFORCxNQU1PO0FBQ0wsdUJBQU8sSUFBUDtBQUNEO0FBRUYsYUFaRCxNQVlPLElBQUlqQyxRQUFRLElBQVIsS0FBaUJ1QixpQkFBakIsSUFBc0N2QixRQUFRLElBQVIsS0FBaUJ3QixvQkFBM0QsRUFBZ0Y7QUFDckYsa0JBQUlPLGNBQWMxRixPQUFPMkMsSUFBUCxDQUFZLFlBQVosRUFBMEIsTUFBMUIsRUFBaUNnQyxTQUFqQyxFQUEyQ0MsaUJBQTNDLENBQWxCO0FBQ0FRLDhCQUFnQk0sWUFBWVosSUFBWixDQUFpQmEsUUFBakIsQ0FBMEJDLGFBQTFDO0FBQ0FMLDBCQUFZLElBQVosRUFBaUIsS0FBakI7QUFDQTFDLHNCQUFRQyxHQUFSLENBQVksNENBQVosRUFBeURzQyxhQUF6RDtBQUNBdkMsc0JBQVFDLEdBQVIsQ0FBWSw4Q0FBWixFQUEyRGEsUUFBUSxJQUFSLElBQWMsSUFBZCxHQUFtQnVCLGlCQUFuQixHQUFxQyxHQUFyQyxHQUF5Q0Msb0JBQXBHO0FBQ0EscUJBQU9PLFlBQVlaLElBQVosQ0FBaUJhLFFBQWpCLENBQTBCQyxhQUFqQztBQUNELGFBUE0sTUFPQTtBQUNMO0FBQ0E7QUFDQSxxQkFBT1IsYUFBUDtBQUNEO0FBQ0YsV0EvQkQsQ0FEK0IsQ0FpQy9COzs7QUFDQSxnQkFBTVUsYUFBYTtBQUNqQmpCLHFCQUFTO0FBQ1AsOEJBQWdCLGtCQURUO0FBRVAsOEJBQWdCdkM7QUFGVCxhQURRO0FBS2pCd0Msa0JBQU1RO0FBTFcsV0FBbkI7QUFPQSxpQkFBT1EsVUFBUDtBQUNELFNBMUNEOztBQTJDQWpELGdCQUFRQyxHQUFSLENBQVl1QyxZQUFZM0IsT0FBWixDQUFaO0FBQ0FiLGdCQUFRQyxHQUFSO0FBRUEsWUFBSWlELGlCQUFpQi9GLE9BQU8yQyxJQUFQLENBQVksaUJBQVosRUFBOEIsTUFBOUIsRUFBcUNzQyxtQkFBckMsRUFBeURJLFlBQVkzQixPQUFaLENBQXpELENBQXJCO0FBQ0EsWUFBSXNDLGtCQUFrQmhDLFVBQVUrQixlQUFlakIsSUFBZixDQUFvQmEsUUFBcEIsQ0FBNkJwRCxHQUE3RDtBQUNBTSxnQkFBUUMsR0FBUixDQUFZLFVBQVFrRCxlQUFwQjtBQUNBLFlBQUlDLGtCQUFrQixFQUF0QixDQWpGRSxDQWtGRjs7QUFDQSxZQUFJQyxtQkFBbUIsQ0FBdkIsQ0FuRkUsQ0FvRkY7O0FBQ0EsZUFBT0EsbUJBQW1CLEdBQTFCLEVBQThCO0FBQzVCQSw2QkFENEIsQ0FFNUI7QUFDQTs7QUFDQSxnQkFBTUMsSUFBSSxNQUFJO0FBQ1osZ0JBQUlDLFVBQVUsSUFBSXBELE9BQUosQ0FBWSxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBbUI7QUFDM0Msa0JBQUltRCxpQkFBaUJyRyxPQUFPMkMsSUFBUCxDQUFZLGlCQUFaLEVBQThCLEtBQTlCLEVBQW9DcUQsZUFBcEMsRUFBb0RYLFlBQVkzQixPQUFaLENBQXBELENBQXJCO0FBQ0FULHNCQUFRb0QsY0FBUjtBQUNELGFBSGEsQ0FBZDtBQUlBLG1CQUFPRCxPQUFQO0FBQ0QsV0FORDs7QUFPQUQsY0FBSUcsSUFBSixDQUFVeEIsSUFBRCxJQUFRO0FBQ2Y7QUFDQSxnQkFBSUEsS0FBS0EsSUFBTCxDQUFVYSxRQUFWLENBQW1CWSxRQUFuQixJQUErQlYsU0FBL0IsSUFBNENmLEtBQUtBLElBQUwsQ0FBVWEsUUFBVixDQUFtQlksUUFBbkIsSUFBK0IsNkJBQS9FLEVBQTZHO0FBQzNHO0FBQ0FMLGlDQUFtQixHQUFuQjtBQUNBckQsc0JBQVFDLEdBQVIsQ0FBWSwrQkFBWixFQUE2Q29ELGdCQUE3QztBQUNBckQsc0JBQVFDLEdBQVIsQ0FBWSxXQUFaLEVBQXdCZ0MsS0FBS0EsSUFBTCxDQUFVYSxRQUFWLENBQW1CWSxRQUEzQztBQUNBMUQsc0JBQVFDLEdBQVIsQ0FBWSxXQUFaLEVBQXdCMEQsS0FBS0MsS0FBTCxDQUFXM0IsS0FBS0EsSUFBTCxDQUFVYSxRQUFWLENBQW1CWSxRQUE5QixDQUF4QjtBQUNBLGtCQUFJRyxlQUFhRixLQUFLQyxLQUFMLENBQVczQixLQUFLQSxJQUFMLENBQVVhLFFBQVYsQ0FBbUJZLFFBQTlCLENBQWpCLENBTjJHLENBTzNHOztBQUVBTixnQ0FBa0JqQyxVQUFTLGVBQVQsR0FBeUIwQyxhQUFhQyxNQUF4RCxDQVQyRyxDQVUzRztBQUVBO0FBQ0Q7QUFDRixXQWhCRDtBQWlCRDs7QUFDRDlELGdCQUFRQyxHQUFSLENBQVksaUJBQVosRUFBOEJtRCxlQUE5QjtBQUVFLFlBQUlXLG1CQUFtQjVHLE9BQU8yQyxJQUFQLENBQVksaUJBQVosRUFBOEIsS0FBOUIsRUFBb0NzRCxlQUFwQyxFQUFvRFosWUFBWTNCLE9BQVosQ0FBcEQsQ0FBdkI7QUFDQWIsZ0JBQVFDLEdBQVIsQ0FBWThELGdCQUFaO0FBQ0EvRCxnQkFBUUMsR0FBUixDQUFZLE9BQVosRUFBb0IwRCxLQUFLQyxLQUFMLENBQVdHLGlCQUFpQkMsT0FBNUIsQ0FBcEI7QUFDQSxZQUFJQyxPQUFPTixLQUFLQyxLQUFMLENBQVdHLGlCQUFpQkMsT0FBNUIsQ0FBWDtBQUNBaEUsZ0JBQVFDLEdBQVIsQ0FBWWdFLEtBQUssQ0FBTCxFQUFRQyxnQkFBcEI7QUFDQWxFLGdCQUFRQyxHQUFSLENBQVksTUFBWixFQUFtQlcsSUFBbkI7QUFDQTVCLHlCQUFpQlosTUFBakIsQ0FBd0J3QyxJQUF4QixFQUE4QjtBQUM1QnJDLGdCQUFLO0FBQ0gsOENBQWlDMEYsS0FBSyxDQUFMLEVBQVFDO0FBRHRDO0FBRHVCLFNBQTlCO0FBS0EsZUFBT3RELElBQVAsQ0EvSEEsQ0FpSUQ7QUFFRDtBQUNBO0FBQ0QsT0FySUQsQ0FxSUUsT0FBT2IsQ0FBUCxFQUFVO0FBQ1Y7QUFDQUMsZ0JBQVFDLEdBQVIsQ0FBWTBELEtBQUtRLFNBQUwsQ0FBZXBFLENBQWYsQ0FBWixFQUZVLENBRXFCOztBQUMvQixlQUFPQSxDQUFQO0FBQ0Q7QUFDRixLQWpMWTs7QUFrTGJxRSwwQkFBc0I3RCxJQUF0QixFQUE0QjtBQUMxQixVQUFJO0FBQ0YsY0FBTVYsU0FBUzFDLE9BQU9rSCxVQUFQLENBQWtCLFlBQVc7QUFDMUNyRiwyQkFBaUJaLE1BQWpCLENBQXdCbUMsSUFBeEIsRUFBOEI7QUFDNUJoQyxrQkFBSztBQUNILGdEQUFpQztBQUQ5QjtBQUR1QixXQUE5QjtBQUtELFNBTmMsRUFNWixNQU5ZLENBQWYsQ0FERSxDQVFGOztBQUNBLGVBQU9zQixNQUFQO0FBQ0QsT0FWRCxDQVVFLE9BQU9FLENBQVAsRUFBVTtBQUNWO0FBQ0FDLGdCQUFRQyxHQUFSLENBQVlGLENBQVosRUFGVSxDQUVLOztBQUNmLGVBQU9BLENBQVA7QUFDRDs7QUFBQTtBQUNGOztBQWxNWSxHQUFmO0FBcU1EOztBQXZPRGpFLE9BQU8wQyxhQUFQLENBME9lUSxnQkExT2YsRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJUCxJQUFKO0FBQVMzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUN5QyxPQUFLeEMsQ0FBTCxFQUFPO0FBQUN3QyxXQUFLeEMsQ0FBTDtBQUFPOztBQUFoQixDQUFwQyxFQUFzRCxDQUF0RDtBQUF5RCxJQUFJa0IsTUFBSjtBQUFXckIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDbUIsU0FBT2xCLENBQVAsRUFBUztBQUFDa0IsYUFBT2xCLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUosS0FBSjtBQUFVQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNILFFBQU1JLENBQU4sRUFBUTtBQUFDSixZQUFNSSxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlDLFlBQUo7QUFBaUJKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0csVUFBUUYsQ0FBUixFQUFVO0FBQUNDLG1CQUFhRCxDQUFiO0FBQWU7O0FBQTNCLENBQXJDLEVBQWtFLENBQWxFO0FBQXFFLElBQUl5QyxPQUFKO0FBQVk1QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEVBQWdDO0FBQUNHLFVBQVFGLENBQVIsRUFBVTtBQUFDeUMsY0FBUXpDLENBQVI7QUFBVTs7QUFBdEIsQ0FBaEMsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSTBDLEtBQUo7QUFBVTdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxPQUFSLENBQWIsRUFBOEI7QUFBQ0csVUFBUUYsQ0FBUixFQUFVO0FBQUMwQyxZQUFNMUMsQ0FBTjtBQUFROztBQUFwQixDQUE5QixFQUFvRCxDQUFwRDtBQUF6WDRDLFFBQVFDLEdBQVIsQ0FBWUMsNEJBQVosR0FBMkMsR0FBM0M7QUFRQTtBQUNBLE1BQU11RixrQkFBa0IsSUFBSXpJLE1BQU1RLFVBQVYsQ0FBcUIsZ0JBQXJCLENBQXhCO0FBRUEsTUFBTWtJLHVCQUF1QixJQUFJckksWUFBSixDQUFrQjtBQUM3Q2lELFdBQVM7QUFDUHBDLFVBQU1vQixNQURDO0FBRVBpQixjQUFVO0FBRkgsR0FEb0M7QUFLN0NDLGVBQWFuRCxhQUFhUSxPQUxtQjtBQU03QzRDLFlBQVc7QUFDVHZDLFVBQU1DO0FBREc7QUFOa0MsQ0FBbEIsQ0FBN0I7QUFZQSxNQUFNd0gsd0JBQXdCLElBQUl0SSxZQUFKLENBQWtCO0FBQzlDdUksWUFBVUY7QUFEb0MsQ0FBbEIsQ0FBOUI7QUFJQUQsZ0JBQWdCcEgsWUFBaEIsQ0FBNkJzSCxxQkFBN0I7O0FBR0EsSUFBSXJILE9BQU9DLFFBQVgsRUFBcUI7QUFLbkJELFNBQU9NLE9BQVAsQ0FBZTtBQUNiaUgscUJBQWlCM0gsSUFBakIsRUFBdUIyQyxHQUF2QixFQUE0QkMsT0FBNUIsRUFBcUM7QUFDbkMsV0FBS0MsT0FBTDs7QUFDQSxVQUFJO0FBQ0YsY0FBTUMsU0FBU3BCLEtBQUtxQixJQUFMLENBQVUvQyxJQUFWLEVBQWdCMkMsR0FBaEIsRUFBcUJDLE9BQXJCLENBQWYsQ0FERSxDQUVGOztBQUNBLGVBQU9FLE1BQVA7QUFDRCxPQUpELENBSUUsT0FBT0UsQ0FBUCxFQUFVO0FBQ1Y7QUFDQUMsZ0JBQVFDLEdBQVIsQ0FBWUYsQ0FBWixFQUZVLENBRUs7O0FBQ2YsZUFBT0EsQ0FBUDtBQUNEO0FBQ0Y7O0FBWlksR0FBZjtBQWNEOztBQWpERGpFLE9BQU8wQyxhQUFQLENBb0RlOEYsZUFwRGYsRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJN0YsSUFBSjtBQUFTM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDeUMsT0FBS3hDLENBQUwsRUFBTztBQUFDd0MsV0FBS3hDLENBQUw7QUFBTzs7QUFBaEIsQ0FBcEMsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSWtCLE1BQUo7QUFBV3JCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ21CLFNBQU9sQixDQUFQLEVBQVM7QUFBQ2tCLGFBQU9sQixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlKLEtBQUo7QUFBVUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSCxRQUFNSSxDQUFOLEVBQVE7QUFBQ0osWUFBTUksQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJQyxZQUFKO0FBQWlCSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNHLFVBQVFGLENBQVIsRUFBVTtBQUFDQyxtQkFBYUQsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJeUMsT0FBSjtBQUFZNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFNBQVIsQ0FBYixFQUFnQztBQUFDRyxVQUFRRixDQUFSLEVBQVU7QUFBQ3lDLGNBQVF6QyxDQUFSO0FBQVU7O0FBQXRCLENBQWhDLEVBQXdELENBQXhEO0FBQTJELElBQUkwQyxLQUFKO0FBQVU3QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsT0FBUixDQUFiLEVBQThCO0FBQUNHLFVBQVFGLENBQVIsRUFBVTtBQUFDMEMsWUFBTTFDLENBQU47QUFBUTs7QUFBcEIsQ0FBOUIsRUFBb0QsQ0FBcEQ7QUFBelg0QyxRQUFRQyxHQUFSLENBQVlDLDRCQUFaLEdBQTJDLEdBQTNDO0FBUUE7QUFDQSxNQUFNNEYsWUFBWSxJQUFJOUksTUFBTVEsVUFBVixDQUFxQixXQUFyQixDQUFsQjtBQUVBLE1BQU11SSxpQkFBaUIsSUFBSTFJLFlBQUosQ0FBa0I7QUFDdkNpRCxXQUFTO0FBQ1BwQyxVQUFNb0IsTUFEQztBQUVQaUIsY0FBVTtBQUZILEdBRDhCO0FBS3ZDQyxlQUFhbkQsYUFBYVEsT0FMYTtBQU12QzRDLFlBQVc7QUFDVHZDLFVBQU1DO0FBREc7QUFONEIsQ0FBbEIsQ0FBdkI7QUFZQSxNQUFNNkgsa0JBQWtCLElBQUkzSSxZQUFKLENBQWtCO0FBQ3hDNEksWUFBVUY7QUFEOEIsQ0FBbEIsQ0FBeEI7QUFJQUQsVUFBVXpILFlBQVYsQ0FBdUIySCxlQUF2Qjs7QUFJQSxJQUFJMUgsT0FBT0MsUUFBWCxFQUFxQjtBQUVuQkQsU0FBT0UsT0FBUCxDQUFlLGNBQWYsRUFBK0IsWUFBVztBQUN4QyxXQUFPMEgsVUFBVXpILElBQVYsQ0FBZSxFQUFmLEVBQW1CO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBRSxZQUFNO0FBQUMsNkJBQXNCLENBQUM7QUFBeEI7QUFKa0IsS0FBbkIsQ0FBUDtBQU1ELEdBUEQ7QUFTQUwsU0FBT0UsT0FBUCxDQUFlLGNBQWYsRUFBK0IsWUFBVztBQUV4QyxXQUFPc0gsVUFBVXJILElBQVYsQ0FBZSxFQUFmLEVBQWtCO0FBQUNFLFlBQUs7QUFBQyxrQ0FBMEIsQ0FBM0I7QUFBNkIsbUNBQTJCO0FBQXhEO0FBQU4sS0FBbEIsQ0FBUDtBQUNELEdBSEQ7QUFTQUwsU0FBT00sT0FBUCxDQUFlO0FBQ2IsbUJBQWUsWUFBVTtBQUN2QixhQUFPa0gsVUFBVXJILElBQVYsQ0FBZSxFQUFmLEVBQWtCO0FBQUNFLGNBQUs7QUFBQyxvQ0FBMEIsQ0FBM0I7QUFBNkIscUNBQTJCO0FBQXhEO0FBQU4sT0FBbEIsRUFBcUZ3SCxLQUFyRixFQUFQO0FBQ0QsS0FIWTtBQUliLDJCQUF1QixZQUFVO0FBQy9CLFlBQU1DLE9BQU8sSUFBYjtBQUNBQSxXQUFLQyxLQUFMLENBQVcsV0FBWCxFQUF1QkMsT0FBT0MsRUFBUCxFQUF2QixFQUFtQztBQUFDbkQ7QUFBRCxPQUFuQztBQUNBZ0QsV0FBS0ksS0FBTDtBQUNBLFVBQUlDLE9BQU9DLEdBQVg7QUFDQSxZQUFNQyxhQUFhckksT0FBT3NJLFdBQVAsQ0FBbUIsTUFBSTtBQUN4Q0g7QUFDQUwsYUFBS0MsS0FBTCxDQUFXLFdBQVgsRUFBdUJDLE9BQU9DLEVBQVAsRUFBdkIsRUFBbUM7QUFBQ0U7QUFBRCxTQUFuQztBQUNELE9BSGtCLEVBR2pCLElBSGlCLENBQW5CO0FBS0FMLFdBQUtTLE1BQUwsQ0FBWSxNQUFJO0FBQ2R2SSxlQUFPd0ksYUFBUCxDQUFxQkgsVUFBckI7QUFDRCxPQUZEO0FBR0Q7QUFqQlksR0FBZjtBQW1CRDs7QUF0RUQxSixPQUFPMEMsYUFBUCxDQXlFZW1HLFNBekVmLEU7Ozs7Ozs7Ozs7O0FDQUEsSUFBSWxHLElBQUo7QUFBUzNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ3lDLE9BQUt4QyxDQUFMLEVBQU87QUFBQ3dDLFdBQUt4QyxDQUFMO0FBQU87O0FBQWhCLENBQXBDLEVBQXNELENBQXREO0FBQXlELElBQUlrQixNQUFKO0FBQVdyQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNtQixTQUFPbEIsQ0FBUCxFQUFTO0FBQUNrQixhQUFPbEIsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJSixLQUFKO0FBQVVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0gsUUFBTUksQ0FBTixFQUFRO0FBQUNKLFlBQU1JLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUMsWUFBSjtBQUFpQkosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRyxVQUFRRixDQUFSLEVBQVU7QUFBQ0MsbUJBQWFELENBQWI7QUFBZTs7QUFBM0IsQ0FBckMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSXlDLE9BQUo7QUFBWTVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxTQUFSLENBQWIsRUFBZ0M7QUFBQ0csVUFBUUYsQ0FBUixFQUFVO0FBQUN5QyxjQUFRekMsQ0FBUjtBQUFVOztBQUF0QixDQUFoQyxFQUF3RCxDQUF4RDtBQUEyRCxJQUFJMEMsS0FBSjtBQUFVN0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLE9BQVIsQ0FBYixFQUE4QjtBQUFDRyxVQUFRRixDQUFSLEVBQVU7QUFBQzBDLFlBQU0xQyxDQUFOO0FBQVE7O0FBQXBCLENBQTlCLEVBQW9ELENBQXBEO0FBQXVELElBQUkySixHQUFKO0FBQVE5SixPQUFPQyxLQUFQLENBQWFDLFFBQVEsS0FBUixDQUFiLEVBQTRCO0FBQUNHLFVBQVFGLENBQVIsRUFBVTtBQUFDMkosVUFBSTNKLENBQUo7QUFBTTs7QUFBbEIsQ0FBNUIsRUFBZ0QsQ0FBaEQ7QUFBeGI0QyxRQUFRQyxHQUFSLENBQVlDLDRCQUFaLEdBQTJDLEdBQTNDO0FBVUE7QUFDQSxNQUFNZ0csWUFBWSxJQUFJbEosTUFBTVEsVUFBVixDQUFxQixXQUFyQixDQUFsQjtBQUVBLE1BQU13SixpQkFBaUIsSUFBSTNKLFlBQUosQ0FBa0I7QUFDdkNLLFFBQU1DLE1BRGlDO0FBRXZDMkMsV0FBUztBQUNQcEMsVUFBTW9CLE1BREM7QUFFUGlCLGNBQVU7QUFGSCxHQUY4QjtBQU12Q0MsZUFBYW5ELGFBQWFRLE9BTmE7QUFPdkM0QyxZQUFXO0FBQ1R2QyxVQUFNQztBQURHO0FBUDRCLENBQWxCLENBQXZCO0FBWUEsTUFBTThJLGtCQUFrQixJQUFJNUosWUFBSixDQUFrQjtBQUN4QzZKLFlBQVVGO0FBRDhCLENBQWxCLENBQXhCO0FBS0FkLFVBQVU3SCxZQUFWLENBQXVCNEksZUFBdkI7O0FBR0EsSUFBSTNJLE9BQU9DLFFBQVgsRUFBcUI7QUFFckI7Ozs7Ozs7OztJQVlFRCxPQUFPTSxPQUFQLENBQWU7QUFDYm9GLGdCQUFZOUYsSUFBWixFQUFrQjJDLEdBQWxCLEVBQXVCQyxPQUF2QixFQUFnQztBQUM5QixXQUFLQyxPQUFMOztBQUNBLFVBQUk7QUFDRixlQUFPLElBQUlPLE9BQUosQ0FBWSxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBb0I7QUFDckMsZ0JBQU1SLFNBQVNwQixLQUFLcUIsSUFBTCxDQUFVL0MsSUFBVixFQUFnQjJDLEdBQWhCLEVBQXFCQyxPQUFyQixDQUFmLENBRHFDLENBRXJDOztBQUNBUyxrQkFBUVAsTUFBUjtBQUNELFNBSk0sQ0FBUDtBQUtELE9BTkQsQ0FNRSxPQUFPRSxDQUFQLEVBQVU7QUFDVk0sZUFBT04sQ0FBUCxFQURVLENBRVY7O0FBQ0FDLGdCQUFRQyxHQUFSLENBQVlGLENBQVosRUFIVSxDQUdLO0FBQ2hCO0FBQ0YsS0FkWTs7QUFlYmlHLGNBQVVqSixJQUFWLEVBQWdCMkMsR0FBaEIsRUFBcUJDLE9BQXJCLEVBQThCO0FBQzVCLFdBQUtDLE9BQUw7O0FBQ0EsVUFBSTtBQUNGLGNBQU1DLFNBQVNwQixLQUFLcUIsSUFBTCxDQUFVL0MsSUFBVixFQUFnQjJDLEdBQWhCLEVBQXFCQyxPQUFyQixDQUFmLENBREUsQ0FFRjs7QUFDQSxlQUFPRSxNQUFQO0FBQ0QsT0FKRCxDQUlFLE9BQU9FLENBQVAsRUFBVTtBQUNWO0FBQ0FDLGdCQUFRQyxHQUFSLENBQVlGLENBQVosRUFGVSxDQUVLOztBQUNmLGVBQU9BLENBQVA7QUFDRDtBQUNGLEtBMUJZOztBQTJCYmtHLGtCQUFjeEcsVUFBZCxFQUF5Qk4sT0FBekIsRUFBa0M7QUFDaEMsVUFBSTJCLFVBQVVFLEtBQUtDLEtBQUwsQ0FBVyxJQUFJakUsSUFBSixHQUFXa0UsT0FBWCxLQUF1QixJQUFsQyxDQUFkO0FBQ0EsVUFBSTVCLFdBQVcsSUFBSXRDLElBQUosRUFBZjtBQUNBK0gsZ0JBQVVwSCxNQUFWLENBQWlCO0FBQ2JvSSxrQkFBVTtBQUNSeEosZ0JBQU1rRCxVQURFO0FBRVJOLG1CQUFTQSxPQUZEO0FBR1JFLHVCQUFheUIsT0FITDtBQUlSeEIsb0JBQVVBO0FBSkY7QUFERyxPQUFqQjtBQVFFMUIsWUFBTUMsZUFBTixDQUFzQlYsT0FBT1csTUFBUCxFQUF0QixFQUF1QyxVQUF2QztBQUNILEtBdkNZOztBQXdDYm9JLG1CQUFlbEksSUFBZixFQUFxQkMsUUFBckIsRUFBK0I7QUFDN0JDLFlBQU1GLElBQU4sRUFBWUcsTUFBWjtBQUNBLFVBQUlyQixjQUFjLElBQUlFLElBQUosRUFBbEI7O0FBQ0EsVUFBR0csT0FBT1csTUFBUCxFQUFILEVBQW9CO0FBQ2xCLFlBQUdHLFlBQVksU0FBZixFQUEwQjtBQUN4QjhHLG9CQUFVM0csTUFBVixDQUFpQkosS0FBS0ssR0FBdEIsRUFBMkI7QUFDekJDLGtCQUFNO0FBQ0osK0JBQWlCO0FBRGIsYUFEbUI7QUFJekJDLGtCQUFNO0FBQ0p6QjtBQURJO0FBSm1CLFdBQTNCO0FBUUQ7O0FBQ0RjLGNBQU1DLGVBQU4sQ0FBc0JWLE9BQU9XLE1BQVAsRUFBdEIsRUFBdUMsT0FBdkM7QUFDRDtBQUNGLEtBeERZOztBQXlEYixrQkFBYyxZQUFVO0FBQ3RCLFVBQUlxSSxZQUFZLE1BQUk7QUFDbEJDLHNCQUFjLFVBQVVDLENBQVYsRUFBYTtBQUN2QjtBQUNBLGlCQUFPQSxJQUFJLFFBQVg7QUFDSCxTQUhEOztBQUlBLFlBQUlDLFVBQVdDLE9BQUQsSUFBVztBQUN2QixjQUFJQyxXQUFXLElBQUl4SixJQUFKLEVBQWY7QUFDQSxjQUFJeUosZ0JBQWdCLElBQUl6SixJQUFKLENBQVN3SixXQUFXSixZQUFZRyxPQUFaLENBQXBCLENBQXBCO0FBQ0FFLDBCQUFnQkEsY0FBY0MsV0FBZCxHQUE0QkMsS0FBNUIsQ0FBa0MsR0FBbEMsQ0FBaEI7QUFDQSxpQkFBT0YsY0FBYyxDQUFkLENBQVA7QUFDRCxTQUxEOztBQU1BLFlBQUlHLElBQUksSUFBSTVKLElBQUosRUFBUjtBQUNBLFlBQUk2SixRQUFRUCxRQUFRLENBQVIsQ0FBWjtBQUNBLFlBQUlRLFlBQVlSLFFBQVEsQ0FBUixDQUFoQjtBQUNBLFlBQUlTLGdCQUFnQlQsUUFBUU0sRUFBRUksTUFBRixLQUFhLENBQXJCLENBQXBCO0FBQ0EsWUFBSUMsY0FBY1gsUUFBUSxJQUFJTSxFQUFFSSxNQUFGLEVBQVosQ0FBbEI7QUFDQSxZQUFJRSxrQkFBa0I7QUFDbEJMLGlCQUFPO0FBQ0hNLG1CQUFPTixLQURKO0FBRUhPLGlCQUFLUDtBQUZGLFdBRFc7QUFLbEJDLHFCQUFXO0FBQ1BLLG1CQUFPTCxTQURBO0FBRVBNLGlCQUFLUDtBQUZFLFdBTE87QUFTbEJRLG9CQUFVO0FBQ05GLG1CQUFPSixhQUREO0FBRU5LLGlCQUFLSDtBQUZDO0FBVFEsU0FBdEI7QUFjQSxlQUFPQyxlQUFQO0FBQ0QsT0EvQkQ7O0FBZ0NBLGFBQU9mLFdBQVA7QUFDRCxLQTNGWTtBQTRGYixvQkFBZ0IsVUFBU21CLFFBQVQsRUFBa0I7QUFDaEMsVUFBSUMsU0FBU3BLLE9BQU9xSyxTQUFQLENBQWlCNUIsSUFBSTJCLE1BQXJCLENBQWI7QUFBQSxVQUNBRSxLQUFLRixPQUFPRCxRQUFQLENBREw7QUFFQXRILGNBQVFDLEdBQVIsQ0FBWXdILEVBQVo7QUFDQSxhQUFPQSxFQUFQO0FBQ0Q7QUFqR1ksR0FBZjtBQW1HRDs7QUFsSkQzTCxPQUFPMEMsYUFBUCxDQW9KZXVHLFNBcEpmLEU7Ozs7Ozs7Ozs7O0FDQUEsSUFBSXRHLElBQUo7QUFBUzNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ3lDLE9BQUt4QyxDQUFMLEVBQU87QUFBQ3dDLFdBQUt4QyxDQUFMO0FBQU87O0FBQWhCLENBQXBDLEVBQXNELENBQXREO0FBQXlELElBQUlrQixNQUFKO0FBQVdyQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNtQixTQUFPbEIsQ0FBUCxFQUFTO0FBQUNrQixhQUFPbEIsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJSixLQUFKO0FBQVVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0gsUUFBTUksQ0FBTixFQUFRO0FBQUNKLFlBQU1JLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUMsWUFBSjtBQUFpQkosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRyxVQUFRRixDQUFSLEVBQVU7QUFBQ0MsbUJBQWFELENBQWI7QUFBZTs7QUFBM0IsQ0FBckMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSXlDLE9BQUo7QUFBWTVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxTQUFSLENBQWIsRUFBZ0M7QUFBQ0csVUFBUUYsQ0FBUixFQUFVO0FBQUN5QyxjQUFRekMsQ0FBUjtBQUFVOztBQUF0QixDQUFoQyxFQUF3RCxDQUF4RDtBQUEyRCxJQUFJMEMsS0FBSjtBQUFVN0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLE9BQVIsQ0FBYixFQUE4QjtBQUFDRyxVQUFRRixDQUFSLEVBQVU7QUFBQzBDLFlBQU0xQyxDQUFOO0FBQVE7O0FBQXBCLENBQTlCLEVBQW9ELENBQXBEO0FBQXVELElBQUkyQyxRQUFKO0FBQWE5QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDRyxVQUFRRixDQUFSLEVBQVU7QUFBQzJDLGVBQVMzQyxDQUFUO0FBQVc7O0FBQXZCLENBQTlDLEVBQXVFLENBQXZFO0FBQTdiNEMsUUFBUUMsR0FBUixDQUFZQyw0QkFBWixHQUEyQyxHQUEzQztBQVNBO0FBQ0EsTUFBTTJJLG9CQUFvQixJQUFJN0wsTUFBTVEsVUFBVixDQUFxQixtQkFBckIsQ0FBMUI7QUFFQSxNQUFNNkMseUJBQXlCLElBQUloRCxZQUFKLENBQWtCO0FBQy9DaUQsV0FBUztBQUNQcEMsVUFBTW9CLE1BREM7QUFFUGlCLGNBQVU7QUFGSCxHQURzQztBQUsvQ0MsZUFBYW5ELGFBQWFRLE9BTHFCO0FBTS9DNEMsWUFBVztBQUNUdkMsVUFBTUM7QUFERztBQU5vQyxDQUFsQixDQUEvQjtBQVlBLE1BQU0ySywwQkFBMEIsSUFBSXpMLFlBQUosQ0FBa0I7QUFDaERzRCxZQUFVTjtBQURzQyxDQUFsQixDQUFoQztBQUlBd0ksa0JBQWtCeEssWUFBbEIsQ0FBK0J5Syx1QkFBL0I7O0FBR0EsSUFBSXhLLE9BQU9DLFFBQVgsRUFBcUI7QUFLbkJELFNBQU9NLE9BQVAsQ0FBZSxFQUFmO0FBR0Q7O0FBdkNEM0IsT0FBTzBDLGFBQVAsQ0EwQ2VrSixpQkExQ2YsRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJakosSUFBSjtBQUFTM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDeUMsT0FBS3hDLENBQUwsRUFBTztBQUFDd0MsV0FBS3hDLENBQUw7QUFBTzs7QUFBaEIsQ0FBcEMsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSWtCLE1BQUo7QUFBV3JCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ21CLFNBQU9sQixDQUFQLEVBQVM7QUFBQ2tCLGFBQU9sQixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlKLEtBQUo7QUFBVUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSCxRQUFNSSxDQUFOLEVBQVE7QUFBQ0osWUFBTUksQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJQyxZQUFKO0FBQWlCSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNHLFVBQVFGLENBQVIsRUFBVTtBQUFDQyxtQkFBYUQsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJeUMsT0FBSjtBQUFZNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFNBQVIsQ0FBYixFQUFnQztBQUFDRyxVQUFRRixDQUFSLEVBQVU7QUFBQ3lDLGNBQVF6QyxDQUFSO0FBQVU7O0FBQXRCLENBQWhDLEVBQXdELENBQXhEO0FBQTJELElBQUkwQyxLQUFKO0FBQVU3QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsT0FBUixDQUFiLEVBQThCO0FBQUNHLFVBQVFGLENBQVIsRUFBVTtBQUFDMEMsWUFBTTFDLENBQU47QUFBUTs7QUFBcEIsQ0FBOUIsRUFBb0QsQ0FBcEQ7QUFBdUQsSUFBSTJKLEdBQUo7QUFBUTlKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxLQUFSLENBQWIsRUFBNEI7QUFBQ0csVUFBUUYsQ0FBUixFQUFVO0FBQUMySixVQUFJM0osQ0FBSjtBQUFNOztBQUFsQixDQUE1QixFQUFnRCxDQUFoRDtBQUF4YjRDLFFBQVFDLEdBQVIsQ0FBWUMsNEJBQVosR0FBMkMsR0FBM0M7QUFVQTtBQUNBLE1BQU02SSx1QkFBdUIsSUFBSS9MLE1BQU1RLFVBQVYsQ0FBcUIsc0JBQXJCLENBQTdCO0FBRUEsTUFBTXdMLDRCQUE0QixJQUFJM0wsWUFBSixDQUFrQjtBQUNsRGlELFdBQVM7QUFDUHBDLFVBQU1vQixNQURDO0FBRVBpQixjQUFVO0FBRkgsR0FEeUM7QUFLbERDLGVBQWFuRCxhQUFhUSxPQUx3QjtBQU1sRDRDLFlBQVc7QUFDVHZDLFVBQU1DO0FBREc7QUFOdUMsQ0FBbEIsQ0FBbEM7QUFXQSxNQUFNOEssNkJBQTZCLElBQUk1TCxZQUFKLENBQWtCO0FBQ25ENkwsaUJBQWVGO0FBRG9DLENBQWxCLENBQW5DO0FBSUFELHFCQUFxQjFLLFlBQXJCLENBQWtDNEssMEJBQWxDOztBQVNBLElBQUkzSyxPQUFPQyxRQUFYLEVBQXFCO0FBRXJCOzs7Ozs7Ozs7SUFZRUQsT0FBT00sT0FBUCxDQUFlLEVBQWY7QUFHRDs7QUF0REQzQixPQUFPMEMsYUFBUCxDQXdEZW9KLG9CQXhEZixFOzs7Ozs7Ozs7OztBQ0FBSSxTQUFTQyxZQUFULENBQXNCLENBQUN0SSxPQUFELEVBQVV1SSxJQUFWLEtBQW1CO0FBQ3ZDO0FBQ0EsTUFBRy9LLE9BQU9pRSxRQUFQLENBQWdCK0csTUFBaEIsQ0FBdUJDLE9BQXZCLENBQStCekksUUFBUTBJLEtBQXZDLElBQWdELENBQUMsQ0FBcEQsRUFBd0Q7QUFDdERILFNBQUtJLEtBQUwsR0FBWSxDQUFDLE9BQUQsQ0FBWjtBQUNEOztBQUNELFNBQU9KLElBQVA7QUFDRCxDQU5ELEU7Ozs7Ozs7Ozs7Ozs7QUNBQXBNLE9BQU95TSxNQUFQLENBQWM7QUFBQ0MsZUFBWSxNQUFJQTtBQUFqQixDQUFkO0FBQTZDLElBQUlyTCxNQUFKO0FBQVdyQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNtQixTQUFPbEIsQ0FBUCxFQUFTO0FBQUNrQixhQUFPbEIsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJK0MsZ0JBQUo7QUFBcUJsRCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNHLFVBQVFGLENBQVIsRUFBVTtBQUFDK0MsdUJBQWlCL0MsQ0FBakI7QUFBbUI7O0FBQS9CLENBQXBDLEVBQXFFLENBQXJFOztBQUc1SSxJQUFJdU0sY0FBYyxNQUFJO0FBQ3BCLE1BQUlDLFdBQVcsS0FBZjtBQUNBLE1BQUlDLFVBQVUsQ0FBZDtBQUNBLFFBQU16RCxZQUFOOztBQUNBLFFBQU1uRSxVQUFXQyxPQUFELElBQVk7QUFDMUIsV0FBT0MsS0FBS0MsS0FBTCxDQUFXLElBQUlqRSxJQUFKLEdBQVdrRSxPQUFYLEtBQXVCSCxPQUFsQyxDQUFQO0FBQ0QsR0FGRDs7QUFHQSxRQUFNekIsV0FBVyxJQUFJdEMsSUFBSixFQUFqQjtBQUNBLFFBQU1tRSxVQUFVaEUsT0FBT2lFLFFBQVAsQ0FBZ0JDLE9BQWhCLENBQXdCQyxNQUF4QixDQUErQkMsS0FBL0IsR0FBdUNwRSxPQUFPaUUsUUFBUCxDQUFnQkMsT0FBaEIsQ0FBd0JDLE1BQXhCLENBQStCSCxPQUF0RSxHQUFnRmhFLE9BQU9pRSxRQUFQLENBQWdCSSxNQUFoQixDQUF1QkMsV0FBdkIsQ0FBbUNOLE9BQW5JO0FBQ0EsUUFBTUksUUFBUXBFLE9BQU9pRSxRQUFQLENBQWdCQyxPQUFoQixDQUF3QkMsTUFBeEIsQ0FBK0JDLEtBQS9CLEdBQXVDcEUsT0FBT2lFLFFBQVAsQ0FBZ0JDLE9BQWhCLENBQXdCQyxNQUF4QixDQUErQkMsS0FBdEUsR0FBOEVwRSxPQUFPaUUsUUFBUCxDQUFnQkksTUFBaEIsQ0FBdUJDLFdBQXZCLENBQW1DRixLQUEvSDtBQUNBLFFBQU1HLFFBQVF2RSxPQUFPaUUsUUFBUCxDQUFnQkMsT0FBaEIsQ0FBd0JDLE1BQXhCLENBQStCQyxLQUEvQixHQUF1Q3BFLE9BQU9pRSxRQUFQLENBQWdCQyxPQUFoQixDQUF3QkMsTUFBeEIsQ0FBK0JJLEtBQXRFLEdBQThFdkUsT0FBT2lFLFFBQVAsQ0FBZ0JJLE1BQWhCLENBQXVCQyxXQUF2QixDQUFtQ0MsS0FBL0g7QUFDQSxRQUFNaUgsY0FBYztBQUNsQkMsY0FBVSxFQURRO0FBRWxCSCxjQUFTLEtBRlM7QUFHbEJJLFdBQU8sVUFBU3BCLEVBQVQsRUFBWTtBQUNqQixVQUFJLEtBQUtnQixRQUFMLEtBQWtCLEtBQXRCLEVBQTRCO0FBQzFCLGFBQUtBLFFBQUwsR0FBZ0JoQixLQUFHLEtBQUgsR0FBU3RDLE9BQU9DLEVBQVAsRUFBekIsQ0FEMEIsQ0FFMUI7O0FBQ0EsZUFBTyxLQUFLcUQsUUFBWjtBQUNELE9BSkQsTUFJTztBQUNMO0FBQ0EsZUFBTyxLQUFLQSxRQUFaO0FBQ0Q7QUFDRjtBQVppQixHQUFwQjs7QUFjQSxRQUFNSyxXQUFZck0sS0FBRCxJQUFTO0FBQ3hCLFdBQU91QyxpQkFBaUIrSixPQUFqQixDQUF5QjtBQUFDLDZCQUFzQnRNO0FBQXZCLEtBQXpCLENBQVA7QUFDRCxHQUZEOztBQUdBLFFBQU11TSxtQkFBbUIsTUFBSTtBQUMzQixXQUFPaEssaUJBQWlCMUIsSUFBakIsR0FBd0IyTCxLQUF4QixFQUFQO0FBQ0QsR0FGRDs7QUFHQWpKLFVBQVFDLEdBQVIsQ0FBWSxxQkFBWixFQUFrQytJLGtCQUFsQztBQUNBLFFBQU1ySCxjQUFjLG1CQUFwQjtBQUNBLFFBQU1DLFVBQVVULFVBQVVRLFdBQTFCO0FBQ0EsUUFBTUUsZ0JBQWdCLGdCQUF0QjtBQUNBLFFBQU1DLFlBQVlYLFVBQVVVLGFBQTVCO0FBQ0EsUUFBTUUsb0JBQW9CO0FBQ3hCQyxhQUFTO0FBQUUsc0JBQWdCO0FBQWxCLEtBRGU7QUFFeEJDLFVBQU07QUFBQ0MsZ0JBQVVYLEtBQVg7QUFBa0JZLGdCQUFVVDtBQUE1QixLQUZrQixDQUkxQjs7QUFKMEIsR0FBMUI7QUFLQSxRQUFNd0gsdUJBQXVCLENBQ3pCLHFLQUR5QixDQUE3QjtBQUdBLE1BQUlDLGlCQUFpQix3QkFBckI7QUFDQSxNQUFJQyxhQUFhakksVUFBVWdJLGNBQTNCO0FBQ0EsTUFBSTlHLG9CQUFvQixDQUF4QjtBQUNBLE1BQUlDLHVCQUF1QixDQUEzQjtBQUNBLE1BQUlDLGdCQUFnQixFQUFwQjs7QUFFQSxRQUFNOEcsbUJBQW9CQyxVQUFELElBQWU7QUFDdEMsUUFBSUEsZUFBZSxHQUFuQixFQUF3QjtBQUN0QixhQUFPLENBQVA7QUFDRCxLQUZELE1BRU87QUFDTCxhQUFPLENBQVA7QUFDRDtBQUNGLEdBTkQ7O0FBT0EsUUFBTUMsYUFBYSxNQUFLO0FBQ3RCLFdBQU8sSUFBSXZNLElBQUosR0FBV2tFLE9BQVgsRUFBUDtBQUNELEdBRkQ7O0FBR0EsUUFBTXNJLGtCQUFtQkMsVUFBRCxJQUFlO0FBQ3JDLFFBQUlDLFdBQVcsSUFBSTFNLElBQUosQ0FBU3lNLFVBQVQsQ0FBZixDQURxQyxDQUVyQzs7QUFDQSxXQUFPQyxTQUFTeEksT0FBVCxFQUFQO0FBQ0QsR0FKRDs7QUFLQSxRQUFNc0IsY0FBZUMsT0FBRCxJQUFhO0FBQy9CLFVBQU1oRCxhQUFhLE1BQUk7QUFDckIsWUFBTWlELGNBQWMsQ0FBQ0MsV0FBRCxFQUFhQyxjQUFiLEtBQStCO0FBQ2pEUCw0QkFBb0J2QixRQUFRLElBQVIsSUFBZ0I2QixXQUFwQztBQUNBTCwrQkFBdUJ4QixRQUFRLElBQVIsSUFBZ0I4QixjQUF2QyxDQUZpRCxDQUdqRDtBQUNBO0FBQ0QsT0FMRDs7QUFNQSxVQUFJUCxzQkFBc0IsQ0FBdEIsSUFBMkJDLHlCQUF5QixDQUF4RCxFQUEyRDtBQUN6RCxZQUFJTyxjQUFjMUYsT0FBTzJDLElBQVAsQ0FBWSxZQUFaLEVBQTBCLE1BQTFCLEVBQWlDZ0MsU0FBakMsRUFBMkNDLGlCQUEzQyxDQUFsQjs7QUFDQSxZQUFJYyxZQUFZWixJQUFaLENBQWlCYSxRQUFqQixDQUEwQkMsYUFBMUIsS0FBNENDLFNBQWhELEVBQTJEO0FBQ3pEVCwwQkFBZ0JNLFlBQVlaLElBQVosQ0FBaUJhLFFBQWpCLENBQTBCQyxhQUExQztBQUNBTCxzQkFBWSxJQUFaLEVBQWlCLEtBQWpCO0FBQ0ExQyxrQkFBUUMsR0FBUixDQUFZLGtCQUFaLEVBQStCc0MsYUFBL0I7QUFDQXZDLGtCQUFRQyxHQUFSLENBQVksOENBQVosRUFBMkRhLFFBQVEsSUFBUixJQUFjLElBQWQsR0FBbUJ1QixpQkFBbkIsR0FBcUMsR0FBckMsR0FBeUNDLG9CQUFwRztBQUNBLGlCQUFPTyxZQUFZWixJQUFaLENBQWlCYSxRQUFqQixDQUEwQkMsYUFBakM7QUFDRCxTQU5ELE1BTU87QUFDTCxpQkFBTyxJQUFQO0FBQ0Q7QUFFRixPQVpELE1BWU8sSUFBSWpDLFFBQVEsSUFBUixLQUFpQnVCLGlCQUFqQixJQUFzQ3ZCLFFBQVEsSUFBUixLQUFpQndCLG9CQUEzRCxFQUFnRjtBQUNyRixZQUFJTyxjQUFjMUYsT0FBTzJDLElBQVAsQ0FBWSxZQUFaLEVBQTBCLE1BQTFCLEVBQWlDZ0MsU0FBakMsRUFBMkNDLGlCQUEzQyxDQUFsQjtBQUNBUSx3QkFBZ0JNLFlBQVlaLElBQVosQ0FBaUJhLFFBQWpCLENBQTBCQyxhQUExQztBQUNBTCxvQkFBWSxJQUFaLEVBQWlCLEtBQWpCO0FBQ0ExQyxnQkFBUUMsR0FBUixDQUFZLDRDQUFaLEVBQXlEc0MsYUFBekQ7QUFDQXZDLGdCQUFRQyxHQUFSLENBQVksOENBQVosRUFBMkRhLFFBQVEsSUFBUixJQUFjLElBQWQsR0FBbUJ1QixpQkFBbkIsR0FBcUMsR0FBckMsR0FBeUNDLG9CQUFwRztBQUNBLGVBQU9PLFlBQVlaLElBQVosQ0FBaUJhLFFBQWpCLENBQTBCQyxhQUFqQztBQUNELE9BUE0sTUFPQTtBQUNMO0FBQ0E7QUFDQSxlQUFPUixhQUFQO0FBQ0Q7QUFDRixLQS9CRDs7QUFnQ0EsVUFBTVUsYUFBYTtBQUNqQmpCLGVBQVM7QUFDUCx3QkFBZ0Isa0JBRFQ7QUFFUCx3QkFBZ0J2QztBQUZULE9BRFE7QUFLakJ3QyxZQUFNUTtBQUxXLEtBQW5CO0FBT0EsV0FBT1EsVUFBUDtBQUNELEdBekNEOztBQTJDQSxRQUFNMEcsZ0JBQWdCLENBQUNDLE1BQUQsRUFBUWxLLEdBQVIsRUFBWUMsT0FBWixLQUF1QjtBQUMzQyxVQUFNa0ssZUFBZTFNLE9BQU8yQyxJQUFQLENBQVksYUFBWixFQUEyQjhKLE1BQTNCLEVBQWtDbEssR0FBbEMsRUFBc0NDLE9BQXRDLENBQXJCO0FBQ0EsVUFBTW1LLFdBQVdELFlBQWpCOztBQUNBLFFBQUlDLFNBQVNSLFVBQVQsS0FBd0IsR0FBNUIsRUFBaUM7QUFDL0I7QUFDQTtBQUNBLGFBQU9RLFNBQVM3SCxJQUFULENBQWNhLFFBQXJCO0FBQ0QsS0FKRCxNQUlPO0FBQ0wsYUFBT2dILFFBQVA7QUFDRDtBQUNGLEdBVkQsQ0E1R29CLENBdUhwQjtBQUNBOzs7QUFFQSxXQUFlakgsV0FBZixDQUEyQitHLE1BQTNCLEVBQWtDbEssR0FBbEMsRUFBc0NDLE9BQXRDO0FBQUEsb0NBQThDO0FBQzVDLFlBQU1vSyw0QkFBb0I1TSxPQUFPMkMsSUFBUCxDQUFZLGFBQVosRUFBMkI4SixNQUEzQixFQUFrQ2xLLEdBQWxDLEVBQXNDQyxPQUF0QyxDQUFwQixDQUFOO0FBQ0EsWUFBTTZJLDRCQUFvQnVCLFdBQXBCLENBQU4sQ0FGNEMsQ0FHNUM7O0FBQ0EsVUFBSSxjQUFNdkIsWUFBWWMsVUFBbEIsTUFBaUMsR0FBckMsRUFBMEM7QUFDeEM7QUFDQSw2QkFBYW5KLFFBQVE2SixHQUFSLENBQVl4QixZQUFZdkcsSUFBWixDQUFpQmEsUUFBakIsQ0FBMEJtSCxHQUExQixDQUE4QixDQUFDaEksSUFBRCxFQUFNaUksS0FBTixLQUFjO0FBQ25FO0FBQ0E7QUFDQSxnQkFBTUMsc0JBQXNCbEksS0FBS2tJLG1CQUFqQztBQUNBLGdCQUFNQyxXQUFXbkksS0FBS21ELEVBQXRCO0FBQ0EsZ0JBQU1pRixpQkFBaUJwSSxLQUFLb0ksY0FBNUI7QUFDQSxnQkFBTUMsWUFBWXRMLGlCQUFpQjFCLElBQWpCLENBQXNCO0FBQUMsb0RBQXVDNk07QUFBeEMsV0FBdEIsRUFBb0ZuRixLQUFwRixFQUFsQjtBQUNBLGdCQUFNdUYsWUFBWXRJLEtBQUt1SSxRQUFMLEdBQWdCdkksS0FBS3VJLFFBQUwsQ0FBY0MsV0FBZCxFQUFoQixHQUE4QyxNQUFoRSxDQVBtRSxDQVFuRTs7QUFDQXhJLGVBQUt5SSxpQkFBTCxHQUF5QkgsU0FBekI7O0FBRUEsZ0JBQU1JLGFBQWEsTUFBSTtBQUNyQixnQkFBSTFJLEtBQUsySSxNQUFMLElBQWUsWUFBbkIsRUFBZ0M7QUFDOUIscUJBQU8zSSxLQUFLMEksVUFBTCxHQUFrQixJQUF6QjtBQUNELGFBRkQsTUFFTztBQUNMLG9CQUFNRSxpQkFBaUIxSixVQUFVLHdCQUFWLEdBQW9DLEdBQXBDLEdBQXlDYyxLQUFLbUQsRUFBOUMsR0FBaUQsT0FBeEU7QUFDQSxvQkFBTXVGLGFBQWF4TixPQUFPMkMsSUFBUCxDQUFZLGlCQUFaLEVBQThCLEtBQTlCLEVBQW9DK0ssY0FBcEMsRUFBbURsTCxPQUFuRCxDQUFuQjs7QUFDQSxrQkFBSWdMLFdBQVdyQixVQUFYLElBQXlCLEdBQTdCLEVBQWlDO0FBQy9CLG9CQUFJcUIsV0FBVzFJLElBQVgsQ0FBZ0JhLFFBQWhCLENBQXlCZ0ksTUFBekIsSUFBbUMsQ0FBdkMsRUFBeUM7QUFDdkMseUJBQU83SSxLQUFLMEksVUFBTCxHQUFrQixJQUF6QjtBQUNELGlCQUZELE1BRU87QUFDTCx5QkFBTzFJLEtBQUswSSxVQUFMLEdBQWtCQSxXQUFXMUksSUFBWCxDQUFnQmEsUUFBekM7QUFDRDtBQUNGLGVBTkQsTUFNTztBQUNMLHVCQUFPYixLQUFLMEksVUFBTCxHQUFrQixJQUF6QjtBQUNEO0FBQ0Y7QUFDRixXQWhCRDs7QUFpQkEsZ0JBQU1JLGdCQUFnQixNQUFJO0FBQ3hCLGdCQUFJLENBQUM5SSxLQUFLMkksTUFBTCxJQUFlLG1CQUFmLElBQXNDM0ksS0FBSzJJLE1BQUwsSUFBZSxTQUF0RCxLQUFvRTNJLEtBQUsrSSxTQUFMLEtBQW1CLElBQXZGLElBQStGL0ksS0FBSytJLFNBQUwsSUFBa0IsZUFBckgsRUFBcUk7QUFDbkksb0JBQU1DLG1CQUFtQjlKLFVBQVUsa0NBQVYsR0FBOEMsR0FBOUMsR0FBbURjLEtBQUttRCxFQUFqRjtBQUNBLG9CQUFNOEYsb0JBQW9CL04sT0FBTzJDLElBQVAsQ0FBWSxpQkFBWixFQUE4QixLQUE5QixFQUFvQ21MLGdCQUFwQyxFQUFxRHRMLE9BQXJELENBQTFCOztBQUNBLGtCQUFJdUwsa0JBQWtCNUIsVUFBbEIsSUFBZ0MsR0FBcEMsRUFBd0M7QUFDdEM7QUFFQTRCLGtDQUFrQmpKLElBQWxCLENBQXVCYSxRQUF2QixDQUFnQ21ILEdBQWhDLENBQW9DLENBQUNoSSxJQUFELEVBQU1pSSxLQUFOLEtBQWM7QUFDaEQsc0JBQUlqSSxLQUFLa0osTUFBTCxJQUFlLE1BQW5CLEVBQTJCO0FBQ3pCO0FBQ0E7QUFDQSx3QkFBSWIsVUFBVSxDQUFWLENBQUosRUFBaUI7QUFDZjtBQUNBO0FBQ0EsMEJBQUlBLFVBQVUsQ0FBVixFQUFhOUssUUFBYixDQUFzQkwsT0FBdEIsQ0FBOEJpTSxlQUE5QixDQUE4Q2xCLEtBQTlDLEVBQXFEaUIsTUFBckQsSUFBK0QsSUFBbkUsRUFBeUU7QUFDdkU7QUFDQTtBQUNBO0FBQ0FsSiw2QkFBS29KLFFBQUwsR0FBZ0J2SyxRQUFRLENBQVIsQ0FBaEI7QUFDRCx1QkFMRCxNQUtPLElBQUl3SixVQUFVLENBQVYsRUFBYTlLLFFBQWIsQ0FBc0JMLE9BQXRCLENBQThCaU0sZUFBOUIsQ0FBOENsQixLQUE5QyxFQUFxRGlCLE1BQXJELElBQStELE1BQW5FLEVBQTJFO0FBQ2hGO0FBQ0E7QUFDQSw0QkFBSSxPQUFPYixVQUFVLENBQVYsRUFBYTlLLFFBQWIsQ0FBc0JMLE9BQXRCLENBQThCaU0sZUFBOUIsQ0FBOENsQixLQUE5QyxFQUFxRG1CLFFBQTVELElBQXdFLFFBQTVFLEVBQXNGO0FBQ3BGO0FBQ0E7QUFDQTtBQUNBcEosK0JBQUtvSixRQUFMLEdBQWdCZixVQUFVLENBQVYsRUFBYTlLLFFBQWIsQ0FBc0JMLE9BQXRCLENBQThCaU0sZUFBOUIsQ0FBOENsQixLQUE5QyxFQUFxRG1CLFFBQXJFO0FBQ0QseUJBTEQsTUFLTyxJQUFJZixVQUFVLENBQVYsRUFBYTlLLFFBQWIsQ0FBc0JMLE9BQXRCLENBQThCaU0sZUFBOUIsQ0FBOENsQixLQUE5QyxFQUFxRG1CLFFBQXJELElBQWlFLElBQXJFLEVBQTBFO0FBQy9FO0FBQ0E7Ozs0QkFGK0UsQ0FNL0U7QUFDQXBKLCtCQUFLb0osUUFBTCxHQUFnQnZLLFFBQVEsQ0FBUixDQUFoQjtBQUNELHlCQVJNLE1BUUE7QUFDTDtBQUNBO0FBQ0E7QUFDQW1CLCtCQUFLb0osUUFBTCxHQUFnQnZLLFFBQVEsQ0FBUixDQUFoQjtBQUNEO0FBQ0Y7QUFDRjtBQUNGLG1CQW5DRCxNQW1DTztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0FtQix5QkFBS29KLFFBQUwsR0FBZ0IsSUFBaEI7QUFDRDtBQUNGLGlCQTNDRDtBQTRDQSx1QkFBT3BKLEtBQUttSixlQUFMLEdBQXVCRixrQkFBa0JqSixJQUFsQixDQUF1QmEsUUFBckQ7QUFDRDtBQUNGO0FBQ0YsV0F0REQ7O0FBdURBLGdCQUFNd0ksY0FBYyxNQUFJO0FBQ3RCLGdCQUFJLENBQUNySixLQUFLMkksTUFBTCxJQUFlLG1CQUFmLElBQXNDM0ksS0FBSzJJLE1BQUwsSUFBZSxTQUF0RCxLQUFvRTNJLEtBQUsrSSxTQUFMLEtBQW1CLElBQTNGLEVBQWdHO0FBQzlGLG9CQUFNTyxpQkFBaUJwSyxVQUFVLHFDQUFWLEdBQWlELEdBQWpELEdBQXNEYyxLQUFLbUQsRUFBbEY7QUFDQSxvQkFBTW9HLGtCQUFrQnJPLE9BQU8yQyxJQUFQLENBQVksaUJBQVosRUFBOEIsS0FBOUIsRUFBb0N5TCxjQUFwQyxFQUFtRDVMLE9BQW5ELENBQXhCOztBQUNBLGtCQUFJNkwsZ0JBQWdCbEMsVUFBaEIsSUFBOEIsR0FBbEMsRUFBc0M7QUFDcEMsdUJBQU9ySCxLQUFLd0osYUFBTCxHQUFxQkQsZ0JBQWdCdkosSUFBaEIsQ0FBcUJhLFFBQWpEO0FBQ0Q7QUFDRjtBQUNGLFdBUkQ7O0FBU0EsZ0JBQU00SSxlQUFlLENBQUNDLFlBQUQsRUFBY0MsS0FBZCxLQUFzQjtBQUN6QyxnQkFBSUMsY0FBYyxDQUFsQjs7QUFDQSxnQkFBSzVKLEtBQUsySSxNQUFMLElBQWUsbUJBQWhCLElBQXdDM0ksS0FBSytJLFNBQUwsS0FBbUIsSUFBL0QsRUFBb0U7QUFDbEUsb0JBQU1jLGFBQWNDLE9BQUQsSUFBWTtBQUM3QixvQkFBSUMsZ0JBQWdCN08sT0FBTzJDLElBQVAsQ0FBWSxpQkFBWixFQUE4QixLQUE5QixFQUFvQ2lNLE9BQXBDLEVBQTRDdkosWUFBWSxFQUFaLENBQTVDLENBQXBCO0FBQ0F4Qyx3QkFBUUMsR0FBUixDQUFZZ00sZUFBZWhLLElBQWYsQ0FBb0JhLFFBQWhDO0FBQ0EsdUJBQU9tSixlQUFlaEssSUFBZixDQUFvQmEsUUFBM0I7QUFDRCxlQUpEOztBQUtBLGtCQUFJb0osV0FBVyxDQUFYLEVBQWNDLElBQWQsSUFBcUIsWUFBekIsRUFBdUM7QUFDckM7QUFDQTtBQUNBLHNCQUFNQyxtQkFBbUI7QUFDdkIsMEJBQVEsTUFEZTtBQUV2Qiw4QkFBWVQsWUFGVztBQUd2QixpQ0FBZSxDQUFDQyxLQUFEO0FBSFEsaUJBQXpCO0FBS0Esc0JBQU14SixzQkFBc0JqQixVQUFVLGdEQUF0QyxDQVJxQyxDQVNyQztBQUNBO0FBQ0E7QUFDQTs7QUFDQSxzQkFBTWtMLDBCQUEwQmxQLE9BQU8yQyxJQUFQLENBQVksaUJBQVosRUFBOEIsTUFBOUIsRUFBcUNzQyxtQkFBckMsRUFBeURJLFlBQVk0SixnQkFBWixDQUF6RCxDQUFoQyxDQWJxQyxDQWNyQztBQUNBOztBQUNBLG9CQUFJQyx3QkFBd0IvQyxVQUF4QixJQUFzQyxHQUExQyxFQUE4QztBQUM1QztBQUNBO0FBQ0Esd0JBQU1nRCw0QkFBNEJuTCxVQUFVa0wsd0JBQXdCcEssSUFBeEIsQ0FBNkJhLFFBQTdCLENBQXNDcEQsR0FBbEYsQ0FINEMsQ0FJNUM7O0FBRUEseUJBQU91QyxLQUFLRyxtQkFBTCxHQUEyQjBKLFdBQVdRLHlCQUFYLENBQWxDO0FBQ0QsaUJBdkJvQyxDQXlCckM7OztBQUdEO0FBQ0Y7QUFFRixXQXZDRDs7QUF3Q0EsZ0JBQU1DLFdBQVlDLE1BQUQsSUFBVTtBQUN6QjtBQUNBO0FBQ0F4Tiw2QkFBaUJyQixNQUFqQixDQUF3QjtBQUN0QjZCLHdCQUFVO0FBQ1JMLHlCQUFTcU4sTUFERDtBQUVSbk4sNkJBQWF5QixRQUFRLElBQVIsQ0FGTDtBQUdSeEIsMEJBQVVBO0FBSEY7QUFEWSxhQUF4QjtBQU9ELFdBVkQ7O0FBV0EsZ0JBQU1tTixXQUFXLENBQUNDLE9BQUQsRUFBU0YsTUFBVCxFQUFnQkcsS0FBaEIsRUFBc0JDLE1BQXRCLEtBQStCO0FBQzlDNU0sb0JBQVFDLEdBQVIsQ0FBWSxVQUFaLEVBQXdCeU0sT0FBeEI7QUFDQTFNLG9CQUFRQyxHQUFSLENBQVksY0FBWixFQUE0QjBNLEtBQTVCO0FBQ0EzTSxvQkFBUUMsR0FBUixDQUFZLG1CQUFaLEVBQWlDMk0sTUFBakM7QUFDQTVOLDZCQUFpQlosTUFBakIsQ0FBd0JzTyxPQUF4QixFQUFpQztBQUMvQm5PLG9CQUFLO0FBQ0gsb0NBQW1CaU8sTUFEaEI7QUFFSCx3Q0FBdUJHLEtBRnBCO0FBR0gscUNBQW9CQztBQUhqQjtBQUQwQixhQUFqQztBQU9ELFdBWEQ7O0FBYUEsZ0JBQU1DLFVBQVUsTUFBSztBQUNyQixxQkFBZUMsZUFBZjtBQUFBLDhDQUFnQztBQUM5QixzQkFBTUMsd0JBQWdCakUsU0FBU3NCLFFBQVQsQ0FBaEIsQ0FBTjs7QUFDQSxvQkFBSSxjQUFNMkMsT0FBTixNQUFrQi9KLFNBQXRCLEVBQWlDO0FBQy9CO0FBQ0E7QUFDQWhFLG1DQUFpQnlCLE1BQWpCLENBQXdCO0FBQUMsMkNBQXNCMko7QUFBdkIsbUJBQXhCO0FBQ0FPO0FBQ0FJO0FBQ0FPO0FBQ0FpQiwyQkFBU3RLLElBQVQsRUFQK0IsQ0FRL0I7QUFDRCxpQkFURCxNQVNPLElBQUk4SyxRQUFRdk4sUUFBUixDQUFpQkwsT0FBakIsQ0FBeUJrTCxjQUF6QixJQUEyQ0EsY0FBL0MsRUFBOEQsQ0FDbkU7QUFDQTtBQUNBO0FBQ0E7QUFDRCxpQkFMTSxNQUtBO0FBQ0w7QUFDQSx3QkFBTTJDLFdBQVdELFFBQVExTyxHQUF6QixDQUZLLENBR0w7QUFDQTs7QUFDQXNNO0FBQ0FJO0FBQ0FPLGdDQVBLLENBUUw7QUFDQTs7QUFDQW1CLDJCQUFTTyxRQUFULEVBQWtCL0ssSUFBbEIsRUFBdUJuQixRQUFRLElBQVIsQ0FBdkIsRUFBcUN4QixRQUFyQztBQUNEO0FBQ0YsZUE1QkQ7QUFBQTs7QUE0QkMsYUE3Qm9CLENBOEJyQjs7QUFDQXdOO0FBQ0MsV0FoQ0Q7O0FBaUNBRDtBQUNELFNBOUx3QixDQUFaLENBQWI7QUErTEQsT0FqTUQsTUFpTU87QUFDTDdNLGdCQUFRQyxHQUFSLENBQVksZ0JBQVosRUFBOEJ1SSxXQUE5QjtBQUNEO0FBQ0YsS0F4TUQ7QUFBQTs7QUF5TUEsUUFBTXlFLE9BQU8sTUFBTTtBQUNmak4sWUFBUUMsR0FBUixDQUFZLDBDQUFaO0FBQ0FELFlBQVFDLEdBQVI7QUFFQTRDLGdCQUFZLEtBQVosRUFBa0J1RyxVQUFsQixFQUE2QjVHLFlBQVksRUFBWixDQUE3Qjs7QUFDQSxRQUFJd0csc0JBQXNCLEdBQTFCLEVBQThCO0FBQzVCaEosY0FBUUMsR0FBUixDQUFZLDBEQUFaLEVBQXVFK0ksa0JBQXZFO0FBQ0FoSixjQUFRQyxHQUFSLENBQVksa0RBQVo7QUFDQWlOLDBCQUFvQi9MLFVBQVEsZ0NBQTVCO0FBQ0EwQixrQkFBWSxLQUFaLEVBQWtCcUssaUJBQWxCLEVBQW9DMUssWUFBWSxFQUFaLENBQXBDO0FBQ0Q7QUFDSixHQVhEOztBQVlBLFFBQU0ySyxhQUFhaFEsT0FBT3NJLFdBQVAsQ0FBbUIsTUFBSTtBQUN4Q2lEO0FBQ0ExSSxZQUFRQyxHQUFSLENBQVkseUNBQVosRUFBc0R5SSxPQUF0RDtBQUNBLFdBQU91RSxNQUFQO0FBQ0QsR0FKa0IsRUFJakIsTUFKaUIsQ0FBbkI7QUFLQUE7QUFDRCxDQXJWRCxDOzs7Ozs7Ozs7OztBQ0hBblIsT0FBT3lNLE1BQVAsQ0FBYztBQUFDNkUsbUJBQWdCLE1BQUlBLGVBQXJCO0FBQXFDQyxRQUFLLE1BQUlBO0FBQTlDLENBQWQ7QUFBbUUsSUFBSWxRLE1BQUo7QUFBV3JCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ21CLFNBQU9sQixDQUFQLEVBQVM7QUFBQ2tCLGFBQU9sQixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUkyTCxvQkFBSjtBQUF5QjlMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx3QkFBUixDQUFiLEVBQStDO0FBQUNHLFVBQVFGLENBQVIsRUFBVTtBQUFDMkwsMkJBQXFCM0wsQ0FBckI7QUFBdUI7O0FBQW5DLENBQS9DLEVBQW9GLENBQXBGOztBQUd0SyxJQUFJbVIsa0JBQW1CRSxZQUFELElBQWdCO0FBQ3BDLFFBQU1qRSxtQkFBb0JDLFVBQUQsSUFBZTtBQUN0QyxRQUFJQSxlQUFlLEdBQW5CLEVBQXdCO0FBQ3RCLGFBQU8sQ0FBUDtBQUNELEtBRkQsTUFFTztBQUNMLGFBQU8sQ0FBUDtBQUNEO0FBQ0YsR0FORDs7QUFPQSxRQUFNQyxhQUFhLE1BQUs7QUFDdEIsV0FBTyxJQUFJdk0sSUFBSixHQUFXa0UsT0FBWCxFQUFQO0FBQ0QsR0FGRDs7QUFHQSxRQUFNc0ksa0JBQW1CQyxVQUFELElBQWU7QUFDckMsUUFBSUMsV0FBVyxJQUFJMU0sSUFBSixDQUFTeU0sVUFBVCxDQUFmLENBRHFDLENBRXJDOztBQUNBLFdBQU9DLFNBQVN4SSxPQUFULEVBQVA7QUFDRCxHQUpEOztBQUtBLFFBQU1xTSxrQkFBa0IsQ0FBQ0MsU0FBRCxFQUFZQyxPQUFaLEtBQXVCO0FBQzdDLFFBQUlwTyxjQUFlb08sVUFBVUQsU0FBN0I7QUFDQSxXQUFPbk8sV0FBUDtBQUNELEdBSEQ7O0FBSUEsUUFBTXFPLHNCQUFzQixDQUFDQyxPQUFELEVBQVVDLE9BQVYsS0FBcUI7QUFDL0MsUUFBSUMsWUFBWUYsVUFBVUMsT0FBMUI7QUFDQSxXQUFPQyxTQUFQO0FBQ0QsR0FIRDs7QUFJQSxRQUFNQyx3QkFBd0IsQ0FBQ0gsT0FBRCxFQUFVQyxPQUFWLEtBQXFCO0FBQ2pELFFBQUlBLFVBQVVELE9BQWQsRUFBdUI7QUFDckIsYUFBT0MsT0FBUDtBQUNELEtBRkQsTUFFTztBQUNMLGFBQU9ELE9BQVA7QUFDRDtBQUNGLEdBTkQ7O0FBT0EsUUFBTUksdUJBQXVCLENBQUNKLE9BQUQsRUFBVUMsT0FBVixLQUFxQjtBQUNoRCxRQUFJQSxVQUFVRCxPQUFkLEVBQXVCO0FBQ3JCLGFBQU9DLE9BQVA7QUFDRCxLQUZELE1BRU87QUFDTCxhQUFPRCxPQUFQO0FBQ0Q7QUFDRixHQU5EOztBQU9BLE1BQUlLLGNBQWMsQ0FBQ0MsSUFBRCxFQUFNQyxXQUFOLEVBQWtCeE8sR0FBbEIsRUFBc0J5TyxLQUF0QixFQUE0QkMsS0FBNUIsRUFBa0NDLEtBQWxDLEtBQTJDO0FBQzNELFFBQUlDLFFBQU87QUFDVEwsWUFBTUEsSUFERztBQUVUQyxtQkFBYUEsV0FGSjtBQUdUeE8sV0FBS0EsR0FISTtBQUlUNk8sa0JBQVc7QUFDVEMsMkJBQW1CTCxLQURWO0FBRVRNLDBCQUFrQk4sS0FGVDtBQUdUTywyQkFBbUIsQ0FIVjtBQUlUQyw2QkFBcUJSLEtBSlo7QUFLVFMsNEJBQW9CVDtBQUxYLE9BSkY7QUFXVHRMLG1CQUFZO0FBQ1ZnTSw0QkFBb0JULEtBRFY7QUFFVlUsZ0NBQXdCVCxLQUZkO0FBR1ZVLCtCQUF1QjtBQUhiO0FBWEgsS0FBWDtBQWlCQSxXQUFPVCxLQUFQO0FBQ0QsR0FuQkQ7O0FBb0JBLFFBQU1yQixPQUFPLE1BQU07QUFDakJLLGlCQUFhckQsR0FBYixDQUFrQmhJLElBQUQsSUFBUTtBQUN2QjtBQUNBLFlBQU0rTSxrQkFBa0IsS0FBeEI7QUFDQSxZQUFNQyxlQUFlaE4sS0FBS3ZDLEdBQTFCO0FBQ0EsWUFBTXdQLG1CQUFtQixFQUF6QjtBQUNBLFlBQU1DLGNBQWM1RixZQUFwQjtBQUNBLFlBQU02RixrQkFBa0IsSUFBSXBTLElBQUosRUFBeEI7QUFDQSxZQUFNd1EsWUFBWWpFLFlBQWxCOztBQUNBLGVBQWUxRyxXQUFmLENBQTJCK0csTUFBM0IsRUFBa0NsSyxHQUFsQyxFQUFzQ0MsT0FBdEM7QUFBQSx3Q0FBOEM7QUFDNUMsZ0JBQU1vSyw0QkFBb0I1TSxPQUFPMkMsSUFBUCxDQUFZLGFBQVosRUFBMkI4SixNQUEzQixFQUFrQ2xLLEdBQWxDLEVBQXNDQyxPQUF0QyxDQUFwQixDQUFOO0FBQ0EsZ0JBQU0wUCwyQkFBbUJ0RixXQUFuQixDQUFOOztBQUNBLDRCQUFVc0YsVUFBVixHQUFzQjtBQUNwQixrQkFBTTVCLFVBQVVsRSxZQUFoQixDQURvQixDQUVwQjtBQUNBOztBQUNBLGtCQUFNK0YsaUJBQWlCOUYsZ0JBQWdCNkYsV0FBV3JOLE9BQVgsQ0FBbUJ1TixJQUFuQyxDQUF2QixDQUpvQixDQUtwQjs7QUFDQSxrQkFBTUMsY0FBY25HLGlCQUFpQmdHLFdBQVcvRixVQUE1QixDQUFwQjtBQUNBLGtCQUFNbUcsbUJBQW1CSixXQUFXL0YsVUFBcEM7QUFDQSxrQkFBTW9HLHNCQUFzQm5DLGdCQUFnQkMsU0FBaEIsRUFBMEJDLE9BQTFCLENBQTVCLENBUm9CLENBVXBCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUVBO0FBRUE7O0FBR0Esa0JBQU1rQyxjQUFjL0gscUJBQXFCdEssSUFBckIsQ0FBMEI7QUFBQyw0Q0FBNkIyRSxLQUFLZ007QUFBbkMsYUFBMUIsRUFBb0VqSixLQUFwRSxFQUFwQixDQTlCb0IsQ0ErQnBCOztBQUVBLGtCQUFNdUgsV0FBVyxDQUFDcUQsS0FBRCxFQUFPakQsS0FBUCxFQUFha0QsS0FBYixLQUFxQjtBQUNwQztBQUNBakksbUNBQXFCakssTUFBckIsQ0FBNEI7QUFDMUJvSywrQkFBZTtBQUNiNUksMkJBQVN5USxLQURJO0FBRWJ2USwrQkFBYXNOLEtBRkE7QUFHYnJOLDRCQUFVdVE7QUFIRztBQURXLGVBQTVCO0FBT0QsYUFURDs7QUFVQSxrQkFBTXBELFdBQVcsQ0FBQ0MsT0FBRCxFQUFTb0QsTUFBVCxFQUFnQkMsTUFBaEIsRUFBdUJDLE1BQXZCLEVBQThCQyxNQUE5QixFQUFxQ0MsUUFBckMsRUFBOEM3QixLQUE5QyxFQUFvRDhCLFFBQXBELEVBQTZEeEQsS0FBN0QsRUFBbUVDLE1BQW5FLEtBQTRFO0FBQzNGaEYsbUNBQXFCeEosTUFBckIsQ0FBNEJzTyxRQUFRLEdBQVIsRUFBYXJPLEdBQXpDLEVBQThDO0FBQzVDQyxzQkFBSztBQUNILHdFQUFxRDtBQURsRCxpQkFEdUM7QUFJNUNDLHNCQUFLO0FBQ0gsd0VBQXFEdVIsTUFEbEQ7QUFFSCx1RUFBb0RDLE1BRmpEO0FBR0gsMEVBQXVEQyxNQUhwRDtBQUlILHlFQUFzREMsTUFKbkQ7QUFLSCwwRUFBdURDLFFBTHBEO0FBTUgsOEVBQTJEN0IsS0FOeEQ7QUFPSCw2RUFBMEQ4QixRQVB2RDtBQVFILCtDQUE0QnhELEtBUnpCO0FBU0gsNENBQXlCQztBQVR0QjtBQUp1QyxlQUE5QztBQWdCRCxhQWpCRDs7QUFrQkEsZ0JBQUkrQyxZQUFZN0UsTUFBWixJQUFzQixDQUExQixFQUE2QjtBQUMzQjtBQUNBLG9CQUFNc0Ysc0JBQXNCVCxZQUFZLEdBQVosRUFBaUI1SCxhQUFqQixDQUErQjVJLE9BQS9CLENBQXVDb1AsVUFBdkMsQ0FBa0RDLGlCQUE5RTtBQUNBLG9CQUFNNkIsZ0JBQWdCVixZQUFZLEdBQVosRUFBaUI1SCxhQUFqQixDQUErQjVJLE9BQS9CLENBQXVDb1AsVUFBdkMsQ0FBa0RJLG1CQUF4RTtBQUNBLG9CQUFNMkIsZUFBZVgsWUFBWSxHQUFaLEVBQWlCNUgsYUFBakIsQ0FBK0I1SSxPQUEvQixDQUF1Q29QLFVBQXZDLENBQWtESyxrQkFBdkU7QUFDQSxvQkFBTTJCLCtCQUErQlosWUFBWSxHQUFaLEVBQWlCNUgsYUFBakIsQ0FBK0I1SSxPQUEvQixDQUF1QzBELFdBQXZDLENBQW1Ea00scUJBQW5ELEdBQTJFUyxXQUFoSDtBQUNBLG9CQUFNZ0Isb0JBQW9COUMsb0JBQW9CMEMsbUJBQXBCLEVBQXdDVixtQkFBeEMsQ0FBMUI7QUFDQSxvQkFBTWUscUJBQXFCM0Msc0JBQXNCdUMsYUFBdEIsRUFBb0NYLG1CQUFwQyxDQUEzQjtBQUNBLG9CQUFNZ0IscUJBQXFCM0MscUJBQXFCdUMsWUFBckIsRUFBa0NaLG1CQUFsQyxDQUEzQjtBQUNBakQsdUJBQVNrRCxXQUFULEVBQXFCYSxpQkFBckIsRUFBdUNkLG1CQUF2QyxFQUEyRGUsa0JBQTNELEVBQ0VDLGtCQURGLEVBQ3FCakIsZ0JBRHJCLEVBQ3NDRCxXQUR0QyxFQUNrRGUsNEJBRGxELEVBRUVwQixXQUZGLEVBRWNDLGVBRmQ7QUFHRCxhQVpELE1BWU87QUFDTDtBQUNBLG9CQUFNdUIsU0FBUzNDLFlBQVkvTCxLQUFLZ00sSUFBakIsRUFBd0JoTSxLQUFLaU0sV0FBN0IsRUFBMkNqTSxLQUFLdkMsR0FBaEQsRUFBcURnUSxtQkFBckQsRUFBMEVELGdCQUExRSxFQUE0RkQsV0FBNUYsQ0FBZjtBQUNBakQsdUJBQVNvRSxNQUFULEVBQWdCeEIsV0FBaEIsRUFBNEJDLGVBQTVCO0FBQ0Q7QUFDRjtBQUNGLFNBbEZEO0FBQUE7O0FBbUZBdk0sa0JBQVltTSxlQUFaLEVBQTRCQyxZQUE1QixFQUF5Q0MsZ0JBQXpDO0FBQ0QsS0E1RkQ7QUE2RkQsR0E5RkQ7O0FBK0ZBLFFBQU0vQixhQUFhaFEsT0FBT3NJLFdBQVAsQ0FBbUIsTUFBSTtBQUN4QztBQUNBLFdBQU93SCxNQUFQO0FBQ0QsR0FIa0IsRUFHakIsS0FIaUIsQ0FBbkI7QUFJQUE7QUFDQSxNQUFJMkQsZUFBZSxjQUFuQjtBQUNBLFNBQU9BLFlBQVA7QUFDRCxDQWhLRDs7QUFpS0EsTUFBTXZELE9BQVE5USxJQUFELElBQVM7QUFDcEIsTUFBSXNVLFFBQVEsc0JBQVo7QUFDQSxNQUFJQyxRQUFRdlUsSUFBWjtBQUNBLFNBQU9zVSxTQUFTQyxLQUFoQjtBQUNELENBSkQsQzs7Ozs7Ozs7Ozs7QUNwS0FoVixPQUFPaVYsT0FBUCxHQUFpQjtBQUNmQyxhQUFXLE1BQU07QUFDZixRQUFJL08sT0FBTyxFQUFYO0FBQ0EsV0FBT0EsSUFBUDtBQUVELEdBTGM7QUFNZmdQLGFBQVcsTUFBTTtBQUNmLFFBQUloUCxPQUFPLEVBQVg7QUFDQSxXQUFPQSxJQUFQO0FBQ0QsR0FUYztBQVVmaVAsYUFBVyxNQUFNO0FBQ2YsUUFBSWpQLE9BQU8sRUFBWDtBQUNBLFdBQU9BLElBQVA7QUFDRCxHQWJjO0FBY2ZrUCxhQUFXLE1BQU07QUFDZixRQUFJbFAsT0FBTyxFQUFYO0FBQ0EsV0FBT0EsSUFBUDtBQUNEO0FBakJjLENBQWpCLEM7Ozs7Ozs7Ozs7O0FDQUEsSUFBSTlFLE1BQUo7QUFBV3JCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ21CLFNBQU9sQixDQUFQLEVBQVM7QUFBQ2tCLGFBQU9sQixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlrSixNQUFKO0FBQVdySixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNtSixTQUFPbEosQ0FBUCxFQUFTO0FBQUNrSixhQUFPbEosQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJRyxLQUFKO0FBQVVOLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxzQkFBUixDQUFiLEVBQTZDO0FBQUNHLFVBQVFGLENBQVIsRUFBVTtBQUFDRyxZQUFNSCxDQUFOO0FBQVE7O0FBQXBCLENBQTdDLEVBQW1FLENBQW5FO0FBQXNFLElBQUkwSSxTQUFKO0FBQWM3SSxPQUFPQyxLQUFQLENBQWFDLFFBQVEscUJBQVIsQ0FBYixFQUE0QztBQUFDRyxVQUFRRixDQUFSLEVBQVU7QUFBQzBJLGdCQUFVMUksQ0FBVjtBQUFZOztBQUF4QixDQUE1QyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJK0MsZ0JBQUo7QUFBcUJsRCxPQUFPQyxLQUFQLENBQWFDLFFBQVEscUJBQVIsQ0FBYixFQUE0QztBQUFDRyxVQUFRRixDQUFSLEVBQVU7QUFBQytDLHVCQUFpQi9DLENBQWpCO0FBQW1COztBQUEvQixDQUE1QyxFQUE2RSxDQUE3RTtBQUFnRixJQUFJeUwsaUJBQUo7QUFBc0I1TCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDRyxVQUFRRixDQUFSLEVBQVU7QUFBQ3lMLHdCQUFrQnpMLENBQWxCO0FBQW9COztBQUFoQyxDQUFwRCxFQUFzRixDQUF0RjtBQUF5RixJQUFJcUksZUFBSjtBQUFvQnhJLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxzQkFBUixDQUFiLEVBQTZDO0FBQUNHLFVBQVFGLENBQVIsRUFBVTtBQUFDcUksc0JBQWdCckksQ0FBaEI7QUFBa0I7O0FBQTlCLENBQTdDLEVBQTZFLENBQTdFO0FBQWdGLElBQUkyTCxvQkFBSjtBQUF5QjlMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxnQ0FBUixDQUFiLEVBQXVEO0FBQUNHLFVBQVFGLENBQVIsRUFBVTtBQUFDMkwsMkJBQXFCM0wsQ0FBckI7QUFBdUI7O0FBQW5DLENBQXZELEVBQTRGLENBQTVGO0FBQStGLElBQUkyQyxRQUFKO0FBQWE5QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsWUFBUixDQUFiLEVBQW1DO0FBQUNHLFVBQVFGLENBQVIsRUFBVTtBQUFDMkMsZUFBUzNDLENBQVQ7QUFBVzs7QUFBdkIsQ0FBbkMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSW1SLGVBQUosRUFBb0JDLElBQXBCO0FBQXlCdlIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG1DQUFSLENBQWIsRUFBMEQ7QUFBQ29SLGtCQUFnQm5SLENBQWhCLEVBQWtCO0FBQUNtUixzQkFBZ0JuUixDQUFoQjtBQUFrQixHQUF0Qzs7QUFBdUNvUixPQUFLcFIsQ0FBTCxFQUFPO0FBQUNvUixXQUFLcFIsQ0FBTDtBQUFPOztBQUF0RCxDQUExRCxFQUFrSCxDQUFsSDtBQUFxSCxJQUFJdU0sV0FBSjtBQUFnQjFNLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwrQkFBUixDQUFiLEVBQXNEO0FBQUN3TSxjQUFZdk0sQ0FBWixFQUFjO0FBQUN1TSxrQkFBWXZNLENBQVo7QUFBYzs7QUFBOUIsQ0FBdEQsRUFBc0YsRUFBdEY7QUFBMEZILE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxnQ0FBUixDQUFiO0FBQXdERixPQUFPQyxLQUFQLENBQWFDLFFBQVEsNEJBQVIsQ0FBYjtBQUFvREYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWI7QUFBZ0RGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxxQkFBUixDQUFiO0FBQTZDRixPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYjtBQUFxREYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHFCQUFSLENBQWI7QUFBNkNGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxzQkFBUixDQUFiO0FBdUIxMUNvUixnQkFBZ0JqUSxPQUFPaUUsUUFBUCxDQUFnQmdRLGFBQWhDO0FBQ0FqVSxPQUFPRSxPQUFQLENBQWUsaUJBQWYsRUFBa0MsWUFBVztBQUUzQyxNQUFJb0wsV0FBVyxLQUFmO0FBQ0EsTUFBSUMsVUFBVSxDQUFkO0FBQ0EsUUFBTXpELE9BQU8sSUFBYjtBQUNBLFFBQU0wRCxjQUFjO0FBQ2xCQyxjQUFVLEVBRFE7QUFFbEJILGNBQVMsS0FGUztBQUdsQkksV0FBTyxVQUFTcEIsRUFBVCxFQUFZO0FBQ2pCLFVBQUksS0FBS2dCLFFBQUwsS0FBa0IsS0FBdEIsRUFBNEI7QUFDMUIsYUFBS0EsUUFBTCxHQUFnQmhCLEtBQUcsS0FBSCxHQUFTdEMsT0FBT0MsRUFBUCxFQUF6QixDQUQwQixDQUUxQjs7QUFDQSxlQUFPLEtBQUtxRCxRQUFaO0FBQ0QsT0FKRCxNQUlPO0FBQ0w7QUFDQSxlQUFPLEtBQUtBLFFBQVo7QUFDRDtBQUNGO0FBWmlCLEdBQXBCOztBQWNBLFFBQU1PLG1CQUFtQixNQUFJO0FBQzNCLFdBQU9wQixxQkFBcUJ0SyxJQUFyQixHQUE0QjJMLEtBQTVCLEVBQVA7QUFDRCxHQUZEOztBQUdBLFFBQU1vSSxZQUFZLE1BQUk7QUFDcEIsV0FBT3pKLHFCQUFxQnRLLElBQXJCLEVBQVA7QUFDRCxHQUZEOztBQUlBMEMsVUFBUUMsR0FBUixDQUFZLDhCQUFaLEVBQTJDK0ksa0JBQTNDOztBQUVBLFFBQU1pRSxPQUFPLE1BQU07QUFDakIsV0FBT29FLFdBQVA7QUFDRCxHQUZEOztBQUdBLFFBQU1sRSxhQUFhaFEsT0FBT3NJLFdBQVAsQ0FBbUIsTUFBSTtBQUN4Q2lEO0FBQ0ExSSxZQUFRQyxHQUFSLENBQVksNERBQVosRUFBeUUwSSxZQUFZRSxLQUFaLENBQWtCLEtBQUt5SSxVQUFMLENBQWdCQyxhQUFsQyxDQUF6RSxFQUEwSDdJLE9BQTFIO0FBQ0EsV0FBT3VFLE1BQVA7QUFDRCxHQUprQixFQUlqQixNQUppQixDQUFuQjtBQUtBaEksT0FBS1MsTUFBTCxDQUFZLE1BQUk7QUFDZDFGLFlBQVFDLEdBQVIsQ0FBWSx5RUFBWixFQUFzRjBJLFlBQVlFLEtBQVosQ0FBa0IsS0FBS3lJLFVBQUwsQ0FBZ0JDLGFBQWxDLENBQXRGLEVBQXVJN0ksT0FBdkk7QUFDQXZMLFdBQU93SSxhQUFQLENBQXFCd0gsVUFBckI7QUFDRCxHQUhEO0FBSUEsU0FBT0YsTUFBUDtBQUNELENBekNELEUsQ0FzREE7O0FBQ0E5UCxPQUFPRSxPQUFQLENBQWUsYUFBZixFQUE4QixZQUFXO0FBQ3ZDLFNBQU9GLE9BQU9xVSxLQUFQLENBQWFsVSxJQUFiLENBQWtCO0FBQUNlLFNBQUssS0FBS29UO0FBQVgsR0FBbEIsRUFBc0M7QUFDM0NDLFlBQVE7QUFDTnBKLGFBQU87QUFERDtBQURtQyxHQUF0QyxDQUFQO0FBS0QsQ0FORDtBQVNBbkwsT0FBT0UsT0FBUCxDQUFlLFlBQWYsRUFBNkIsWUFBVztBQUN0QyxNQUFJMkwsbUJBQW1CMUUsZ0JBQWdCaEgsSUFBaEIsR0FBdUIyTCxLQUF2QixFQUF2QjtBQUNBLE1BQUluSSxVQUFVRSxLQUFLQyxLQUFMLENBQVcsSUFBSWpFLElBQUosR0FBV2tFLE9BQVgsS0FBdUIsSUFBbEMsQ0FBZDtBQUNBLE1BQUk1QixXQUFXLElBQUl0QyxJQUFKLEVBQWY7QUFDQSxNQUFJbUUsVUFBVWhFLE9BQU9pRSxRQUFQLENBQWdCQyxPQUFoQixDQUF3QnNRLEtBQXhCLENBQThCcFEsS0FBOUIsR0FBc0NwRSxPQUFPaUUsUUFBUCxDQUFnQkMsT0FBaEIsQ0FBd0JzUSxLQUF4QixDQUE4QnhRLE9BQXBFLEdBQThFaEUsT0FBT2lFLFFBQVAsQ0FBZ0JJLE1BQWhCLENBQXVCQyxXQUF2QixDQUFtQ04sT0FBL0g7QUFDQSxNQUFJSSxRQUFRcEUsT0FBT2lFLFFBQVAsQ0FBZ0JDLE9BQWhCLENBQXdCc1EsS0FBeEIsQ0FBOEJwUSxLQUE5QixHQUFzQ3BFLE9BQU9pRSxRQUFQLENBQWdCQyxPQUFoQixDQUF3QnNRLEtBQXhCLENBQThCcFEsS0FBcEUsR0FBNEVwRSxPQUFPaUUsUUFBUCxDQUFnQkksTUFBaEIsQ0FBdUJDLFdBQXZCLENBQW1DRixLQUEzSDtBQUNBLE1BQUlHLFFBQVF2RSxPQUFPaUUsUUFBUCxDQUFnQkMsT0FBaEIsQ0FBd0JzUSxLQUF4QixDQUE4QnBRLEtBQTlCLEdBQXNDcEUsT0FBT2lFLFFBQVAsQ0FBZ0JDLE9BQWhCLENBQXdCc1EsS0FBeEIsQ0FBOEJqUSxLQUFwRSxHQUE0RXZFLE9BQU9pRSxRQUFQLENBQWdCSSxNQUFoQixDQUF1QkMsV0FBdkIsQ0FBbUNDLEtBQTNIO0FBQ0EsTUFBSWtRLGlCQUFpQiwrRkFBckI7QUFDQSxNQUFJeEksYUFBYWpJLFVBQVV5USxjQUEzQjtBQUNBLE1BQUlDLGVBQWU7QUFDakI3UCxhQUFTO0FBQUUsdUJBQWlCVCxRQUFNLEdBQU4sR0FBVUcsS0FBN0I7QUFBb0MsZ0JBQVU7QUFBOUM7QUFEUSxHQUFuQjtBQUdBLE1BQUkyTixhQUFhbFMsT0FBTzJDLElBQVAsQ0FBWSxrQkFBWixFQUFnQyxLQUFoQyxFQUFzQ3NKLFVBQXRDLEVBQWlEeUksWUFBakQsQ0FBakIsQ0Fac0MsQ0FhdEM7O0FBQ0EsTUFBSUMsYUFBYXpDLFdBQVdyTCxPQUE1QixDQWRzQyxDQWV0QztBQUNBOztBQUNBOE4sZUFBYW5PLEtBQUtDLEtBQUwsQ0FBV3lMLFdBQVdyTCxPQUF0QixDQUFiOztBQUNBLE1BQUlnRixvQkFBb0IsQ0FBeEIsRUFBMEI7QUFDeEI4SSxlQUFXQyxhQUFYLENBQXlCQyxNQUF6QixDQUFnQy9ILEdBQWhDLENBQXFDaEksSUFBRCxJQUFRO0FBQzFDcUMsc0JBQWdCM0csTUFBaEIsQ0FBdUI7QUFDbkI4RyxrQkFBVTtBQUNSdEYsbUJBQVM4QyxJQUREO0FBRVI1Qyx1QkFBYXlCLE9BRkw7QUFHUnhCLG9CQUFVQTtBQUhGO0FBRFMsT0FBdkI7QUFPRCxLQVJEO0FBU0EsV0FBT2dGLGdCQUFnQmhILElBQWhCLEVBQVA7QUFDRCxHQVhELE1BV087QUFDTCxRQUFJMlUsbUJBQW1CalIsS0FBS0MsS0FBTCxDQUFXLElBQUlqRSxJQUFKLEdBQVdrRSxPQUFYLEtBQXFCLElBQWhDLENBQXZCLENBREssQ0FFTDs7QUFDQSxRQUFJZ1IsaUJBQWlCNU4sZ0JBQWdCaEgsSUFBaEIsQ0FBcUIsRUFBckIsRUFBd0I7QUFBQ0UsWUFBSztBQUFDLGdDQUF3QixDQUFDO0FBQTFCLE9BQU47QUFBbUNrVSxjQUFPO0FBQUMsZ0NBQXdCLENBQXpCO0FBQTJCclQsYUFBSTtBQUEvQixPQUExQztBQUE0RWQsYUFBTTtBQUFsRixLQUF4QixFQUE4R3lILEtBQTlHLEVBQXJCO0FBQ0EsUUFBSW1OLHNCQUFzQkQsZUFBZSxDQUFmLEVBQWtCek4sUUFBbEIsQ0FBMkJwRixXQUFyRDs7QUFDQSxRQUFJNFMsbUJBQW1CRSxtQkFBbkIsR0FBeUMsR0FBN0MsRUFBa0Q7QUFDaEQ3TixzQkFBZ0I3RCxNQUFoQixDQUF1QjtBQUFDLGdDQUF3QjtBQUFDLGtCQUFTTyxLQUFLQyxLQUFMLENBQVcsSUFBSWpFLElBQUosR0FBV2tFLE9BQVgsS0FBcUIsSUFBckIsR0FBNEIsRUFBdkM7QUFBVjtBQUF6QixPQUF2QjtBQUNBbEIsY0FBUUMsR0FBUixDQUFZLDRDQUFaO0FBQ0E2UixpQkFBV0MsYUFBWCxDQUF5QkMsTUFBekIsQ0FBZ0MvSCxHQUFoQyxDQUFxQ2hJLElBQUQsSUFBUTtBQUMxQ3FDLHdCQUFnQjNHLE1BQWhCLENBQXVCO0FBQ25COEcsb0JBQVU7QUFDUnRGLHFCQUFTOEMsSUFERDtBQUVSNUMseUJBQWF5QixPQUZMO0FBR1J4QixzQkFBVUE7QUFIRjtBQURTLFNBQXZCO0FBT0QsT0FSRDtBQVNBLGFBQU9nRixnQkFBZ0JoSCxJQUFoQixFQUFQO0FBQ0Q7O0FBQ0QsV0FBT2dILGdCQUFnQmhILElBQWhCLEVBQVA7QUFDRDtBQUNGLENBbEREO0FBeURBa0w7QUFFQXJMLE9BQU9FLE9BQVAsQ0FBZSxhQUFmLEVBQThCLFlBQVc7QUFDdkMsTUFBSW9MLFdBQVcsS0FBZjtBQUNBLE1BQUlDLFVBQVUsQ0FBZDtBQUNBLFFBQU16RCxPQUFPLElBQWI7QUFDQSxRQUFNMEQsY0FBYztBQUNsQkMsY0FBVSxFQURRO0FBRWxCSCxjQUFTLEtBRlM7QUFHbEJJLFdBQU8sVUFBU3BCLEVBQVQsRUFBWTtBQUNqQixVQUFJLEtBQUtnQixRQUFMLEtBQWtCLEtBQXRCLEVBQTRCO0FBQzFCLGFBQUtBLFFBQUwsR0FBZ0JoQixLQUFHLEtBQUgsR0FBU3RDLE9BQU9DLEVBQVAsRUFBekIsQ0FEMEIsQ0FFMUI7O0FBQ0EsZUFBTyxLQUFLcUQsUUFBWjtBQUNELE9BSkQsTUFJTztBQUNMO0FBQ0EsZUFBTyxLQUFLQSxRQUFaO0FBQ0Q7QUFDRjtBQVppQixHQUFwQjs7QUFjQSxRQUFNTyxtQkFBbUIsTUFBSTtBQUMzQixXQUFPaEssaUJBQWlCMUIsSUFBakIsR0FBd0IyTCxLQUF4QixFQUFQO0FBQ0QsR0FGRDs7QUFHQSxRQUFNb0ksWUFBWSxNQUFJO0FBQ3BCLFdBQU9yUyxpQkFBaUIxQixJQUFqQixDQUNMLEVBREssRUFFTDtBQUFDb1UsY0FBTztBQUNOLG1DQUEwQixDQURwQjtBQUVOLHFDQUE2QixDQUZ2QjtBQUdOLGlDQUF5QixDQUhuQjtBQUlOLHdDQUErQixDQUp6QjtBQUtOLGdEQUF1QyxDQUxqQztBQU1OLDRDQUFtQyxDQU43QjtBQU9OLG1DQUEwQixDQVBwQjtBQVFOLDJDQUFrQyxDQVI1QjtBQVNOLG1DQUEwQixDQVRwQjtBQVVOLHlDQUFnQyxDQVYxQjtBQVdOLCtDQUFzQyxDQVhoQztBQVlOLDhDQUFxQyxDQVovQjtBQWFOLCtCQUFzQixDQWJoQjtBQWNOLHVDQUE4QixDQWR4QjtBQWVOLHNEQUE2QyxDQWZ2QztBQWdCTiw0Q0FBbUMsQ0FoQjdCO0FBaUJOLDBDQUFpQyxDQWpCM0I7QUFrQk4sMENBQWlDO0FBbEIzQjtBQUFSLEtBRkssQ0FBUDtBQXVCRCxHQXhCRDs7QUEwQkExUixVQUFRQyxHQUFSLENBQVkscUJBQVosRUFBa0MrSSxrQkFBbEM7O0FBRUEsUUFBTWlFLE9BQU8sTUFBTTtBQUNqQixXQUFPb0UsV0FBUDtBQUNELEdBRkQ7O0FBR0EsUUFBTWxFLGFBQWFoUSxPQUFPc0ksV0FBUCxDQUFtQixNQUFJO0FBQ3hDaUQ7QUFDQTFJLFlBQVFDLEdBQVIsQ0FBWSw0Q0FBWixFQUF5RDBJLFlBQVlFLEtBQVosQ0FBa0IsS0FBS3lJLFVBQUwsQ0FBZ0JDLGFBQWxDLENBQXpELEVBQTBHN0ksT0FBMUc7QUFDQSxXQUFPdUUsTUFBUDtBQUNELEdBSmtCLEVBSWpCLE1BSmlCLENBQW5CO0FBS0FoSSxPQUFLUyxNQUFMLENBQVksTUFBSTtBQUNkMUYsWUFBUUMsR0FBUixDQUFZLHlEQUFaLEVBQXNFMEksWUFBWUUsS0FBWixDQUFrQixLQUFLeUksVUFBTCxDQUFnQkMsYUFBbEMsQ0FBdEUsRUFBdUg3SSxPQUF2SDtBQUNBdkwsV0FBT3dJLGFBQVAsQ0FBcUJ3SCxVQUFyQjtBQUNELEdBSEQ7QUFJQSxTQUFPRixNQUFQO0FBQ0QsQ0E5REQ7QUF3RUE5UCxPQUFPRSxPQUFQLENBQWUsaUJBQWYsRUFBa0MsWUFBVztBQUMzQyxNQUFJMkwsbUJBQW1CdEIsa0JBQWtCcEssSUFBbEIsR0FBeUIyTCxLQUF6QixFQUF2QjtBQUNBakosVUFBUUMsR0FBUixDQUFZOUMsT0FBTzJDLElBQVAsQ0FBWSxZQUFaLENBQVo7O0FBRUEsTUFBSWtKLG9CQUFvQixDQUF4QixFQUEwQjtBQUN4QixRQUFJb0osV0FBV3hULFFBQWYsQ0FEd0IsQ0FFeEI7QUFDQTs7QUFDQSxRQUFJeVQsT0FBT0QsU0FBU3BCLFNBQVQsRUFBWDtBQUNBLFFBQUlsUSxVQUFVRSxLQUFLQyxLQUFMLENBQVcsSUFBSWpFLElBQUosR0FBV2tFLE9BQVgsS0FBdUIsSUFBbEMsQ0FBZDtBQUNBLFFBQUk1QixXQUFXLElBQUl0QyxJQUFKLEVBQWYsQ0FOd0IsQ0FPeEI7QUFDQTtBQUNBOztBQUNBcVYsU0FBS3BJLEdBQUwsQ0FBVWhJLElBQUQsSUFBUTtBQUNmeUYsd0JBQWtCL0osTUFBbEIsQ0FBeUI7QUFDckI2QixrQkFBVTtBQUNSTCxtQkFBUzhDLElBREQ7QUFFUjVDLHVCQUFheUIsT0FGTDtBQUdSeEIsb0JBQVVBO0FBSEY7QUFEVyxPQUF6QjtBQU9ELEtBUkQsRUFWd0IsQ0FtQjFCOztBQUNBLFdBQU9vSSxrQkFBa0JwSyxJQUFsQixFQUFQO0FBQ0QsR0FyQkMsTUFxQks7QUFDTCxXQUFPb0ssa0JBQWtCcEssSUFBbEIsRUFBUDtBQUNEO0FBRUEsQ0E3QkQ7QUErQkFILE9BQU9FLE9BQVAsQ0FBZSxnQkFBZixFQUFpQyxZQUFXO0FBQzFDLE1BQUkyTCxtQkFBbUJyRSxVQUFVckgsSUFBVixHQUFpQjJMLEtBQWpCLEVBQXZCO0FBQ0FqSixVQUFRQyxHQUFSLENBQVkrSSxnQkFBWixFQUYwQyxDQUcxQzs7Ozs7Ozs7OztBQVVBLE1BQUlqTSxPQUFPLEtBQVg7QUFDQSxNQUFJb0UsVUFBVWhFLE9BQU9pRSxRQUFQLENBQWdCQyxPQUFoQixDQUF3QmlSLFFBQXhCLENBQWlDblIsT0FBL0M7QUFDQSxNQUFJSSxRQUFRcEUsT0FBT2lFLFFBQVAsQ0FBZ0JDLE9BQWhCLENBQXdCaVIsUUFBeEIsQ0FBaUMvUSxLQUE3QztBQUNBLE1BQUlHLFFBQVF2RSxPQUFPaUUsUUFBUCxDQUFnQkMsT0FBaEIsQ0FBd0JpUixRQUF4QixDQUFpQzVRLEtBQTdDO0FBQ0EsTUFBSTZRLFNBQVMsZUFBYWhSLEtBQWIsR0FBbUIsWUFBbkIsR0FBZ0NHLEtBQTdDO0FBQ0EsTUFBSWhDLE1BQU15QixVQUFRLDRJQUFSLEdBQXFKb1IsTUFBL0o7QUFDQSxNQUFJNVMsT0FBSjtBQUNBLE1BQUk2UyxLQUFKO0FBQ0EsUUFBTUMsZ0JBQWdCLEVBQXRCOztBQUNBLE1BQUd6SixvQkFBb0IsQ0FBdkIsRUFBeUI7QUFDdkJoSixZQUFRQyxHQUFSLENBQVksbUNBQVo7O0FBQ0EsVUFBTWdOLE9BQU8sTUFBTTtBQUNqQjtBQUNBLFlBQU1oTCxPQUFPeEQsS0FBS2lVLEdBQUwsQ0FBU2hULEdBQVQsRUFBY0MsT0FBZCxDQUFiO0FBQ0EsVUFBSWdULFVBQVVoUCxLQUFLQyxLQUFMLENBQVczQixLQUFLK0IsT0FBaEIsQ0FBZCxDQUhpQixDQUlqQjtBQUNBO0FBQ0E7QUFDQTs7QUFDQTJPLGNBQVFDLE9BQVIsQ0FBZ0IzSSxHQUFoQixDQUFvQixDQUFDaEksSUFBRCxFQUFNeEYsS0FBTixLQUFnQjtBQUNsQyxZQUFJb1csU0FBUzFSLFVBQVEsMERBQVIsR0FBbUV3UixRQUFRQyxPQUFSLENBQWdCblcsS0FBaEIsRUFBdUJxVyxLQUExRixHQUFnR1AsTUFBN0c7QUFDQSxZQUFJelIsVUFBVUUsS0FBS0MsS0FBTCxDQUFXLElBQUlqRSxJQUFKLEdBQVdrRSxPQUFYLEtBQXVCLElBQWxDLENBQWQ7QUFDQSxZQUFJNUIsV0FBVyxJQUFJdEMsSUFBSixFQUFmLENBSGtDLENBSWxDO0FBQ0E7QUFDQTs7QUFDQWlGLGFBQUs4USxLQUFMLEdBQWFGLE1BQWI7QUFDQWxPLGtCQUFVaEgsTUFBVixDQUFpQjtBQUNibUgsb0JBQVU7QUFDUjNGLHFCQUFTOEMsSUFERDtBQUVSNUMseUJBQWF5QixPQUZMO0FBR1J4QixzQkFBVUE7QUFIRjtBQURHLFNBQWpCO0FBT0QsT0FmRDtBQWdCRCxLQXhCRDs7QUF5QkEyTixXQTNCdUIsQ0E0QnZCOztBQUNBLFdBQU90SSxVQUFVckgsSUFBVixDQUFlLEVBQWYsRUFBa0I7QUFBQ0UsWUFBSztBQUFDLGtDQUEwQixDQUEzQjtBQUE2QixtQ0FBMkI7QUFBeEQ7QUFBTixLQUFsQixDQUFQO0FBQ0QsR0E5QkQsTUE4Qk87QUFDTHdDLFlBQVFDLEdBQVIsQ0FBWSwwQkFBWixFQURLLENBRUw7O0FBQ0EsUUFBSWdTLG1CQUFtQmpSLEtBQUtDLEtBQUwsQ0FBVyxJQUFJakUsSUFBSixHQUFXa0UsT0FBWCxLQUFxQixJQUFoQyxDQUF2QixDQUhLLENBSUw7O0FBQ0EsUUFBSWdSLGlCQUFpQnZOLFVBQVVySCxJQUFWLENBQWUsRUFBZixFQUFrQjtBQUFDRSxZQUFLO0FBQUMsZ0NBQXdCLENBQUM7QUFBMUIsT0FBTjtBQUFtQ2tVLGNBQU87QUFBQyxnQ0FBd0IsQ0FBekI7QUFBMkJyVCxhQUFJO0FBQS9CLE9BQTFDO0FBQTRFZCxhQUFNO0FBQWxGLEtBQWxCLEVBQXdHeUgsS0FBeEcsRUFBckIsQ0FMSyxDQU1MOztBQUNBLFFBQUltTixzQkFBc0JELGVBQWUsQ0FBZixFQUFrQnBOLFFBQWxCLENBQTJCekYsV0FBckQ7QUFDQVcsWUFBUUMsR0FBUixDQUFZLGdCQUFaLEVBQTZCa1MsbUJBQTdCLEVBQWlELE1BQWpELEVBQXdELGNBQXhELEVBQXVFRixtQkFBbUJFLG1CQUExRjs7QUFDQSxRQUFHRixtQkFBbUJFLG1CQUFuQixHQUF5QyxJQUE1QyxFQUFpRDtBQUMvQ25TLGNBQVFDLEdBQVIsQ0FBWSx5Q0FBWixFQUQrQyxDQUUvQzs7QUFDQTBFLGdCQUFVbEUsTUFBVixDQUFpQjtBQUFDLGdDQUF3QjtBQUFDLGtCQUFTTyxLQUFLQyxLQUFMLENBQVcsSUFBSWpFLElBQUosR0FBV2tFLE9BQVgsS0FBcUIsSUFBckIsR0FBNEIsRUFBdkM7QUFBVjtBQUF6QixPQUFqQjs7QUFDQSxZQUFNK0wsT0FBTyxNQUFNO0FBQ2pCO0FBQ0EsY0FBTWhMLE9BQU94RCxLQUFLaVUsR0FBTCxDQUFTaFQsR0FBVCxFQUFjQyxPQUFkLENBQWI7QUFDQSxZQUFJZ1QsVUFBVWhQLEtBQUtDLEtBQUwsQ0FBVzNCLEtBQUsrQixPQUFoQixDQUFkLENBSGlCLENBSWpCO0FBQ0E7QUFDQTtBQUNBOztBQUNBMk8sZ0JBQVFDLE9BQVIsQ0FBZ0IzSSxHQUFoQixDQUFvQixDQUFDaEksSUFBRCxFQUFNeEYsS0FBTixLQUFnQjtBQUNsQyxjQUFJb1csU0FBUzFSLFVBQVEsMERBQVIsR0FBbUV3UixRQUFRQyxPQUFSLENBQWdCblcsS0FBaEIsRUFBdUJxVyxLQUExRixHQUFnR1AsTUFBN0c7QUFDQSxjQUFJelIsVUFBVUUsS0FBS0MsS0FBTCxDQUFXLElBQUlqRSxJQUFKLEdBQVdrRSxPQUFYLEtBQXVCLElBQWxDLENBQWQ7QUFDQSxjQUFJNUIsV0FBVyxJQUFJdEMsSUFBSixFQUFmLENBSGtDLENBSWxDO0FBQ0E7QUFDQTs7QUFDQWlGLGVBQUs4USxLQUFMLEdBQWFGLE1BQWI7QUFDQWxPLG9CQUFVaEgsTUFBVixDQUFpQjtBQUNibUgsc0JBQVU7QUFDUjNGLHVCQUFTOEMsSUFERDtBQUVSNUMsMkJBQWF5QixPQUZMO0FBR1J4Qix3QkFBVUE7QUFIRjtBQURHLFdBQWpCO0FBT0QsU0FmRDtBQWdCRCxPQXhCRDs7QUF5QkEyTixhQTdCK0MsQ0E4Qi9DOztBQUNBLGFBQU90SSxVQUFVckgsSUFBVixDQUFlLEVBQWYsRUFBa0I7QUFBQ0UsY0FBSztBQUFDLG9DQUEwQixDQUEzQjtBQUE2QixxQ0FBMkI7QUFBeEQ7QUFBTixPQUFsQixDQUFQO0FBQ0QsS0FoQ0QsTUFnQ087QUFDTDtBQUNBLGFBQU9tSCxVQUFVckgsSUFBVixDQUFlLEVBQWYsRUFBa0I7QUFBQ0UsY0FBSztBQUFDLG9DQUEwQixDQUEzQjtBQUE2QixxQ0FBMkI7QUFBeEQ7QUFBTixPQUFsQixDQUFQO0FBQ0Q7QUFDRjtBQUNGLENBbEdEO0FBbUdBTCxPQUFPNlYsT0FBUCxDQUFlLE1BQU0sQ0FDbkI7QUFDRCxDQUZELEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcblxuY29uc3QgSXRlbXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignaXRlbXMnKTtcblxuY29uc3QgSXRlbVNjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEgKHtcbiAgdGV4dDogU3RyaW5nLFxuICB2YWx1ZTogU2ltcGxlU2NoZW1hLkludGVnZXJcbn0pO1xuXG5jb25zdCBJdGVtc1NjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEgKHtcbiAgaXRlbU9uZTogSXRlbVNjaGVtYSxcbiAgaXRlbVR3bzogSXRlbVNjaGVtYSxcbiAgbGFzdFVwZGF0ZWQgOiB7XG4gICAgdHlwZTogRGF0ZSxcbiAgICBvcHRpb25hbDogdHJ1ZVxuICB9XG59KTtcblxuSXRlbXMuYXR0YWNoU2NoZW1hKEl0ZW1zU2NoZW1hKTtcblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuXG4gIE1ldGVvci5wdWJsaXNoKCdhbGxJdGVtcycsIGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiBJdGVtcy5maW5kKHt9LCB7XG4gICAgICAvLyBsaW1pdHMgdGhlIG51bWJlciBvZiByZXR1cm4ganNvbiBpdGVtcyBmcm9tIERCXG4gICAgICBsaW1pdDogNTAsXG4gICAgICAvLyB2YWx1ZSAxIChPTERFU1QpIG9yIC0xIChORVdFU1QpIGRldGVybWluZXMgZGlyZWN0aW9ucyBvZiBsYXN0VXBkYXRlZFxuICAgICAgc29ydDoge2xhc3RVcGRhdGVkOiAtMX1cbiAgICB9KTtcbiAgfSk7XG5cblxuICBNZXRlb3IubWV0aG9kcyh7XG4gICAgaW5zZXJ0TmV3SXRlbShpdGVtT25lLGl0ZW1Ud28pIHtcbiAgICAgIEl0ZW1zLmluc2VydCh7XG4gICAgICAgICAgaXRlbU9uZToge1xuICAgICAgICAgICAgdGV4dDogaXRlbU9uZSxcbiAgICAgICAgICAgIHZhbHVlOiAwLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgaXRlbVR3bzoge1xuICAgICAgICAgICAgdGV4dDogaXRlbVR3byxcbiAgICAgICAgICAgIHZhbHVlOiAwLFxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIFJvbGVzLmFkZFVzZXJzVG9Sb2xlcyhNZXRlb3IudXNlcklkKCksICdzdW1pdHRlcicpXG4gICAgfSxcbiAgICB2b3RlT25JdGVtKGl0ZW0sIHBvc2l0aW9uKSB7XG4gICAgICBjaGVjayhpdGVtLCBPYmplY3QpO1xuICAgICAgbGV0IGxhc3RVcGRhdGVkID0gbmV3IERhdGUoKTtcbiAgICAgIGlmKE1ldGVvci51c2VySWQoKSkge1xuICAgICAgICBpZihwb3NpdGlvbiA9PSAnaXRlbU9uZScpIHtcbiAgICAgICAgICBJdGVtcy51cGRhdGUoaXRlbS5faWQsIHtcbiAgICAgICAgICAgICRpbmM6IHtcbiAgICAgICAgICAgICAgJ2l0ZW1PbmUudmFsdWUnOiAxXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgJHNldDoge1xuICAgICAgICAgICAgICBsYXN0VXBkYXRlZFxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgSXRlbXMudXBkYXRlKGl0ZW0uX2lkLCB7XG4gICAgICAgICAgICAkaW5jOiB7XG4gICAgICAgICAgICAgICdpdGVtVHdvLnZhbHVlJzogMVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgICAgbGFzdFVwZGF0ZWRcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KVxuICAgICAgICB9XG4gICAgICAgIFJvbGVzLmFkZFVzZXJzVG9Sb2xlcyhNZXRlb3IudXNlcklkKCksICd2b3RlcicpXG4gICAgICB9XG4gICAgfVxuICB9KTtcbn1cblxuXG5leHBvcnQgZGVmYXVsdCBJdGVtcztcbiIsInByb2Nlc3MuZW52Lk5PREVfVExTX1JFSkVDVF9VTkFVVEhPUklaRUQgPSAnMCc7XG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuaW1wb3J0IHJlcXVlc3QgZnJvbSAncmVxdWVzdCc7XG5pbXBvcnQgaHR0cHMgZnJvbSAnaHR0cHMnO1xuaW1wb3J0IHRlbXBEYXRhIGZyb20gJy4uLy4uL3NlcnZlci90ZW1wRGF0YSc7XG5cbi8vIGFwaWNcblxuY29uc3QgSXRlbXNBcGljRGV2aWNlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdpdGVtYXBpY2RldmljZXMnKTtcbi8vIHNpbXBsZSBzY2hlbWEgZGVidWdcblNpbXBsZVNjaGVtYS5kZWJ1ZyA9IHRydWVcbmNvbnN0IEl0ZW1UcmFuc2ZlclJhdGVTY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hICh7XG4gIGRhdGFPYmo6IHtcbiAgICB0eXBlOiBPYmplY3QsXG4gICAgYmxhY2tib3g6IHRydWVcbiAgfSxcbiAgcmVxdWVzdFRpbWU6IFNpbXBsZVNjaGVtYS5JbnRlZ2VyLFxuICBkYXRlVGltZSA6IHtcbiAgICB0eXBlOiBEYXRlXG4gIH1cbn0pO1xuXG5cbmNvbnN0IEl0ZW1zQXBpY0RldmljZXNTY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hICh7XG4gIHNpdGVEYXRhOiBJdGVtVHJhbnNmZXJSYXRlU2NoZW1hXG59KTtcblxuSXRlbXNBcGljRGV2aWNlcy5hdHRhY2hTY2hlbWEoSXRlbXNBcGljRGV2aWNlc1NjaGVtYSk7XG5cblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICBNZXRlb3IubWV0aG9kcyh7XG4gICAgYXBpY1RpY2tldCh0eXBlLCB1cmwsIG9wdGlvbnMpIHtcbiAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gSFRUUC5jYWxsKHR5cGUsIHVybCwgb3B0aW9ucyk7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHJlc3VsdCk7IC8vIGRlYnVnXG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIEdvdCBhIG5ldHdvcmsgZXJyb3IsIHRpbWVvdXQsIG9yIEhUVFAgZXJyb3IgaW4gdGhlIDQwMCBvciA1MDAgcmFuZ2UuXG4gICAgICAgIGNvbnNvbGUubG9nKGUpIC8vIGRlYnVnXG4gICAgICAgIHJldHVybiBlO1xuICAgICAgfVxuICAgIH0sXG4gICAgYXBpY0h0dHBSZXF1ZXN0KHR5cGUsIHVybCwgb3B0aW9ucykge1xuICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICB0cnkge1xuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT57XG4gICAgICAgICAgY29uc3QgcmVzdWx0ID0gSFRUUC5jYWxsKHR5cGUsIHVybCwgb3B0aW9ucyk7XG4gICAgICAgICAgLy8gY29uc29sZS5sb2cocmVzdWx0KTsgLy8gZGVidWdcbiAgICAgICAgICByZXNvbHZlKHJlc3VsdClcbiAgICAgICAgfSlcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgcmVqZWN0KGUpXG4gICAgICAgIC8vIEdvdCBhIG5ldHdvcmsgZXJyb3IsIHRpbWVvdXQsIG9yIEhUVFAgZXJyb3IgaW4gdGhlIDQwMCBvciA1MDAgcmFuZ2UuXG4gICAgICAgIGNvbnNvbGUubG9nKGUpIC8vIGRlYnVnc1xuICAgICAgfVxuICAgIH0sXG4gICAgYXBpY0RiUmVtb3ZlKGRiSUQsdXVpZCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gSXRlbXNBcGljRGV2aWNlcy5yZW1vdmUoZGJJRCk7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHJlc3VsdCk7IC8vIGRlYnVnXG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIEdvdCBhIG5ldHdvcmsgZXJyb3IsIHRpbWVvdXQsIG9yIEhUVFAgZXJyb3IgaW4gdGhlIDQwMCBvciA1MDAgcmFuZ2UuXG4gICAgICAgIGNvbnNvbGUubG9nKGUpIC8vIGRlYnVnXG4gICAgICAgIHJldHVybiBlO1xuICAgICAgfTtcbiAgICB9LFxuICAgIGFwaWNTaG93Q29tbWFuZHMoc2hvd0NvbW1hbmQsdXVpZCxkYklkKSB7XG4gICAgICB0cnkge1xuICAgICAgICBzaG93T2JqID0ge1xuICAgICAgICAgIFwibmFtZVwiOlwiZnJvc3RTaG93Q29tbWFuZFwiLFxuICAgICAgICAgIFwidGllb3V0XCI6MCxcbiAgICAgICAgICBcImRlc2NyaXB0aW9uXCI6XCJcIixcbiAgICAgICAgICBcImNvbW1hbmRzXCI6W1xuICAgICAgICAgICAgc2hvd0NvbW1hbmRcbiAgICAgICAgICBdLFxuICAgICAgICAgIFwiZGV2aWNlVXVpZHNcIjpbXG4gICAgICAgICAgICB1dWlkXG4gICAgICAgICAgXVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHRpbWVOb3cgPSAoZGl2aXNvcikgPT57XG4gICAgICAgICAgcmV0dXJuIE1hdGgucm91bmQobmV3IERhdGUoKS5nZXRUaW1lKCkgLyBkaXZpc29yKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBkYXRlVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgIGNvbnN0IGJhc2VVcmwgPSBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5hcGljRU0udU5hbWUgPyBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5hcGljRU0uYmFzZVVybCA6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2lzY29BcGljRU0uYmFzZVVybDtcbiAgICAgICAgY29uc3QgdU5hbWUgPSBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5hcGljRU0udU5hbWUgPyBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5hcGljRU0udU5hbWUgOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNpc2NvQXBpY0VNLnVOYW1lO1xuICAgICAgICBjb25zdCB1UGFzcyA9IE1ldGVvci5zZXR0aW5ncy5wcml2YXRlLmFwaWNFTS51TmFtZSA/IE1ldGVvci5zZXR0aW5ncy5wcml2YXRlLmFwaWNFTS51UGFzcyA6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2lzY29BcGljRU0udVBhc3M7XG4gICAgICAgIGNvbnN0IGFwaWNSb2xlVXJuID0gJy9hcGkvdjEvdXNlci9yb2xlJztcbiAgICAgICAgY29uc3Qgcm9sZVVybCA9IGJhc2VVcmwgKyBhcGljUm9sZVVybjtcbiAgICAgICAgY29uc3QgYXBpY1RpY2tldFVybiA9ICcvYXBpL3YxL3RpY2tldCc7XG4gICAgICAgIGNvbnN0IHRpY2tldFVybCA9IGJhc2VVcmwgKyBhcGljVGlja2V0VXJuO1xuICAgICAgICBjb25zdCBhcGljVGlja2V0T3B0aW9ucyA9IHtcbiAgICAgICAgICBoZWFkZXJzOiB7ICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgICAgICBkYXRhOiB7dXNlcm5hbWU6IHVOYW1lLCBwYXNzd29yZDogdVBhc3N9XG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IG5ldHdvcmtEZXZpY2VQb2xsZXIgPSBiYXNlVXJsICsgXCIvYXBpL3YxL25ldHdvcmstZGV2aWNlLXBvbGxlci9jbGkvcmVhZC1yZXF1ZXN0XCI7XG4gICAgICAgIGxldCB0aWNrZXRJZGxlVGltZW91dCA9IDA7XG4gICAgICAgIGxldCB0aWNrZXRTZXNzaW9uVGltZW91dCA9IDA7XG4gICAgICAgIGxldCBvbGRBcGljVGlja2V0ID0gXCJcIjtcbiAgICAgICAgLy8gY3JlYXRlcyBkYXRhQmxvYiBmb3IgYW4gSFRUUHMgcmVxdWVzdC4gY3JlYXRlcyBhbmQgcmV1c2VzIGFwaWNUaWNrZXRzLCB0aWNrZXRzIGZvciB0aGUgc2FtZSByZXF1ZXN0IGFyZSByZXVzZWQuXG4gICAgICAgIGNvbnN0IGFwaWNPcHRpb25zID0gKGJvZHlPYmopID0+IHtcbiAgICAgICAgICBjb25zdCBhcGljVGlja2V0ID0gKCk9PntcbiAgICAgICAgICAgIGNvbnN0IHNldFRpbWVvdXRzID0gKGlkbGVUaW1lb3V0LHNlc3Npb25UaW1lb3V0KSA9PntcbiAgICAgICAgICAgICAgdGlja2V0SWRsZVRpbWVvdXQgPSB0aW1lTm93KDEwMDApICsgaWRsZVRpbWVvdXQ7XG4gICAgICAgICAgICAgIHRpY2tldFNlc3Npb25UaW1lb3V0ID0gdGltZU5vdygxMDAwKSArIHNlc3Npb25UaW1lb3V0O1xuICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwiVGlja2V0IHRpbWVvdXQgPFRpbWUgTm93OiBJZGxlL1Nlc3Npb24+IFwiLHRpbWVOb3coMTAwMCkrXCI6IFwiK3RpY2tldElkbGVUaW1lb3V0K1wiL1wiK3RpY2tldFNlc3Npb25UaW1lb3V0KTtcbiAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcIlJlcXVlc3RpbmcgTmV3IHRpY2tldDogXCIsIG9sZEFwaWNUaWNrZXQpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodGlja2V0SWRsZVRpbWVvdXQgPT09IDAgJiYgdGlja2V0U2Vzc2lvblRpbWVvdXQgPT09IDAgKXtcbiAgICAgICAgICAgICAgbGV0IGh0dHBSZXF1ZXN0ID0gTWV0ZW9yLmNhbGwoJ2FwaWNUaWNrZXQnLCBcIlBPU1RcIix0aWNrZXRVcmwsYXBpY1RpY2tldE9wdGlvbnMpO1xuICAgICAgICAgICAgICBpZiAoaHR0cFJlcXVlc3QuZGF0YS5yZXNwb25zZS5zZXJ2aWNlVGlja2V0ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICBvbGRBcGljVGlja2V0ID0gaHR0cFJlcXVlc3QuZGF0YS5yZXNwb25zZS5zZXJ2aWNlVGlja2V0O1xuICAgICAgICAgICAgICAgIHNldFRpbWVvdXRzKDE4MDAsMjE2MDApO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiIyMjLU5ldyBUaWNrZXQ6IFwiLG9sZEFwaWNUaWNrZXQpXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCIjIyMtVGlja2V0IHRpbWVvdXQgPFRpbWUgTm93OiBJZGxlL1Nlc3Npb24+IFwiLHRpbWVOb3coMTAwMCkrXCI6IFwiK3RpY2tldElkbGVUaW1lb3V0K1wiL1wiK3RpY2tldFNlc3Npb25UaW1lb3V0KTtcbiAgICAgICAgICAgICAgICByZXR1cm4gaHR0cFJlcXVlc3QuZGF0YS5yZXNwb25zZS5zZXJ2aWNlVGlja2V0O1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIH0gZWxzZSBpZiAodGltZU5vdygxMDAwKSA+PSB0aWNrZXRJZGxlVGltZW91dCB8fCB0aW1lTm93KDEwMDApID49IHRpY2tldFNlc3Npb25UaW1lb3V0KXtcbiAgICAgICAgICAgICAgbGV0IGh0dHBSZXF1ZXN0ID0gTWV0ZW9yLmNhbGwoJ2FwaWNUaWNrZXQnLCBcIlBPU1RcIix0aWNrZXRVcmwsYXBpY1RpY2tldE9wdGlvbnMpO1xuICAgICAgICAgICAgICBvbGRBcGljVGlja2V0ID0gaHR0cFJlcXVlc3QuZGF0YS5yZXNwb25zZS5zZXJ2aWNlVGlja2V0O1xuICAgICAgICAgICAgICBzZXRUaW1lb3V0cygxODAwLDIxNjAwKTtcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coXCIqKiotVGlja2V0IGV4cGlyZWQgcmVxdWVzdGluZyBuZXcgVGlja2V0OiBcIixvbGRBcGljVGlja2V0KVxuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIioqKi1UaWNrZXQgdGltZW91dCA8VGltZSBOb3c6IElkbGUvU2Vzc2lvbj4gXCIsdGltZU5vdygxMDAwKStcIjogXCIrdGlja2V0SWRsZVRpbWVvdXQrXCIvXCIrdGlja2V0U2Vzc2lvblRpbWVvdXQpO1xuICAgICAgICAgICAgICByZXR1cm4gaHR0cFJlcXVlc3QuZGF0YS5yZXNwb25zZS5zZXJ2aWNlVGlja2V0O1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcIlVzaW5nIEV4aXN0aW5nIFRpY2tldDogXCIsb2xkQXBpY1RpY2tldClcbiAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcIlRpY2tldCB0aW1lb3V0IDxUaW1lIE5vdzogSWRsZS9TZXNzaW9uPiBcIix0aW1lTm93KDEwMDApK1wiOiBcIit0aWNrZXRJZGxlVGltZW91dCtcIi9cIit0aWNrZXRTZXNzaW9uVGltZW91dCk7XG4gICAgICAgICAgICAgIHJldHVybiBvbGRBcGljVGlja2V0O1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICAvLyB0aGlzIGlzIHRoZSByZXF1ZXN0IGJvZHlcbiAgICAgICAgICBjb25zdCByZXF1ZXN0T2JqID0ge1xuICAgICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgICAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAgICAgICAneC1hdXRoLXRva2VuJzogYXBpY1RpY2tldCgpXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZGF0YTogYm9keU9ialxuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gcmVxdWVzdE9iajtcbiAgICAgICAgfTtcbiAgICAgICAgY29uc29sZS5sb2coYXBpY09wdGlvbnMoc2hvd09iaikpXG4gICAgICAgIGNvbnNvbGUubG9nKCk7XG5cbiAgICAgICAgbGV0IHJlc3BvbnNlVGFza0lEID0gTWV0ZW9yLmNhbGwoJ2FwaWNIdHRwUmVxdWVzdCcsXCJQT1NUXCIsbmV0d29ya0RldmljZVBvbGxlcixhcGljT3B0aW9ucyhzaG93T2JqKSlcbiAgICAgICAgbGV0IHJlc3BvbnNlVGFza1VSTCA9IGJhc2VVcmwgKyByZXNwb25zZVRhc2tJRC5kYXRhLnJlc3BvbnNlLnVybDtcbiAgICAgICAgY29uc29sZS5sb2coXCIqKioqKlwiK3Jlc3BvbnNlVGFza1VSTCk7XG4gICAgICAgIGxldCByZXNwb25zZUZpbGVVUkwgPSBcIlwiO1xuICAgICAgICAvLyBpbml0aWFsIHN0YXRlIG9mIHRoZSB3aGlsZSBsb29wXG4gICAgICAgIGxldCB1bmRlZmluZWRDb3VudGVyID0gMDtcbiAgICAgICAgLy8gdGhlIHdoaWxlIGxvb3AgcnVucyB1bnRpbCB0aGlzIGNvbmRpdGlvbiBpcyBtZXRcbiAgICAgICAgd2hpbGUgKHVuZGVmaW5lZENvdW50ZXIgPCAzMDApe1xuICAgICAgICAgIHVuZGVmaW5lZENvdW50ZXIrKztcbiAgICAgICAgICAvLyBkZWJ1Z1xuICAgICAgICAgIC8vY29uc29sZS5sb2coXCJ3YWl0aW5nLi4uIFRyeTpcIiwgdW5kZWZpbmVkQ291bnRlcilcbiAgICAgICAgICBjb25zdCB4ID0gKCk9PntcbiAgICAgICAgICAgIGxldCBwcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCk9PntcbiAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlRmlsZUlkID0gTWV0ZW9yLmNhbGwoJ2FwaWNIdHRwUmVxdWVzdCcsXCJHRVRcIixyZXNwb25zZVRhc2tVUkwsYXBpY09wdGlvbnMoc2hvd09iaikpXG4gICAgICAgICAgICAgIHJlc29sdmUocmVzcG9uc2VGaWxlSWQpXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgcmV0dXJuIHByb21pc2U7XG4gICAgICAgICAgfVxuICAgICAgICAgIHgoKS50aGVuKChkYXRhKT0+e1xuICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhkYXRhLmRhdGEucmVzcG9uc2UucHJvZ3Jlc3MpO1xuICAgICAgICAgICAgaWYgKGRhdGEuZGF0YS5yZXNwb25zZS5wcm9ncmVzcyAhPSB1bmRlZmluZWQgJiYgZGF0YS5kYXRhLnJlc3BvbnNlLnByb2dyZXNzICE9IFwiQ0xJIFJ1bm5lciByZXF1ZXN0IGNyZWF0aW9uXCIpe1xuICAgICAgICAgICAgICAvLyB0aGlzIGJyZWFrcyB0aGUgd2hpbGUgbG9vcFxuICAgICAgICAgICAgICB1bmRlZmluZWRDb3VudGVyID0gODAwO1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlRoaXMgdG9vayB0aGlzIG1heSByZXF1ZXN0czogXCIsIHVuZGVmaW5lZENvdW50ZXIpO1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIioqKkFBQSoqIFwiLGRhdGEuZGF0YS5yZXNwb25zZS5wcm9ncmVzcyk7XG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiKioqQkJCKiogXCIsSlNPTi5wYXJzZShkYXRhLmRhdGEucmVzcG9uc2UucHJvZ3Jlc3MpKTtcbiAgICAgICAgICAgICAgbGV0IHN0cmluZ1RvSlNPTj1KU09OLnBhcnNlKGRhdGEuZGF0YS5yZXNwb25zZS5wcm9ncmVzcyk7XG4gICAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCIqKioqKiBcIixkYXRhLmRhdGEucmVzcG9uc2UpO1xuXG4gICAgICAgICAgICAgIHJlc3BvbnNlRmlsZVVSTCA9IGJhc2VVcmwgK1wiL2FwaS92MS9maWxlL1wiK3N0cmluZ1RvSlNPTi5maWxlSWQ7XG4gICAgICAgICAgICAgIC8vY29uc29sZS5sb2cocmVzcG9uc2VGaWxlVVJMKVxuXG4gICAgICAgICAgICAgIC8vcmV0dXJuIE1ldGVvci5jYWxsKCdhcGljSHR0cFJlcXVlc3QnLFwiR0VUXCIscmVzcG9uc2VGaWxlVVJMLGFwaWNPcHRpb25zKHNob3dPYmopKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zb2xlLmxvZyhcInJlc3BvbnNlRmlsZVVSTFwiLHJlc3BvbnNlRmlsZVVSTClcblxuICAgICAgICAgIGxldCBodHRwUmVzcG9uc2VGaWxlID0gTWV0ZW9yLmNhbGwoJ2FwaWNIdHRwUmVxdWVzdCcsXCJHRVRcIixyZXNwb25zZUZpbGVVUkwsYXBpY09wdGlvbnMoc2hvd09iaikpO1xuICAgICAgICAgIGNvbnNvbGUubG9nKGh0dHBSZXNwb25zZUZpbGUpXG4gICAgICAgICAgY29uc29sZS5sb2coXCIqKioqKlwiLEpTT04ucGFyc2UoaHR0cFJlc3BvbnNlRmlsZS5jb250ZW50KSlcbiAgICAgICAgICBsZXQgbWFuMiA9IEpTT04ucGFyc2UoaHR0cFJlc3BvbnNlRmlsZS5jb250ZW50KVxuICAgICAgICAgIGNvbnNvbGUubG9nKG1hbjJbMF0uY29tbWFuZFJlc3BvbnNlcylcbiAgICAgICAgICBjb25zb2xlLmxvZyhcIkRCaWRcIixkYklkKVxuICAgICAgICAgIEl0ZW1zQXBpY0RldmljZXMudXBkYXRlKGRiSWQsIHtcbiAgICAgICAgICAgICRzZXQ6e1xuICAgICAgICAgICAgICAnc2l0ZURhdGEuZGF0YU9iai5jb21tYW5kUnVubmVyJzptYW4yWzBdLmNvbW1hbmRSZXNwb25zZXMsXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuIGRiSWQ7XG5cbiAgICAgICAgIC8vY29uc29sZS5sb2coaHR0cFJlc3BvbnNlRmlsZSlcblxuICAgICAgICAvL2NvbnNvbGUubG9nKE1ldGVvci5jYWxsKCdhcGljSHR0cFJlcXVlc3QnLFwiR0VUXCIscmVzcG9uc2VGaWxlVVJMLFwiXCIpKVxuICAgICAgICAvL3JldHVybiBhcGljT3B0aW9ucyhzaG93T2JqKVxuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAvLyBHb3QgYSBuZXR3b3JrIGVycm9yLCB0aW1lb3V0LCBvciBIVFRQIGVycm9yIGluIHRoZSA0MDAgb3IgNTAwIHJhbmdlLlxuICAgICAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeShlKSkgLy8gZGVidWdcbiAgICAgICAgcmV0dXJuIGU7XG4gICAgICB9XG4gICAgfSxcbiAgICBhcGljQ2xlYXJTaG93Q29tbWFuZHMoZGJJRCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gTWV0ZW9yLnNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgSXRlbXNBcGljRGV2aWNlcy51cGRhdGUoZGJJRCwge1xuICAgICAgICAgICAgJHNldDp7XG4gICAgICAgICAgICAgICdzaXRlRGF0YS5kYXRhT2JqLmNvbW1hbmRSdW5uZXInOm51bGxcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgfSwgMzAwMDAwKTtcbiAgICAgICAgLy8gY29uc29sZS5sb2cocmVzdWx0KTsgLy8gZGVidWdcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgLy8gR290IGEgbmV0d29yayBlcnJvciwgdGltZW91dCwgb3IgSFRUUCBlcnJvciBpbiB0aGUgNDAwIG9yIDUwMCByYW5nZS5cbiAgICAgICAgY29uc29sZS5sb2coZSkgLy8gZGVidWdcbiAgICAgICAgcmV0dXJuIGU7XG4gICAgICB9O1xuICAgIH0sXG5cbiAgfSk7XG59XG5cblxuZXhwb3J0IGRlZmF1bHQgSXRlbXNBcGljRGV2aWNlcztcbiIsInByb2Nlc3MuZW52Lk5PREVfVExTX1JFSkVDVF9VTkFVVEhPUklaRUQgPSAnMCc7XG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuaW1wb3J0IHJlcXVlc3QgZnJvbSAncmVxdWVzdCc7XG5pbXBvcnQgaHR0cHMgZnJvbSAnaHR0cHMnO1xuXG4vLyBwcnRnXG5jb25zdCBJdGVtc1ByaW1lSG9zdHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignaXRlbXByaW1laG9zdHMnKTtcblxuY29uc3QgSXRlbVByaW1lSG9zdHNTY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hICh7XG4gIGRhdGFPYmo6IHtcbiAgICB0eXBlOiBPYmplY3QsXG4gICAgYmxhY2tib3g6IHRydWVcbiAgfSxcbiAgcmVxdWVzdFRpbWU6IFNpbXBsZVNjaGVtYS5JbnRlZ2VyLFxuICBkYXRlVGltZSA6IHtcbiAgICB0eXBlOiBEYXRlXG4gIH1cbn0pO1xuXG5cbmNvbnN0IEl0ZW1zUHJpbWVIb3N0c1NjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEgKHtcbiAgaG9zdERhdGE6IEl0ZW1QcmltZUhvc3RzU2NoZW1hXG59KTtcblxuSXRlbXNQcmltZUhvc3RzLmF0dGFjaFNjaGVtYShJdGVtc1ByaW1lSG9zdHNTY2hlbWEpO1xuXG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcblxuXG5cblxuICBNZXRlb3IubWV0aG9kcyh7XG4gICAgcHJpbWVIdHRwUmVxdWVzdCh0eXBlLCB1cmwsIG9wdGlvbnMpIHtcbiAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gSFRUUC5jYWxsKHR5cGUsIHVybCwgb3B0aW9ucyk7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHJlc3VsdCk7IC8vIGRlYnVnXG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIEdvdCBhIG5ldHdvcmsgZXJyb3IsIHRpbWVvdXQsIG9yIEhUVFAgZXJyb3IgaW4gdGhlIDQwMCBvciA1MDAgcmFuZ2UuXG4gICAgICAgIGNvbnNvbGUubG9nKGUpIC8vIGRlYnVnXG4gICAgICAgIHJldHVybiBlO1xuICAgICAgfVxuICAgIH0sXG4gIH0pO1xufVxuXG5cbmV4cG9ydCBkZWZhdWx0IEl0ZW1zUHJpbWVIb3N0cztcbiIsInByb2Nlc3MuZW52Lk5PREVfVExTX1JFSkVDVF9VTkFVVEhPUklaRUQgPSAnMCc7XG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuaW1wb3J0IHJlcXVlc3QgZnJvbSAncmVxdWVzdCc7XG5pbXBvcnQgaHR0cHMgZnJvbSAnaHR0cHMnO1xuXG4vLyBwcnRnXG5jb25zdCBJdGVtc1BydGcgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignaXRlbXNwcnRnJyk7XG5cbmNvbnN0IEl0ZW1QcnRnU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSAoe1xuICBkYXRhT2JqOiB7XG4gICAgdHlwZTogT2JqZWN0LFxuICAgIGJsYWNrYm94OiB0cnVlXG4gIH0sXG4gIHJlcXVlc3RUaW1lOiBTaW1wbGVTY2hlbWEuSW50ZWdlcixcbiAgZGF0ZVRpbWUgOiB7XG4gICAgdHlwZTogRGF0ZVxuICB9XG59KTtcblxuXG5jb25zdCBJdGVtc1BydGdTY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hICh7XG4gIHBydGdEYXRhOiBJdGVtUHJ0Z1NjaGVtYVxufSk7XG5cbkl0ZW1zUHJ0Zy5hdHRhY2hTY2hlbWEoSXRlbXNQcnRnU2NoZW1hKTtcblxuXG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcblxuICBNZXRlb3IucHVibGlzaCgnYWxsQXBpY0l0ZW1zJywgZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIEl0ZW1zQXBpYy5maW5kKHt9LCB7XG4gICAgICAvLyBsaW1pdHMgdGhlIG51bWJlciBvZiByZXR1cm4ganNvbiBpdGVtcyBmcm9tIERCXG4gICAgICAvL2xpbWl0OiA1MCxcbiAgICAgIC8vIHZhbHVlIDEgKE9MREVTVCkgb3IgLTEgKE5FV0VTVCkgZGV0ZXJtaW5lcyBkaXJlY3Rpb25zIG9mIGxhc3RVcGRhdGVkXG4gICAgICBzb3J0OiB7XCJhcGljRGF0YS5kYXRlVGltZVwiIDogLTF9XG4gICAgfSk7XG4gIH0pO1xuXG4gIE1ldGVvci5wdWJsaXNoKCdhbGxQcnRnSXRlbXMnLCBmdW5jdGlvbigpIHtcblxuICAgIHJldHVybiBJdGVtc1BydGcuZmluZCh7fSx7c29ydDp7XCJwcnRnRGF0YS5kYXRhT2JqLmdyb3VwXCI6IDEsXCJwcnRnRGF0YS5kYXRhT2JqLmRldmljZVwiOiAxfX0pO1xuICB9KTtcblxuXG5cblxuXG4gIE1ldGVvci5tZXRob2RzKHtcbiAgICAnZ2V0UHJ0Z0RhdGEnOiBmdW5jdGlvbigpe1xuICAgICAgcmV0dXJuIEl0ZW1zUHJ0Zy5maW5kKHt9LHtzb3J0OntcInBydGdEYXRhLmRhdGFPYmouZ3JvdXBcIjogMSxcInBydGdEYXRhLmRhdGFPYmouZGV2aWNlXCI6IDF9fSkuZmV0Y2goKTtcbiAgICB9LFxuICAgICdnZXRQcnRnRGF0YUZpbHRlcmVkJzogZnVuY3Rpb24oKXtcbiAgICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuICAgICAgc2VsZi5hZGRlZCgnaXRlbXNwcnRnJyxSYW5kb20uaWQoKSx7ZGF0YX0pO1xuICAgICAgc2VsZi5yZWFkeSgpO1xuICAgICAgbGV0IG1vcmUgPSBudW07XG4gICAgICBjb25zdCBpbnRlcnZhbElEID0gTWV0ZW9yLnNldEludGVydmFsKCgpPT57XG4gICAgICAgIG1vcmUgKys7XG4gICAgICAgIHNlbGYuYWRkZWQoJ2l0ZW1zcHJ0ZycsUmFuZG9tLmlkKCkse21vcmV9KVxuICAgICAgfSw1MDAwKTtcblxuICAgICAgc2VsZi5vblN0b3AoKCk9PntcbiAgICAgICAgTWV0ZW9yLmNsZWFySW50ZXJ2YWwoaW50ZXJ2YWxJRCk7XG4gICAgICB9KTtcbiAgICB9LFxuICB9KTtcbn1cblxuXG5leHBvcnQgZGVmYXVsdCBJdGVtc1BydGc7XG4iLCJwcm9jZXNzLmVudi5OT0RFX1RMU19SRUpFQ1RfVU5BVVRIT1JJWkVEID0gJzAnO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJ1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcbmltcG9ydCByZXF1ZXN0IGZyb20gJ3JlcXVlc3QnO1xuaW1wb3J0IGh0dHBzIGZyb20gJ2h0dHBzJztcbmltcG9ydCBkbnMgZnJvbSAnZG5zJztcblxuXG4vLyBhcGljXG5jb25zdCBJdGVtc0FwaWMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignaXRlbXNhcGljJyk7XG5cbmNvbnN0IEl0ZW1BcGljU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSAoe1xuICB0ZXh0OiBTdHJpbmcsXG4gIGRhdGFPYmo6IHtcbiAgICB0eXBlOiBPYmplY3QsXG4gICAgYmxhY2tib3g6IHRydWVcbiAgfSxcbiAgcmVxdWVzdFRpbWU6IFNpbXBsZVNjaGVtYS5JbnRlZ2VyLFxuICBkYXRlVGltZSA6IHtcbiAgICB0eXBlOiBEYXRlXG4gIH1cbn0pO1xuXG5jb25zdCBJdGVtc0FwaWNTY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hICh7XG4gIGFwaWNEYXRhOiBJdGVtQXBpY1NjaGVtYVxufSk7XG5cblxuSXRlbXNBcGljLmF0dGFjaFNjaGVtYShJdGVtc0FwaWNTY2hlbWEpO1xuXG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcblxuLypcbiAgTWV0ZW9yLnB1Ymxpc2goJ2FsbEFwaWNJdGVtcycsIGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiBJdGVtc0FwaWMuZmluZCh7fSwge1xuICAgICAgLy8gbGltaXRzIHRoZSBudW1iZXIgb2YgcmV0dXJuIGpzb24gaXRlbXMgZnJvbSBEQlxuICAgICAgLy9saW1pdDogNTAsXG4gICAgICAvLyB2YWx1ZSAxIChPTERFU1QpIG9yIC0xIChORVdFU1QpIGRldGVybWluZXMgZGlyZWN0aW9ucyBvZiBsYXN0VXBkYXRlZFxuICAgICAgc29ydDoge1wiYXBpY0RhdGEuZGF0ZVRpbWVcIiA6IC0xfVxuICAgIH0pO1xuICB9KTtcbiovXG5cblxuICBNZXRlb3IubWV0aG9kcyh7XG4gICAgaHR0cFJlcXVlc3QodHlwZSwgdXJsLCBvcHRpb25zKSB7XG4gICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PntcbiAgICAgICAgICBjb25zdCByZXN1bHQgPSBIVFRQLmNhbGwodHlwZSwgdXJsLCBvcHRpb25zKTtcbiAgICAgICAgICAvLyBjb25zb2xlLmxvZyhyZXN1bHQpOyAvLyBkZWJ1Z1xuICAgICAgICAgIHJlc29sdmUocmVzdWx0KVxuICAgICAgICB9KVxuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICByZWplY3QoZSlcbiAgICAgICAgLy8gR290IGEgbmV0d29yayBlcnJvciwgdGltZW91dCwgb3IgSFRUUCBlcnJvciBpbiB0aGUgNDAwIG9yIDUwMCByYW5nZS5cbiAgICAgICAgY29uc29sZS5sb2coZSkgLy8gZGVidWdzXG4gICAgICB9XG4gICAgfSxcbiAgICBjaGVja0FwaWModHlwZSwgdXJsLCBvcHRpb25zKSB7XG4gICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IEhUVFAuY2FsbCh0eXBlLCB1cmwsIG9wdGlvbnMpO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhyZXN1bHQpOyAvLyBkZWJ1Z1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAvLyBHb3QgYSBuZXR3b3JrIGVycm9yLCB0aW1lb3V0LCBvciBIVFRQIGVycm9yIGluIHRoZSA0MDAgb3IgNTAwIHJhbmdlLlxuICAgICAgICBjb25zb2xlLmxvZyhlKSAvLyBkZWJ1Z1xuICAgICAgICByZXR1cm4gZTtcbiAgICAgIH1cbiAgICB9LFxuICAgIGluc2VydE5ld0FwaWMoYXBpY1RpY2tldCxkYXRhT2JqKSB7XG4gICAgICBsZXQgdGltZU5vdyA9IE1hdGgucm91bmQobmV3IERhdGUoKS5nZXRUaW1lKCkgLyAxMDAwKTtcbiAgICAgIGxldCBkYXRlVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICBJdGVtc0FwaWMuaW5zZXJ0KHtcbiAgICAgICAgICBhcGljRGF0YToge1xuICAgICAgICAgICAgdGV4dDogYXBpY1RpY2tldCxcbiAgICAgICAgICAgIGRhdGFPYmo6IGRhdGFPYmosXG4gICAgICAgICAgICByZXF1ZXN0VGltZTogdGltZU5vdyxcbiAgICAgICAgICAgIGRhdGVUaW1lOiBkYXRlVGltZVxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIFJvbGVzLmFkZFVzZXJzVG9Sb2xlcyhNZXRlb3IudXNlcklkKCksICdzdW1pdHRlcicpXG4gICAgfSxcbiAgICB2b3RlT25JdGVtQXBpYyhpdGVtLCBwb3NpdGlvbikge1xuICAgICAgY2hlY2soaXRlbSwgT2JqZWN0KTtcbiAgICAgIGxldCBsYXN0VXBkYXRlZCA9IG5ldyBEYXRlKCk7XG4gICAgICBpZihNZXRlb3IudXNlcklkKCkpIHtcbiAgICAgICAgaWYocG9zaXRpb24gPT0gJ2l0ZW1PbmUnKSB7XG4gICAgICAgICAgSXRlbXNBcGljLnVwZGF0ZShpdGVtLl9pZCwge1xuICAgICAgICAgICAgJGluYzoge1xuICAgICAgICAgICAgICAnaXRlbU9uZS52YWx1ZSc6IDFcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgICAgIGxhc3RVcGRhdGVkXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgICAgICBSb2xlcy5hZGRVc2Vyc1RvUm9sZXMoTWV0ZW9yLnVzZXJJZCgpLCAndm90ZXInKVxuICAgICAgfVxuICAgIH0sXG4gICAgJ2dldERhdGVJU08nOiBmdW5jdGlvbigpe1xuICAgICAgbGV0IGRhdGVSYW5nZSA9ICgpPT57XG4gICAgICAgIGNvbnZlcnREYXlzID0gZnVuY3Rpb24gKGQpIHtcbiAgICAgICAgICAgIC8vQ29udmVydCBkYXlzIGludG8gTWlsbGlTZWNvbmRzXG4gICAgICAgICAgICByZXR1cm4gZCAqIDg2NDAwMDAwO1xuICAgICAgICB9XG4gICAgICAgIGxldCBkYXRlSVNPID0gKGRhdGVOdW0pPT57XG4gICAgICAgICAgbGV0IG5ld1RvZGF5ID0gbmV3IERhdGUoKTtcbiAgICAgICAgICBsZXQgbmV3TG9va3VwRGF0ZSA9IG5ldyBEYXRlKG5ld1RvZGF5IC0gY29udmVydERheXMoZGF0ZU51bSkpO1xuICAgICAgICAgIG5ld0xvb2t1cERhdGUgPSBuZXdMb29rdXBEYXRlLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVxuICAgICAgICAgIHJldHVybiBuZXdMb29rdXBEYXRlWzBdO1xuICAgICAgICB9XG4gICAgICAgIGxldCBhID0gbmV3IERhdGUoKVxuICAgICAgICBsZXQgdG9kYXkgPSBkYXRlSVNPKDApO1xuICAgICAgICBsZXQgeWVzdGVyZGF5ID0gZGF0ZUlTTygxKTtcbiAgICAgICAgbGV0IGxhc3RXZWVrU3RhcnQgPSBkYXRlSVNPKGEuZ2V0RGF5KCkgKyA3KTtcbiAgICAgICAgbGV0IGxhc3RXZWVrRW5kID0gZGF0ZUlTTyg3IC0gYS5nZXREYXkoKSk7XG4gICAgICAgIHZhciBkYXRlUmFuZ2VMYWJlbHMgPSB7XG4gICAgICAgICAgICB0b2RheToge1xuICAgICAgICAgICAgICAgIHN0YXJ0OiB0b2RheSxcbiAgICAgICAgICAgICAgICBlbmQ6IHRvZGF5XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgeWVzdGVyZGF5OiB7XG4gICAgICAgICAgICAgICAgc3RhcnQ6IHllc3RlcmRheSxcbiAgICAgICAgICAgICAgICBlbmQ6IHRvZGF5XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgbGFzdFdlZWs6IHtcbiAgICAgICAgICAgICAgICBzdGFydDogbGFzdFdlZWtTdGFydCxcbiAgICAgICAgICAgICAgICBlbmQ6IGxhc3RXZWVrRW5kXG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHJldHVybiBkYXRlUmFuZ2VMYWJlbHNcbiAgICAgIH1cbiAgICAgIHJldHVybiBkYXRlUmFuZ2UoKVxuICAgIH0sXG4gICAgJ2dldERuc0xvb2t1cCc6IGZ1bmN0aW9uKGhvc3ROYW1lKXtcbiAgICAgIGxldCBsb29rdXAgPSBNZXRlb3Iud3JhcEFzeW5jKGRucy5sb29rdXApLFxuICAgICAgaXAgPSBsb29rdXAoaG9zdE5hbWUpXG4gICAgICBjb25zb2xlLmxvZyhpcClcbiAgICAgIHJldHVybiBpcFxuICAgIH0sXG4gIH0pO1xufVxuXG5leHBvcnQgZGVmYXVsdCBJdGVtc0FwaWM7XG4iLCJwcm9jZXNzLmVudi5OT0RFX1RMU19SRUpFQ1RfVU5BVVRIT1JJWkVEID0gJzAnO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJ1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcbmltcG9ydCByZXF1ZXN0IGZyb20gJ3JlcXVlc3QnO1xuaW1wb3J0IGh0dHBzIGZyb20gJ2h0dHBzJztcbmltcG9ydCB0ZW1wRGF0YSBmcm9tICcuLi8uLi9zZXJ2ZXIvdGVtcERhdGEnO1xuXG4vLyBwcnRnXG5jb25zdCBJdGVtc1RyYW5zZmVyUmF0ZSA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdpdGVtc3RyYW5zZmVycmF0ZScpO1xuXG5jb25zdCBJdGVtVHJhbnNmZXJSYXRlU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSAoe1xuICBkYXRhT2JqOiB7XG4gICAgdHlwZTogT2JqZWN0LFxuICAgIGJsYWNrYm94OiB0cnVlXG4gIH0sXG4gIHJlcXVlc3RUaW1lOiBTaW1wbGVTY2hlbWEuSW50ZWdlcixcbiAgZGF0ZVRpbWUgOiB7XG4gICAgdHlwZTogRGF0ZVxuICB9XG59KTtcblxuXG5jb25zdCBJdGVtc1RyYW5zZmVyUmF0ZVNjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEgKHtcbiAgc2l0ZURhdGE6IEl0ZW1UcmFuc2ZlclJhdGVTY2hlbWFcbn0pO1xuXG5JdGVtc1RyYW5zZmVyUmF0ZS5hdHRhY2hTY2hlbWEoSXRlbXNUcmFuc2ZlclJhdGVTY2hlbWEpO1xuXG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcblxuXG5cblxuICBNZXRlb3IubWV0aG9kcyh7XG5cbiAgfSk7XG59XG5cblxuZXhwb3J0IGRlZmF1bHQgSXRlbXNUcmFuc2ZlclJhdGU7XG4iLCJwcm9jZXNzLmVudi5OT0RFX1RMU19SRUpFQ1RfVU5BVVRIT1JJWkVEID0gJzAnO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJ1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcbmltcG9ydCByZXF1ZXN0IGZyb20gJ3JlcXVlc3QnO1xuaW1wb3J0IGh0dHBzIGZyb20gJ2h0dHBzJztcbmltcG9ydCBkbnMgZnJvbSAnZG5zJztcblxuXG4vLyBhcGljXG5jb25zdCBJdGVtc1dlYlNlcnZlclN0YXR1cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdpdGVtc3dlYnNlcnZlcnN0YXR1cycpO1xuXG5jb25zdCBJdGVtV2ViU2VydmVyU3RhdHVzU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSAoe1xuICBkYXRhT2JqOiB7XG4gICAgdHlwZTogT2JqZWN0LFxuICAgIGJsYWNrYm94OiB0cnVlXG4gIH0sXG4gIHJlcXVlc3RUaW1lOiBTaW1wbGVTY2hlbWEuSW50ZWdlcixcbiAgZGF0ZVRpbWUgOiB7XG4gICAgdHlwZTogRGF0ZVxuICB9XG59KTtcblxuY29uc3QgSXRlbXNXZWJTZXJ2ZXJTdGF0dXNTY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hICh7XG4gIHdlYlNlcnZlckRhdGE6IEl0ZW1XZWJTZXJ2ZXJTdGF0dXNTY2hlbWFcbn0pO1xuXG5JdGVtc1dlYlNlcnZlclN0YXR1cy5hdHRhY2hTY2hlbWEoSXRlbXNXZWJTZXJ2ZXJTdGF0dXNTY2hlbWEpO1xuXG5cblxuXG5cblxuXG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcblxuLypcbiAgTWV0ZW9yLnB1Ymxpc2goJ2FsbEFwaWNJdGVtcycsIGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiBJdGVtc0FwaWMuZmluZCh7fSwge1xuICAgICAgLy8gbGltaXRzIHRoZSBudW1iZXIgb2YgcmV0dXJuIGpzb24gaXRlbXMgZnJvbSBEQlxuICAgICAgLy9saW1pdDogNTAsXG4gICAgICAvLyB2YWx1ZSAxIChPTERFU1QpIG9yIC0xIChORVdFU1QpIGRldGVybWluZXMgZGlyZWN0aW9ucyBvZiBsYXN0VXBkYXRlZFxuICAgICAgc29ydDoge1wiYXBpY0RhdGEuZGF0ZVRpbWVcIiA6IC0xfVxuICAgIH0pO1xuICB9KTtcbiovXG5cblxuICBNZXRlb3IubWV0aG9kcyh7XG4gIFxuICB9KTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgSXRlbXNXZWJTZXJ2ZXJTdGF0dXM7XG4iLCJBY2NvdW50cy5vbkNyZWF0ZVVzZXIoKG9wdGlvbnMsIHVzZXIpID0+IHtcbiAgLy8gY29uc29sZS5sb2cob3B0aW9ucywgdXNlcik7XG4gIGlmKE1ldGVvci5zZXR0aW5ncy5hZG1pbnMuaW5kZXhPZihvcHRpb25zLmVtYWlsKSA+IC0xICkge1xuICAgIHVzZXIucm9sZXM9IFsnYWRtaW4nXTtcbiAgfVxuICByZXR1cm4gdXNlcjtcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgSXRlbXNBcGljRGV2aWNlcyBmcm9tICcuLi9hcGkvYXBpYyc7XG5cbmxldCBhcGljRGV2aWNlcyA9ICgpPT57XG4gIGxldCBjbGllbnRJZCA9IGZhbHNlO1xuICBsZXQgY291bnRlciA9IDA7XG4gIGNvbnN0IHNlbGYgPSB0aGlzO1xuICBjb25zdCB0aW1lTm93ID0gKGRpdmlzb3IpID0+e1xuICAgIHJldHVybiBNYXRoLnJvdW5kKG5ldyBEYXRlKCkuZ2V0VGltZSgpIC8gZGl2aXNvcik7XG4gIH1cbiAgY29uc3QgZGF0ZVRpbWUgPSBuZXcgRGF0ZSgpO1xuICBjb25zdCBiYXNlVXJsID0gTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUuYXBpY0VNLnVOYW1lID8gTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUuYXBpY0VNLmJhc2VVcmwgOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNpc2NvQXBpY0VNLmJhc2VVcmw7XG4gIGNvbnN0IHVOYW1lID0gTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUuYXBpY0VNLnVOYW1lID8gTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUuYXBpY0VNLnVOYW1lIDogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaXNjb0FwaWNFTS51TmFtZTtcbiAgY29uc3QgdVBhc3MgPSBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5hcGljRU0udU5hbWUgPyBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5hcGljRU0udVBhc3MgOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNpc2NvQXBpY0VNLnVQYXNzO1xuICBjb25zdCBjbGllbnRJZGVudCA9IHtcbiAgICBjbGllbnRJcDogXCJcIixcbiAgICBjbGllbnRJZDpmYWxzZSxcbiAgICBzZXRJcDogZnVuY3Rpb24oaXApe1xuICAgICAgaWYgKHRoaXMuY2xpZW50SWQgPT09IGZhbHNlKXtcbiAgICAgICAgdGhpcy5jbGllbnRJZCA9IGlwK1wiIDogXCIrUmFuZG9tLmlkKCk7XG4gICAgICAgIC8vY29uc29sZS5sb2coXCJkYXRhXCIsdGhpcy5jbGllbnRJZCk7XG4gICAgICAgIHJldHVybiB0aGlzLmNsaWVudElkO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy9jb25zb2xlLmxvZyhcImRhdGFcIix0aGlzLmNsaWVudElkKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuY2xpZW50SWQ7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGNvbnN0IGZpbmRJdGVtID0gKHZhbHVlKT0+e1xuICAgIHJldHVybiBJdGVtc0FwaWNEZXZpY2VzLmZpbmRPbmUoe1wic2l0ZURhdGEuZGF0YU9iai5pZFwiOnZhbHVlfSk7XG4gIH1cbiAgY29uc3QgY291bnRDb2xsZWN0aW9ucyA9ICgpPT57XG4gICAgcmV0dXJuIEl0ZW1zQXBpY0RldmljZXMuZmluZCgpLmNvdW50KCk7XG4gIH1cbiAgY29uc29sZS5sb2coXCJhcGljRGV2aWNlcyBDb3VudDogXCIsY291bnRDb2xsZWN0aW9ucygpKTtcbiAgY29uc3QgYXBpY1JvbGVVcm4gPSAnL2FwaS92MS91c2VyL3JvbGUnO1xuICBjb25zdCByb2xlVXJsID0gYmFzZVVybCArIGFwaWNSb2xlVXJuO1xuICBjb25zdCBhcGljVGlja2V0VXJuID0gJy9hcGkvdjEvdGlja2V0JztcbiAgY29uc3QgdGlja2V0VXJsID0gYmFzZVVybCArIGFwaWNUaWNrZXRVcm47XG4gIGNvbnN0IGFwaWNUaWNrZXRPcHRpb25zID0ge1xuICAgIGhlYWRlcnM6IHsgJ2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxuICAgIGRhdGE6IHt1c2VybmFtZTogdU5hbWUsIHBhc3N3b3JkOiB1UGFzc31cbiAgfVxuICAvLyBjb21tYW5kcyB0byBiZSBydW4gYWdhaW5zdCBhcGljIGRldmljZS4gTm8gbW9yZSB0aGFuIDUgIHBlciBhcnJheXMgZS5nLiBbMCwxLDIsMyw0XVxuICBjb25zdCBkb3duUG9ydENvbW1hbmRBcnJheSA9IFtcbiAgICAgIFwic2hvdyBpbnQgfCBpIHByb3RvLipub3Rjb25uZWN0fHByb3RvLiphZG1pbmlzdHJhdGl2ZWx5IGRvd258TGFzdCBpbi4qIFs2LTldd3xMYXN0IGluLipbMC05XVswLTldd3xbMC05XXl8ZGlzYWJsZWR8TGFzdCBpbnB1dCBuZXZlciwgb3V0cHV0IG5ldmVyLCBvdXRwdXQgaGFuZyBuZXZlclwiXG4gIF07XG4gIGxldCBhcGljRGV2aWNlc1VybiA9IFwiL2FwaS92MS9uZXR3b3JrLWRldmljZVwiO1xuICBsZXQgZGV2aWNlc1VybCA9IGJhc2VVcmwgKyBhcGljRGV2aWNlc1VybjtcbiAgbGV0IHRpY2tldElkbGVUaW1lb3V0ID0gMDtcbiAgbGV0IHRpY2tldFNlc3Npb25UaW1lb3V0ID0gMDtcbiAgbGV0IG9sZEFwaWNUaWNrZXQgPSBcIlwiO1xuXG4gIGNvbnN0IHN0YXR1c0NvZGVQYXJzZXIgPSAoc3RhdHVzQ29kZSkgPT57XG4gICAgaWYgKHN0YXR1c0NvZGUgPT09IDIwMCkge1xuICAgICAgcmV0dXJuIDA7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiAxO1xuICAgIH1cbiAgfVxuICBjb25zdCBnZXRUaW1lTm93ID0gKCkgPT57XG4gICAgcmV0dXJuIG5ldyBEYXRlKCkuZ2V0VGltZSgpXG4gIH1cbiAgY29uc3QgY29udmVydERhdGVUaW1lID0gKGRhdGVTdHJpbmcpID0+e1xuICAgIGxldCBzb21lRGF0ZSA9IG5ldyBEYXRlKGRhdGVTdHJpbmcpO1xuICAgIC8vY29uc29sZS5sb2coc29tZURhdGUuZ2V0VGltZSgpKTtcbiAgICByZXR1cm4gc29tZURhdGUuZ2V0VGltZSgpO1xuICB9XG4gIGNvbnN0IGFwaWNPcHRpb25zID0gKGJvZHlPYmopID0+IHtcbiAgICBjb25zdCBhcGljVGlja2V0ID0gKCk9PntcbiAgICAgIGNvbnN0IHNldFRpbWVvdXRzID0gKGlkbGVUaW1lb3V0LHNlc3Npb25UaW1lb3V0KSA9PntcbiAgICAgICAgdGlja2V0SWRsZVRpbWVvdXQgPSB0aW1lTm93KDEwMDApICsgaWRsZVRpbWVvdXQ7XG4gICAgICAgIHRpY2tldFNlc3Npb25UaW1lb3V0ID0gdGltZU5vdygxMDAwKSArIHNlc3Npb25UaW1lb3V0O1xuICAgICAgICAvL2NvbnNvbGUubG9nKFwiVGlja2V0IHRpbWVvdXQgPFRpbWUgTm93OiBJZGxlL1Nlc3Npb24+IFwiLHRpbWVOb3coMTAwMCkrXCI6IFwiK3RpY2tldElkbGVUaW1lb3V0K1wiL1wiK3RpY2tldFNlc3Npb25UaW1lb3V0KTtcbiAgICAgICAgLy9jb25zb2xlLmxvZyhcIlJlcXVlc3RpbmcgTmV3IHRpY2tldDogXCIsIG9sZEFwaWNUaWNrZXQpXG4gICAgICB9XG4gICAgICBpZiAodGlja2V0SWRsZVRpbWVvdXQgPT09IDAgJiYgdGlja2V0U2Vzc2lvblRpbWVvdXQgPT09IDAgKXtcbiAgICAgICAgbGV0IGh0dHBSZXF1ZXN0ID0gTWV0ZW9yLmNhbGwoJ2FwaWNUaWNrZXQnLCBcIlBPU1RcIix0aWNrZXRVcmwsYXBpY1RpY2tldE9wdGlvbnMpO1xuICAgICAgICBpZiAoaHR0cFJlcXVlc3QuZGF0YS5yZXNwb25zZS5zZXJ2aWNlVGlja2V0ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICBvbGRBcGljVGlja2V0ID0gaHR0cFJlcXVlc3QuZGF0YS5yZXNwb25zZS5zZXJ2aWNlVGlja2V0O1xuICAgICAgICAgIHNldFRpbWVvdXRzKDE4MDAsMjE2MDApO1xuICAgICAgICAgIGNvbnNvbGUubG9nKFwiIyMjLU5ldyBUaWNrZXQ6IFwiLG9sZEFwaWNUaWNrZXQpXG4gICAgICAgICAgY29uc29sZS5sb2coXCIjIyMtVGlja2V0IHRpbWVvdXQgPFRpbWUgTm93OiBJZGxlL1Nlc3Npb24+IFwiLHRpbWVOb3coMTAwMCkrXCI6IFwiK3RpY2tldElkbGVUaW1lb3V0K1wiL1wiK3RpY2tldFNlc3Npb25UaW1lb3V0KTtcbiAgICAgICAgICByZXR1cm4gaHR0cFJlcXVlc3QuZGF0YS5yZXNwb25zZS5zZXJ2aWNlVGlja2V0O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG5cbiAgICAgIH0gZWxzZSBpZiAodGltZU5vdygxMDAwKSA+PSB0aWNrZXRJZGxlVGltZW91dCB8fCB0aW1lTm93KDEwMDApID49IHRpY2tldFNlc3Npb25UaW1lb3V0KXtcbiAgICAgICAgbGV0IGh0dHBSZXF1ZXN0ID0gTWV0ZW9yLmNhbGwoJ2FwaWNUaWNrZXQnLCBcIlBPU1RcIix0aWNrZXRVcmwsYXBpY1RpY2tldE9wdGlvbnMpO1xuICAgICAgICBvbGRBcGljVGlja2V0ID0gaHR0cFJlcXVlc3QuZGF0YS5yZXNwb25zZS5zZXJ2aWNlVGlja2V0O1xuICAgICAgICBzZXRUaW1lb3V0cygxODAwLDIxNjAwKTtcbiAgICAgICAgY29uc29sZS5sb2coXCIqKiotVGlja2V0IGV4cGlyZWQgcmVxdWVzdGluZyBuZXcgVGlja2V0OiBcIixvbGRBcGljVGlja2V0KVxuICAgICAgICBjb25zb2xlLmxvZyhcIioqKi1UaWNrZXQgdGltZW91dCA8VGltZSBOb3c6IElkbGUvU2Vzc2lvbj4gXCIsdGltZU5vdygxMDAwKStcIjogXCIrdGlja2V0SWRsZVRpbWVvdXQrXCIvXCIrdGlja2V0U2Vzc2lvblRpbWVvdXQpO1xuICAgICAgICByZXR1cm4gaHR0cFJlcXVlc3QuZGF0YS5yZXNwb25zZS5zZXJ2aWNlVGlja2V0O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy9jb25zb2xlLmxvZyhcIlVzaW5nIEV4aXN0aW5nIFRpY2tldDogXCIsb2xkQXBpY1RpY2tldClcbiAgICAgICAgLy9jb25zb2xlLmxvZyhcIlRpY2tldCB0aW1lb3V0IDxUaW1lIE5vdzogSWRsZS9TZXNzaW9uPiBcIix0aW1lTm93KDEwMDApK1wiOiBcIit0aWNrZXRJZGxlVGltZW91dCtcIi9cIit0aWNrZXRTZXNzaW9uVGltZW91dCk7XG4gICAgICAgIHJldHVybiBvbGRBcGljVGlja2V0O1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCByZXF1ZXN0T2JqID0ge1xuICAgICAgaGVhZGVyczoge1xuICAgICAgICAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAneC1hdXRoLXRva2VuJzogYXBpY1RpY2tldCgpXG4gICAgICB9LFxuICAgICAgZGF0YTogYm9keU9ialxuICAgIH1cbiAgICByZXR1cm4gcmVxdWVzdE9iajtcbiAgfTtcblxuICBjb25zdCBjaGVja1VzZXJSb2xlID0gKG1ldGhvZCx1cmwsb3B0aW9ucykgPT57XG4gICAgY29uc3QgaHR0cFVzZXJSb2xlID0gTWV0ZW9yLmNhbGwoJ2h0dHBSZXF1ZXN0JywgbWV0aG9kLHVybCxvcHRpb25zKTtcbiAgICBjb25zdCB1c2VyUm9sZSA9IGh0dHBVc2VyUm9sZTtcbiAgICBpZiAodXNlclJvbGUuc3RhdHVzQ29kZSA9PT0gMjAwKSB7XG4gICAgICAvL2NvbnNvbGUubG9nKFwiaGl0XCIpXG4gICAgICAvL2NvbnNvbGUubG9nKHVzZXJSb2xlLmRhdGEucmVzcG9uc2UpXG4gICAgICByZXR1cm4gdXNlclJvbGUuZGF0YS5yZXNwb25zZTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIHVzZXJSb2xlO1xuICAgIH1cbiAgfVxuICAvLyBnZXRzIHVzZXIgcm9sZXMgYXMgQXJyYXlcbiAgLy9jb25zdCByb2xlU3RhdHVzID0gY2hlY2tVc2VyUm9sZShcIkdFVFwiLHJvbGVVcmwsYXBpY09wdGlvbnMoXCJcIikpO1xuXG4gIGFzeW5jIGZ1bmN0aW9uIGh0dHBSZXF1ZXN0KG1ldGhvZCx1cmwsb3B0aW9ucyl7XG4gICAgY29uc3QgaHR0cERldmljZXMgPSBhd2FpdCBNZXRlb3IuY2FsbCgnaHR0cFJlcXVlc3QnLCBtZXRob2QsdXJsLG9wdGlvbnMpO1xuICAgIGNvbnN0IGFwaWNEZXZpY2VzID0gYXdhaXQgaHR0cERldmljZXM7XG4gICAgLy8gZXJyb3IgY2hlY2tpbmcgUkVTVCByZXF1ZXN0LiBJZiBub3QgMjAwIGRvIG5vdGhpbmcgYW5kIGxvZ1xuICAgIGlmIChhd2FpdCBhcGljRGV2aWNlcy5zdGF0dXNDb2RlID09PSAyMDApIHtcbiAgICAgIC8vIGl0dGVyYXRlIG92ZXIgb2JqZWN0XG4gICAgICByZXR1cm4gYXdhaXQgUHJvbWlzZS5hbGwoYXBpY0RldmljZXMuZGF0YS5yZXNwb25zZS5tYXAoKGRhdGEsaW5kZXgpPT57XG4gICAgICAgIC8vIGRlYnVnXG4gICAgICAgIC8vY29uc29sZS5sb2coYXBpY0RldmljZXMpXG4gICAgICAgIGNvbnN0IG1hbmFnZW1lbnRJcEFkZHJlc3MgPSBkYXRhLm1hbmFnZW1lbnRJcEFkZHJlc3M7XG4gICAgICAgIGNvbnN0IGRldmljZUlkID0gZGF0YS5pZDtcbiAgICAgICAgY29uc3QgbGFzdFVwZGF0ZVRpbWUgPSBkYXRhLmxhc3RVcGRhdGVUaW1lO1xuICAgICAgICBjb25zdCBkYXRhQ2hlY2sgPSBJdGVtc0FwaWNEZXZpY2VzLmZpbmQoe1wic2l0ZURhdGEuZGF0YU9iai5tYW5hZ2VtZW50SXBBZGRyZXNzXCI6bWFuYWdlbWVudElwQWRkcmVzc30pLmZldGNoKCk7XG4gICAgICAgIGNvbnN0IG5vcm1hbGl6ZSA9IGRhdGEuaG9zdG5hbWUgPyBkYXRhLmhvc3RuYW1lLnRvTG93ZXJDYXNlKCkgOiBcIk51bGxcIjtcbiAgICAgICAgLy8gYWRkcyBub3JtYWxpemVkIG5hbWUgZm9yIGVhc2llciBzZWFyY2hpbmdcbiAgICAgICAgZGF0YS5ub3JtYWxpemVIb3N0TmFtZSA9IG5vcm1hbGl6ZTtcblxuICAgICAgICBjb25zdCB2bGFuRGV0YWlsID0gKCk9PntcbiAgICAgICAgICBpZiAoZGF0YS5mYW1pbHkgPT0gXCJVbmlmaWVkIEFQXCIpe1xuICAgICAgICAgICAgcmV0dXJuIGRhdGEudmxhbkRldGFpbCA9IG51bGw7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGRldmljZXNWbGFuVXJsID0gYmFzZVVybCArIFwiL2FwaS92MS9uZXR3b3JrLWRldmljZVwiICtcIi9cIisgZGF0YS5pZCtcIi92bGFuXCI7XG4gICAgICAgICAgICBjb25zdCB2bGFuRGV0YWlsID0gTWV0ZW9yLmNhbGwoJ2FwaWNIdHRwUmVxdWVzdCcsXCJHRVRcIixkZXZpY2VzVmxhblVybCxvcHRpb25zKTtcbiAgICAgICAgICAgIGlmICh2bGFuRGV0YWlsLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgaWYgKHZsYW5EZXRhaWwuZGF0YS5yZXNwb25zZS5sZW5ndGggPD0gMCl7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGRhdGEudmxhbkRldGFpbCA9IG51bGw7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGRhdGEudmxhbkRldGFpbCA9IHZsYW5EZXRhaWwuZGF0YS5yZXNwb25zZTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGRhdGEudmxhbkRldGFpbCA9IG51bGw7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGludGVyZmFjZUluZm8gPSAoKT0+e1xuICAgICAgICAgIGlmICgoZGF0YS5mYW1pbHkgPT0gXCJTd2l0Y2hlcyBhbmQgSHVic1wiIHx8IGRhdGEuZmFtaWx5ID09IFwiUm91dGVyc1wiKSAmJiBkYXRhLmVycm9yQ29kZSA9PT0gbnVsbCB8fCBkYXRhLmVycm9yQ29kZSA9PSBcIkRFVi1VTlJFQUNIRURcIil7XG4gICAgICAgICAgICBjb25zdCBpbnRlcmZhY2VJbmZvVXJsID0gYmFzZVVybCArIFwiL2FwaS92MS9pbnRlcmZhY2UvbmV0d29yay1kZXZpY2VcIiArXCIvXCIrIGRhdGEuaWQ7XG4gICAgICAgICAgICBjb25zdCBpbnRlcmZhY2VJbmZvQ2FsbCA9IE1ldGVvci5jYWxsKCdhcGljSHR0cFJlcXVlc3QnLFwiR0VUXCIsaW50ZXJmYWNlSW5mb1VybCxvcHRpb25zKTtcbiAgICAgICAgICAgIGlmIChpbnRlcmZhY2VJbmZvQ2FsbC5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgIC8vIGNyZWF0ZXMgYSByZWNvcmQgb2Ygd2hlbiB0aGUgaW50ZXJmYWNlIGhhcyBnb25lIGRvd24sIGFuZCBob3cgbG9uZyBpdCBoYXMgYmVlbiBkb3duXG5cbiAgICAgICAgICAgICAgaW50ZXJmYWNlSW5mb0NhbGwuZGF0YS5yZXNwb25zZS5tYXAoKGRhdGEsaW5kZXgpPT57XG4gICAgICAgICAgICAgICAgaWYgKGRhdGEuc3RhdHVzID09IFwiZG93blwiKSB7XG4gICAgICAgICAgICAgICAgICAvLyBkZWJ1Z1xuICAgICAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcIkFwaWMgU2F5cyBpdCdzIFwiLGRhdGEuc3RhdHVzKTtcbiAgICAgICAgICAgICAgICAgIGlmIChkYXRhQ2hlY2tbMF0pe1xuICAgICAgICAgICAgICAgICAgICAvLyBkZWJ1Z1xuICAgICAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwiTW9uZ28gU2F5cyBpdCdzIFwiLCBkYXRhQ2hlY2tbMF0uc2l0ZURhdGEuZGF0YU9iai5pbnRlcmZhY2VEZXRhaWxbaW5kZXhdLnN0YXR1cyk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChkYXRhQ2hlY2tbMF0uc2l0ZURhdGEuZGF0YU9iai5pbnRlcmZhY2VEZXRhaWxbaW5kZXhdLnN0YXR1cyA9PSBcInVwXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAvLyBkZWJ1Z1xuICAgICAgICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJNb25nbyBzYXlzIFVQLCBhbmQgQVBJQyBzYXlzIGl0J3MgRE9XTi4gU2V0dGluZyBkb3duQXNPZiB0byBjdXJyZW50IHRpbWVcIik7XG4gICAgICAgICAgICAgICAgICAgICAgLy9zZXQgZG93bkFzT2YgdG8gRGF0ZSBUaW1lIGluIG1pbGlzZWNvbmRzXG4gICAgICAgICAgICAgICAgICAgICAgZGF0YS5kb3duQXNPZiA9IHRpbWVOb3coMSk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoZGF0YUNoZWNrWzBdLnNpdGVEYXRhLmRhdGFPYmouaW50ZXJmYWNlRGV0YWlsW2luZGV4XS5zdGF0dXMgPT0gXCJkb3duXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAvLyBkZWJ1Z1xuICAgICAgICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJNb25nbyBzYXlzIERPV04sIGFuZCBBUElDIHNheXMgaXQncyBET1dOLiBDaGVja2luZyBpZiBmaWVsZCBleGlzdHNcIik7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBkYXRhQ2hlY2tbMF0uc2l0ZURhdGEuZGF0YU9iai5pbnRlcmZhY2VEZXRhaWxbaW5kZXhdLmRvd25Bc09mID09IFwibnVtYmVyXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRlYnVnXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwiTnVtYmVyIERldGVjdGVkLCBEb2luZyBub3RoaW5nXCIsIGRhdGFDaGVja1swXS5zaXRlRGF0YS5kYXRhT2JqLmludGVyZmFjZURldGFpbFtpbmRleF0uZG93bkFzT2YpXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBETyBOT1RISU5HLCBsZWF2ZSB0aGUgZXhpc3RpbmcgdGltZSBzdGFtcFxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS5kb3duQXNPZiA9IGRhdGFDaGVja1swXS5zaXRlRGF0YS5kYXRhT2JqLmludGVyZmFjZURldGFpbFtpbmRleF0uZG93bkFzT2Y7XG4gICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChkYXRhQ2hlY2tbMF0uc2l0ZURhdGEuZGF0YU9iai5pbnRlcmZhY2VEZXRhaWxbaW5kZXhdLmRvd25Bc09mID09IG51bGwpe1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGVidWdcbiAgICAgICAgICAgICAgICAgICAgICAgIC8qY29uc29sZS5sb2coZGF0YS5pZClcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coZGF0YUNoZWNrWzBdLnNpdGVEYXRhLmRhdGFPYmouaW50ZXJmYWNlRGV0YWlsW2luZGV4XS5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlRoZSBmaWVsZCBkb2VzIE5PVCBleGlzdCBzZXR0aW5nIGRvd25Bc09mIHRvIGN1cnJlbnQgdGltZVwiLCBkYXRhQ2hlY2tbMF0uc2l0ZURhdGEuZGF0YU9iai5pbnRlcmZhY2VEZXRhaWxbaW5kZXhdLmRvd25Bc09mKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICAgICAgICAvL3NldCBkb3duQXNPZiB0byBEYXRlIFRpbWUgaW4gbWlsaXNlY29uZHNcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEuZG93bkFzT2YgPSB0aW1lTm93KDEpO1xuICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBkZWJ1Z1xuICAgICAgICAgICAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcIlRoZSBmaWVsZCBpcyBET0VTIGV4aXN0LiBOTyBDSEFOR0UgKioqXCIpXG4gICAgICAgICAgICAgICAgICAgICAgICAvL3NldCBkb3duQXNPZiB0byBEYXRlIFRpbWUgaW4gbWlsaXNlY29uZHNcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEuZG93bkFzT2YgPSB0aW1lTm93KDEpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAvLyB0YWtlcyBjYXJlIG9mIGFueSBvdGhlciBzdGF0ZVxuICAgICAgICAgICAgICAgICAgLy8gZGVidWdcbiAgICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJJbnRlcmZhY2UgaXMgdXAsIG1hcmtpbmQgZG93bkFzT2YgdG8gTlVMTFwiKVxuICAgICAgICAgICAgICAgICAgLy9zZXQgZG93bkFzT2YgdG8gTlVMTFxuICAgICAgICAgICAgICAgICAgZGF0YS5kb3duQXNPZiA9IG51bGw7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICByZXR1cm4gZGF0YS5pbnRlcmZhY2VEZXRhaWwgPSBpbnRlcmZhY2VJbmZvQ2FsbC5kYXRhLnJlc3BvbnNlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCBsaWNlbnNlSW5mbyA9ICgpPT57XG4gICAgICAgICAgaWYgKChkYXRhLmZhbWlseSA9PSBcIlN3aXRjaGVzIGFuZCBIdWJzXCIgfHwgZGF0YS5mYW1pbHkgPT0gXCJSb3V0ZXJzXCIpICYmIGRhdGEuZXJyb3JDb2RlID09PSBudWxsKXtcbiAgICAgICAgICAgIGNvbnN0IGxpY2Vuc2VJbmZvVXJsID0gYmFzZVVybCArIFwiL2FwaS92MS9saWNlbnNlLWluZm8vbmV0d29yay1kZXZpY2VcIiArXCIvXCIrIGRhdGEuaWQ7XG4gICAgICAgICAgICBjb25zdCBsaWNlbnNlSW5mb0NhbGwgPSBNZXRlb3IuY2FsbCgnYXBpY0h0dHBSZXF1ZXN0JyxcIkdFVFwiLGxpY2Vuc2VJbmZvVXJsLG9wdGlvbnMpO1xuICAgICAgICAgICAgaWYgKGxpY2Vuc2VJbmZvQ2FsbC5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgIHJldHVybiBkYXRhLmxpY2Vuc2VEZXRhaWwgPSBsaWNlbnNlSW5mb0NhbGwuZGF0YS5yZXNwb25zZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc2hvd0NvbW1hbmRzID0gKGNvbW1hbmRBcnJheSx1VWlkcyk9PntcbiAgICAgICAgICBsZXQgdGVzdENvdW50ZXIgPSAwO1xuICAgICAgICAgIGlmICgoZGF0YS5mYW1pbHkgPT0gXCJTd2l0Y2hlcyBhbmQgSHVic1wiKSAmJiBkYXRhLmVycm9yQ29kZSA9PT0gbnVsbCl7XG4gICAgICAgICAgICBjb25zdCB0YXNrU3RhdHVzID0gKHRhc2tVcmwpID0+e1xuICAgICAgICAgICAgICBsZXQgdGFza1N0YXVzQ2FsbCA9IE1ldGVvci5jYWxsKCdhcGljSHR0cFJlcXVlc3QnLFwiR0VUXCIsdGFza1VybCxhcGljT3B0aW9ucyhcIlwiKSk7XG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKHRhc2tTdGF0dXNDYWxsLmRhdGEucmVzcG9uc2UpO1xuICAgICAgICAgICAgICByZXR1cm4gdGFza1N0YXR1c0NhbGwuZGF0YS5yZXNwb25zZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChyb2xlU3RhdHVzWzBdLnJvbGUgPT1cIlJPTEVfQURNSU5cIiApe1xuICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKHJvbGVTdGF0dXNbMF0ucm9sZSlcbiAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhjb21tYW5kQXJyYXksdVVpZHMpXG4gICAgICAgICAgICAgIGNvbnN0IGNvbW1hbmRSdW5uZXJEVE8gPSB7XG4gICAgICAgICAgICAgICAgXCJuYW1lXCI6IFwidGVzdFwiLFxuICAgICAgICAgICAgICAgIFwiY29tbWFuZHNcIjogY29tbWFuZEFycmF5LFxuICAgICAgICAgICAgICAgIFwiZGV2aWNlVXVpZHNcIjogW3VVaWRzXVxuICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICBjb25zdCBuZXR3b3JrRGV2aWNlUG9sbGVyID0gYmFzZVVybCArIFwiL2FwaS92MS9uZXR3b3JrLWRldmljZS1wb2xsZXIvY2xpL3JlYWQtcmVxdWVzdFwiO1xuICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKG5ldHdvcmtEZXZpY2VQb2xsZXIpXG4gICAgICAgICAgICAgIC8vY29uc29sZS5sb2coY29tbWFuZFJ1bm5lckRUTylcbiAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhuZXR3b3JrRGV2aWNlUG9sbGVyKVxuICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKGFwaWNPcHRpb25zKGNvbW1hbmRSdW5uZXJEVE8pKVxuICAgICAgICAgICAgICBjb25zdCBuZXR3b3JrRGV2aWNlUG9sbGVyQ2FsbCA9IE1ldGVvci5jYWxsKCdhcGljSHR0cFJlcXVlc3QnLFwiUE9TVFwiLG5ldHdvcmtEZXZpY2VQb2xsZXIsYXBpY09wdGlvbnMoY29tbWFuZFJ1bm5lckRUTykpO1xuICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKG5ldHdvcmtEZXZpY2VQb2xsZXJDYWxsKVxuICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKG5ldHdvcmtEZXZpY2VQb2xsZXJDYWxsLnN0YXR1c0NvZGUpXG4gICAgICAgICAgICAgIGlmIChuZXR3b3JrRGV2aWNlUG9sbGVyQ2FsbC5zdGF0dXNDb2RlID09IDIwMil7XG4gICAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhuZXR3b3JrRGV2aWNlUG9sbGVyQ2FsbC5kYXRhLnJlc3BvbnNlKVxuICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2cobmV0d29ya0RldmljZVBvbGxlckNhbGwuZGF0YS5yZXNwb25zZS51cmwpXG4gICAgICAgICAgICAgICAgY29uc3QgbmV0d29ya0RldmljZVBvbGxlclN0YXR1cyA9IGJhc2VVcmwgKyBuZXR3b3JrRGV2aWNlUG9sbGVyQ2FsbC5kYXRhLnJlc3BvbnNlLnVybDtcbiAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKG5ldHdvcmtEZXZpY2VQb2xsZXJTdGF0dXMpXG5cbiAgICAgICAgICAgICAgICByZXR1cm4gZGF0YS5uZXR3b3JrRGV2aWNlUG9sbGVyID0gdGFza1N0YXR1cyhuZXR3b3JrRGV2aWNlUG9sbGVyU3RhdHVzKTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIC8qY29uc3QgbGljZW5zZUluZm9VcmwgPSBiYXNlVXJsICsgXCIvYXBpL3YxL2xpY2Vuc2UtaW5mby9uZXR3b3JrLWRldmljZVwiICtcIi9cIisgZGF0YS5pZDtcbiAgICAgICAgICAgICAgY29uc3QgbGljZW5zZUluZm9DYWxsID0gTWV0ZW9yLmNhbGwoJ2FwaWNIdHRwUmVxdWVzdCcsXCJHRVRcIixsaWNlbnNlSW5mb1VybCxvcHRpb25zKTtcbiAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgfVxuICAgICAgICBjb25zdCBkYkluc2VydCA9IChkYkRhdGEpPT57XG4gICAgICAgICAgLy8gZGVidWdcbiAgICAgICAgICAvL2NvbnNvbGUubG9nKFwiZGJJbnNlcnQgaW5kZXggSGl0OiBcIixpbmRleClcbiAgICAgICAgICBJdGVtc0FwaWNEZXZpY2VzLmluc2VydCh7XG4gICAgICAgICAgICBzaXRlRGF0YToge1xuICAgICAgICAgICAgICBkYXRhT2JqOiBkYkRhdGEsXG4gICAgICAgICAgICAgIHJlcXVlc3RUaW1lOiB0aW1lTm93KDEwMDApLFxuICAgICAgICAgICAgICBkYXRlVGltZTogZGF0ZVRpbWVcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBkYlVwZGF0ZSA9IChkZENoZWNrLGRiRGF0YSxjVGltZSxjZFRpbWUpPT57XG4gICAgICAgICAgY29uc29sZS5sb2coXCJ1cGRhdGluZ1wiLCBkZENoZWNrKTtcbiAgICAgICAgICBjb25zb2xlLmxvZyhcImN1cnJlbnQgdGltZVwiLCBjVGltZSk7XG4gICAgICAgICAgY29uc29sZS5sb2coXCJjdXJyZW50IGRhdGUgdGltZVwiLCBjZFRpbWUpO1xuICAgICAgICAgIEl0ZW1zQXBpY0RldmljZXMudXBkYXRlKGRkQ2hlY2ssIHtcbiAgICAgICAgICAgICRzZXQ6e1xuICAgICAgICAgICAgICAnc2l0ZURhdGEuZGF0YU9iaic6ZGJEYXRhLFxuICAgICAgICAgICAgICAnc2l0ZURhdGEucmVxdWVzdFRpbWUnOmNUaW1lLFxuICAgICAgICAgICAgICAnc2l0ZURhdGEuZGF0ZVRpbWUnOmNkVGltZVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgZGJUYXNrcyA9ICgpID0+e1xuICAgICAgICBhc3luYyBmdW5jdGlvbiByZXN0RGF0YUhhbmRsZXIoKXtcbiAgICAgICAgICBjb25zdCBkYk1hdGNoID0gYXdhaXQgZmluZEl0ZW0oZGV2aWNlSWQpO1xuICAgICAgICAgIGlmIChhd2FpdCBkYk1hdGNoID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIC8vIGRlYnVnXG4gICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwidW5kZWZpbmVkXCIpXG4gICAgICAgICAgICBJdGVtc0FwaWNEZXZpY2VzLnJlbW92ZSh7XCJzaXRlRGF0YS5kYXRhT2JqLmlkXCI6ZGV2aWNlSWR9KTtcbiAgICAgICAgICAgIHZsYW5EZXRhaWwoKTtcbiAgICAgICAgICAgIGludGVyZmFjZUluZm8oKTtcbiAgICAgICAgICAgIGxpY2Vuc2VJbmZvKCk7XG4gICAgICAgICAgICBkYkluc2VydChkYXRhKTtcbiAgICAgICAgICAgIC8vIGlmIHRoZXJlIGlzIGEgbWF0Y2ggY29tcGFyZSB0aGUgbGFzdFVwZGF0ZVRpbWVzLCBpZiB0aGV5IG1hdGNoIGl0IHNraXBzXG4gICAgICAgICAgfSBlbHNlIGlmIChkYk1hdGNoLnNpdGVEYXRhLmRhdGFPYmoubGFzdFVwZGF0ZVRpbWUgPT0gbGFzdFVwZGF0ZVRpbWUpe1xuICAgICAgICAgICAgLy8gZGVidWdcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJNYXRjaCBGb3VuZFwiLGRiTWF0Y2guc2l0ZURhdGEuZGF0YU9iai5sYXN0VXBkYXRlVGltZSk7XG4gICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwiZXF1YWxpdHlcIilcbiAgICAgICAgICAgIC8vIHJlbW92ZSBtYXRjaGVzIHRoYXQgZmFpbCB0aGUgbGFzdFVwZGF0ZVRpbWUgY29tcGFyaXNvblxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBkYXRhYmFzZSBJdGVtIElEXG4gICAgICAgICAgICBjb25zdCBkYkRhdGFJRCA9IGRiTWF0Y2guX2lkO1xuICAgICAgICAgICAgLy8gZGVidWdcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJ1bmVxdWFsXCIpXG4gICAgICAgICAgICB2bGFuRGV0YWlsKCk7XG4gICAgICAgICAgICBpbnRlcmZhY2VJbmZvKCk7XG4gICAgICAgICAgICBsaWNlbnNlSW5mbygpO1xuICAgICAgICAgICAgLy8gZGlzYWJsZWQsIGJ1dCBpdCB3b3Jrc1xuICAgICAgICAgICAgLy9zaG93Q29tbWFuZHMoZG93blBvcnRDb21tYW5kQXJyYXksZGV2aWNlSWQpO1xuICAgICAgICAgICAgZGJVcGRhdGUoZGJEYXRhSUQsZGF0YSx0aW1lTm93KDEwMDApLGRhdGVUaW1lKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIC8vSXRlbXNBcGljRGV2aWNlcy5yZW1vdmUoe1wic2l0ZURhdGEuZGF0YU9iai5tYW5hZ2VtZW50SXBBZGRyZXNzXCI6bWFuYWdlbWVudElwQWRkcmVzcyxcInNpdGVEYXRhLmRhdGFPYmoubGFzdFVwZGF0ZVRpbWVcIjp7XCIkbHRlXCI6bGFzdFVwZGF0ZVRpbWV9fSk7XG4gICAgICAgIHJlc3REYXRhSGFuZGxlcigpXG4gICAgICAgIH1cbiAgICAgICAgZGJUYXNrcygpO1xuICAgICAgfSkpXG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnNvbGUubG9nKFwiUkVTVCBGQUlMVVJFOiBcIiwgYXBpY0RldmljZXMpO1xuICAgIH1cbiAgfVxuICBjb25zdCBwb2xsID0gKCkgPT4ge1xuICAgICAgY29uc29sZS5sb2coXCJyZXF1ZXN0aW5nIHVwdG8gNTAwIG9iamVjdHMgZnJvbSBBUElDLUVNXCIpXG4gICAgICBjb25zb2xlLmxvZygpXG5cbiAgICAgIGh0dHBSZXF1ZXN0KFwiR0VUXCIsZGV2aWNlc1VybCxhcGljT3B0aW9ucyhcIlwiKSlcbiAgICAgIGlmIChjb3VudENvbGxlY3Rpb25zKCkgPj0gMzAwKXtcbiAgICAgICAgY29uc29sZS5sb2coXCJvdmVyIDkwMDAhISEgYWN0dWFsbHkgaXQncyBvbmx5IG9ubHkgb3ZlciAzMDAgRGV2aWNlcyEhIVwiLGNvdW50Q29sbGVjdGlvbnMoKSlcbiAgICAgICAgY29uc29sZS5sb2coXCJyZXF1ZXN0aW5nIHVwdG8gQU5PVEhFUiA1MDAgb2JqZWN0cyBmcm9tIEFQSUMtRU1cIilcbiAgICAgICAgYXBpY0RldmljZXNVcm41MDAgPSBiYXNlVXJsK1wiL2FwaS92MS9uZXR3b3JrLWRldmljZS81MDEvNTAwXCI7XG4gICAgICAgIGh0dHBSZXF1ZXN0KFwiR0VUXCIsYXBpY0RldmljZXNVcm41MDAsYXBpY09wdGlvbnMoXCJcIikpXG4gICAgICB9XG4gIH1cbiAgY29uc3QgaW50ZXJ2YWxJZCA9IE1ldGVvci5zZXRJbnRlcnZhbCgoKT0+e1xuICAgIGNvdW50ZXIrKztcbiAgICBjb25zb2xlLmxvZyhcIkFwaWMgRGF0YSBQdWJsaXNoIG9uIGNsaWVudCBDb3VudGVyOiAlc1wiLGNvdW50ZXIpO1xuICAgIHJldHVybiBwb2xsKCk7XG4gIH0sMzAwMDAwKVxuICBwb2xsKClcbn07XG5leHBvcnQge2FwaWNEZXZpY2VzfTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IEl0ZW1zV2ViU2VydmVyU3RhdHVzIGZyb20gJy4uL2FwaS93ZWJzZXJ2ZXJTdGF0dXMnO1xuXG5sZXQgd2ViU2VydmVyU3RhdHVzID0gKHdlYlNlcnZlck9iaik9PntcbiAgY29uc3Qgc3RhdHVzQ29kZVBhcnNlciA9IChzdGF0dXNDb2RlKSA9PntcbiAgICBpZiAoc3RhdHVzQ29kZSA9PT0gMjAwKSB7XG4gICAgICByZXR1cm4gMDtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIDE7XG4gICAgfVxuICB9XG4gIGNvbnN0IGdldFRpbWVOb3cgPSAoKSA9PntcbiAgICByZXR1cm4gbmV3IERhdGUoKS5nZXRUaW1lKClcbiAgfVxuICBjb25zdCBjb252ZXJ0RGF0ZVRpbWUgPSAoZGF0ZVN0cmluZykgPT57XG4gICAgbGV0IHNvbWVEYXRlID0gbmV3IERhdGUoZGF0ZVN0cmluZyk7XG4gICAgLy9jb25zb2xlLmxvZyhzb21lRGF0ZS5nZXRUaW1lKCkpO1xuICAgIHJldHVybiBzb21lRGF0ZS5nZXRUaW1lKCk7XG4gIH1cbiAgY29uc3QgZGVsYXlDYWxjdWxhdG9yID0gKHN0YXJ0VGltZSwgZW5kVGltZSkgPT57XG4gICAgbGV0IHJlcXVlc3RUaW1lID0gKGVuZFRpbWUgLSBzdGFydFRpbWUpO1xuICAgIHJldHVybiByZXF1ZXN0VGltZTtcbiAgfVxuICBjb25zdCB0b3RhbFRpbWVDYWxjdWxhdG9yID0gKG9sZFRpbWUsIG5ld1RpbWUpID0+e1xuICAgIGxldCB0b3RhbFRpbWUgPSBvbGRUaW1lICsgbmV3VGltZTtcbiAgICByZXR1cm4gdG90YWxUaW1lO1xuICB9XG4gIGNvbnN0IGhpZ2hlc3RUaW1lQ2FsY3VsYXRvciA9IChvbGRUaW1lLCBuZXdUaW1lKSA9PntcbiAgICBpZiAobmV3VGltZSA+IG9sZFRpbWUpIHtcbiAgICAgIHJldHVybiBuZXdUaW1lO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gb2xkVGltZTtcbiAgICB9XG4gIH1cbiAgY29uc3QgbG93ZXN0VGltZUNhbGN1bGF0b3IgPSAob2xkVGltZSwgbmV3VGltZSkgPT57XG4gICAgaWYgKG5ld1RpbWUgPCBvbGRUaW1lKSB7XG4gICAgICByZXR1cm4gbmV3VGltZTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIG9sZFRpbWU7XG4gICAgfVxuICB9XG4gIGxldCBkYXRhYmFzZU9iaiA9IChuYW1lLGRlc2NyaXB0aW9uLHVybCxyVGltZSxyQ29kZSxmQ29kZSkgPT57XG4gICAgbGV0IHRhbmdvPSB7XG4gICAgICBuYW1lOiBuYW1lLFxuICAgICAgZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uLFxuICAgICAgdXJsOiB1cmwsXG4gICAgICBzdGF0aXN0aWNzOntcbiAgICAgICAgcmVzcG9uc2VUaW1lVG90YWw6IHJUaW1lLFxuICAgICAgICByZXNwb25zZVRpbWVMYXN0OiByVGltZSxcbiAgICAgICAgcmVzcG9uc2VUaW1lQ291bnQ6IDEsXG4gICAgICAgIHJlc3BvbnNlVGltZUhpZ2hlc3Q6IHJUaW1lLFxuICAgICAgICByZXNwb25zZVRpbWVMb3dlc3Q6IHJUaW1lXG4gICAgICB9LFxuICAgICAgaHR0cFJlcXVlc3Q6e1xuICAgICAgICByZXNwb25zZVN0YXR1c0NvZGU6IHJDb2RlLFxuICAgICAgICB3ZWJTZXJ2ZXJGYWlsdXJlU3RhdHVzOiBmQ29kZSxcbiAgICAgICAgd2ViU2VydmVyRmFpbHVyZWNvdW50OiAwXG4gICAgICB9XG4gICAgfTtcbiAgICByZXR1cm4gdGFuZ287XG4gIH07XG4gIGNvbnN0IHBvbGwgPSAoKSA9PiB7XG4gICAgd2ViU2VydmVyT2JqLm1hcCgoZGF0YSk9PntcbiAgICAgIC8vY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkoZGF0YSwgbnVsbCwgMikpO1xuICAgICAgY29uc3Qgd2ViU2VydmVyTWV0aG9kID0gXCJHRVRcIjtcbiAgICAgIGNvbnN0IHdlYlNlcnZlclVybCA9IGRhdGEudXJsO1xuICAgICAgY29uc3Qgd2ViU2VydmVyT3B0aW9ucyA9IHt9O1xuICAgICAgY29uc3QgY3VycmVudFRpbWUgPSBnZXRUaW1lTm93KCk7XG4gICAgICBjb25zdCBjdXJyZW50RGF0ZVRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgY29uc3Qgc3RhcnRUaW1lID0gZ2V0VGltZU5vdygpO1xuICAgICAgYXN5bmMgZnVuY3Rpb24gaHR0cFJlcXVlc3QobWV0aG9kLHVybCxvcHRpb25zKXtcbiAgICAgICAgY29uc3QgaHR0cERldmljZXMgPSBhd2FpdCBNZXRlb3IuY2FsbCgnaHR0cFJlcXVlc3QnLCBtZXRob2QsdXJsLG9wdGlvbnMpO1xuICAgICAgICBjb25zdCBodHRwUmV0dXJuID0gYXdhaXQgaHR0cERldmljZXM7XG4gICAgICAgIGlmIChhd2FpdCBodHRwUmV0dXJuKSB7XG4gICAgICAgICAgY29uc3QgZW5kVGltZSA9IGdldFRpbWVOb3coKTtcbiAgICAgICAgICAvL2NvbnNvbGUubG9nKFwiaHR0cFJlc29uc2UgXCIgKyBkYXRhLm5hbWUgLCBodHRwUmV0dXJuLmhlYWRlcnMpO1xuICAgICAgICAgIC8vY29uc29sZS5sb2coaHR0cFJldHVybi5oZWFkZXJzLmRhdGUpO1xuICAgICAgICAgIGNvbnN0IGh0dHBSZXR1cm5UaW1lID0gY29udmVydERhdGVUaW1lKGh0dHBSZXR1cm4uaGVhZGVycy5kYXRlKTtcbiAgICAgICAgICAvL2NvbnNvbGUubG9nKHN0YXR1c0NvZGVQYXJzZXIoaHR0cFJldHVybi5zdGF0dXNDb2RlKSk7XG4gICAgICAgICAgY29uc3QgZmFpbHVyZUNvZGUgPSBzdGF0dXNDb2RlUGFyc2VyKGh0dHBSZXR1cm4uc3RhdHVzQ29kZSk7XG4gICAgICAgICAgY29uc3QgaHR0cFJlc3BvbnNlQ29kZSA9IGh0dHBSZXR1cm4uc3RhdHVzQ29kZTtcbiAgICAgICAgICBjb25zdCBjdXJyZW50UmVzcG9uc2VUaW1lID0gZGVsYXlDYWxjdWxhdG9yKHN0YXJ0VGltZSxlbmRUaW1lKTtcblxuICAgICAgICAgIC8vY29uc29sZS5sb2coaHR0cFJldHVyblRpbWUrXCIgXCIrY3VycmVudFRpbWUpXG4gICAgICAgICAgLy9jb25zb2xlLmxvZyhkYXRhLm5hbWUpXG4gICAgICAgICAgLy9jb25zb2xlLmxvZyhkYXRhLnVybClcbiAgICAgICAgICAvL2NvbnNvbGUubG9nKGRhdGEuZGVzY3JpcHRpb24pXG4gICAgICAgICAgLy9jb25zb2xlLmxvZyhodHRwUmV0dXJuLnN0YXR1c0NvZGUpXG4gICAgICAgICAgLy9jb25zb2xlLmxvZyhmYWlsdXJlQ29kZSlcbiAgICAgICAgICAvL2NvbnNvbGUubG9nKGRlbGF5Q2FsY3VsYXRvcihjdXJyZW50VGltZSxodHRwUmV0dXJuVGltZSkpXG4gICAgICAgICAgLy9jb25zb2xlLmxvZyhcIlN0YXJ0UmF3IGVuZFJhdzogXCIsIHN0YXJ0VGltZStcIiBcIitlbmRUaW1lKVxuICAgICAgICAgIC8vY29uc29sZS5sb2coXCJTdGFydCBhbmQgRW5kdGltZSBcIixkZWxheUNhbGN1bGF0b3Ioc3RhcnRUaW1lLGVuZFRpbWUpKVxuXG4gICAgICAgICAgLy8gZXJyb3IgY2hlY2tpbmcgUkVTVCByZXF1ZXN0LiBJZiBub3QgMjAwIGRvIG5vdGhpbmcgYW5kIGxvZ1xuICAgICAgICAgIC8vIGh0dHAgc3RhdHVzIGNvZGVcblxuICAgICAgICAgIC8vIHdlYlNlcnZlcnMgbmFtZVxuXG4gICAgICAgICAgLy8gbGFuZ3VhZ2UgZGlzY3JpYmluZyB0aGUgc2VydmVyXG5cbiAgICAgICAgICAvLyAwIHJldHVybmVkIG9uIHN0YXR1cyBjb2RlIDIwMCwgMSByZXR1cm5lZCBvbiBhbGwgZWxzZVxuXG5cbiAgICAgICAgICBjb25zdCBkYkRhdGFDaGVjayA9IEl0ZW1zV2ViU2VydmVyU3RhdHVzLmZpbmQoe1wid2ViU2VydmVyRGF0YS5kYXRhT2JqLm5hbWVcIjpkYXRhLm5hbWV9KS5mZXRjaCgpO1xuICAgICAgICAgIC8vY29uc29sZS5sb2coXCJkYXRhQ2hlY2sgOiBcIixkYkRhdGFDaGVjayk7XG5cbiAgICAgICAgICBjb25zdCBkYkluc2VydCA9IChkRGF0YSxjVGltZSxkVGltZSk9PntcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJpbnNlcnQgQXR0ZW1wdFwiKVxuICAgICAgICAgICAgSXRlbXNXZWJTZXJ2ZXJTdGF0dXMuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgd2ViU2VydmVyRGF0YToge1xuICAgICAgICAgICAgICAgIGRhdGFPYmo6IGREYXRhLFxuICAgICAgICAgICAgICAgIHJlcXVlc3RUaW1lOiBjVGltZSxcbiAgICAgICAgICAgICAgICBkYXRlVGltZTogZFRpbWVcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IGRiVXBkYXRlID0gKGRkQ2hlY2ssdHJUaW1lLGNyVGltZSxoclRpbWUsbHJUaW1lLGh0dHBDb2RlLGZDb2RlLGN3ZkNvdW50LGNUaW1lLGNkVGltZSk9PntcbiAgICAgICAgICAgIEl0ZW1zV2ViU2VydmVyU3RhdHVzLnVwZGF0ZShkZENoZWNrW1wiMFwiXS5faWQsIHtcbiAgICAgICAgICAgICAgJGluYzp7XG4gICAgICAgICAgICAgICAgJ3dlYlNlcnZlckRhdGEuZGF0YU9iai5zdGF0aXN0aWNzLnJlc3BvbnNlVGltZUNvdW50JzoxXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICRzZXQ6e1xuICAgICAgICAgICAgICAgICd3ZWJTZXJ2ZXJEYXRhLmRhdGFPYmouc3RhdGlzdGljcy5yZXNwb25zZVRpbWVUb3RhbCc6dHJUaW1lLFxuICAgICAgICAgICAgICAgICd3ZWJTZXJ2ZXJEYXRhLmRhdGFPYmouc3RhdGlzdGljcy5yZXNwb25zZVRpbWVMYXN0JzpjclRpbWUsXG4gICAgICAgICAgICAgICAgJ3dlYlNlcnZlckRhdGEuZGF0YU9iai5zdGF0aXN0aWNzLnJlc3BvbnNlVGltZUhpZ2hlc3QnOmhyVGltZSxcbiAgICAgICAgICAgICAgICAnd2ViU2VydmVyRGF0YS5kYXRhT2JqLnN0YXRpc3RpY3MucmVzcG9uc2VUaW1lTG93ZXN0JzpsclRpbWUsXG4gICAgICAgICAgICAgICAgJ3dlYlNlcnZlckRhdGEuZGF0YU9iai5odHRwUmVxdWVzdC5yZXNwb25zZVN0YXR1c0NvZGUnOmh0dHBDb2RlLFxuICAgICAgICAgICAgICAgICd3ZWJTZXJ2ZXJEYXRhLmRhdGFPYmouaHR0cFJlcXVlc3Qud2ViU2VydmVyRmFpbHVyZVN0YXR1cyc6ZkNvZGUsXG4gICAgICAgICAgICAgICAgJ3dlYlNlcnZlckRhdGEuZGF0YU9iai5odHRwUmVxdWVzdC53ZWJTZXJ2ZXJGYWlsdXJlY291bnQnOmN3ZkNvdW50LFxuICAgICAgICAgICAgICAgICd3ZWJTZXJ2ZXJEYXRhLnJlcXVlc3RUaW1lJzpjVGltZSxcbiAgICAgICAgICAgICAgICAnd2ViU2VydmVyRGF0YS5kYXRlVGltZSc6Y2RUaW1lXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoZGJEYXRhQ2hlY2subGVuZ3RoID49IDEpIHtcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJDaGVjayBQYXNzZWRcIilcbiAgICAgICAgICAgIGNvbnN0IGRiUmVzcG9uc2VUaW1lVG90YWwgPSBkYkRhdGFDaGVja1tcIjBcIl0ud2ViU2VydmVyRGF0YS5kYXRhT2JqLnN0YXRpc3RpY3MucmVzcG9uc2VUaW1lVG90YWw7XG4gICAgICAgICAgICBjb25zdCBkYkhpZ2hlc3RUaW1lID0gZGJEYXRhQ2hlY2tbXCIwXCJdLndlYlNlcnZlckRhdGEuZGF0YU9iai5zdGF0aXN0aWNzLnJlc3BvbnNlVGltZUhpZ2hlc3Q7XG4gICAgICAgICAgICBjb25zdCBkYkxvd2VzdFRpbWUgPSBkYkRhdGFDaGVja1tcIjBcIl0ud2ViU2VydmVyRGF0YS5kYXRhT2JqLnN0YXRpc3RpY3MucmVzcG9uc2VUaW1lTG93ZXN0O1xuICAgICAgICAgICAgY29uc3QgY3VycmVudFdlYlNlcnZlckZhaWx1cmVjb3VudCA9IGRiRGF0YUNoZWNrW1wiMFwiXS53ZWJTZXJ2ZXJEYXRhLmRhdGFPYmouaHR0cFJlcXVlc3Qud2ViU2VydmVyRmFpbHVyZWNvdW50ICsgZmFpbHVyZUNvZGU7XG4gICAgICAgICAgICBjb25zdCB0b3RhbFJlc3BvbnNlVGltZSA9IHRvdGFsVGltZUNhbGN1bGF0b3IoZGJSZXNwb25zZVRpbWVUb3RhbCxjdXJyZW50UmVzcG9uc2VUaW1lKTtcbiAgICAgICAgICAgIGNvbnN0IGhpZ2hlc3RSZXBvbnNlVGltZSA9IGhpZ2hlc3RUaW1lQ2FsY3VsYXRvcihkYkhpZ2hlc3RUaW1lLGN1cnJlbnRSZXNwb25zZVRpbWUpO1xuICAgICAgICAgICAgY29uc3QgbG93ZXN0UmVzcG9uc2VUaW1lID0gbG93ZXN0VGltZUNhbGN1bGF0b3IoZGJMb3dlc3RUaW1lLGN1cnJlbnRSZXNwb25zZVRpbWUpO1xuICAgICAgICAgICAgZGJVcGRhdGUoZGJEYXRhQ2hlY2ssdG90YWxSZXNwb25zZVRpbWUsY3VycmVudFJlc3BvbnNlVGltZSxoaWdoZXN0UmVwb25zZVRpbWUsXG4gICAgICAgICAgICAgIGxvd2VzdFJlc3BvbnNlVGltZSxodHRwUmVzcG9uc2VDb2RlLGZhaWx1cmVDb2RlLGN1cnJlbnRXZWJTZXJ2ZXJGYWlsdXJlY291bnQsXG4gICAgICAgICAgICAgIGN1cnJlbnRUaW1lLGN1cnJlbnREYXRlVGltZSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJDaGVjayBGYWlsZWRcIilcbiAgICAgICAgICAgIGNvbnN0IGRCZGF0YSA9IGRhdGFiYXNlT2JqKGRhdGEubmFtZSAsIGRhdGEuZGVzY3JpcHRpb24gLCBkYXRhLnVybCwgY3VycmVudFJlc3BvbnNlVGltZSAsaHR0cFJlc3BvbnNlQ29kZSAsZmFpbHVyZUNvZGUpO1xuICAgICAgICAgICAgZGJJbnNlcnQoZEJkYXRhLGN1cnJlbnRUaW1lLGN1cnJlbnREYXRlVGltZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBodHRwUmVxdWVzdCh3ZWJTZXJ2ZXJNZXRob2Qsd2ViU2VydmVyVXJsLHdlYlNlcnZlck9wdGlvbnMpXG4gICAgfSlcbiAgfVxuICBjb25zdCBpbnRlcnZhbElkID0gTWV0ZW9yLnNldEludGVydmFsKCgpPT57XG4gICAgLy9jb25zb2xlLmxvZyhcInBvbGwgaGl0XCIpO1xuICAgIHJldHVybiBwb2xsKCk7XG4gIH0sMTUwMDApXG4gIHBvbGwoKVxuICBsZXQgZGVidWdIZWxwZXIxID0gXCJEZWJ1ZyBoZWxwZXJcIlxuICByZXR1cm4gZGVidWdIZWxwZXIxO1xufTtcbmNvbnN0IGJsYWggPSAodGV4dCkgPT57XG4gIGxldCB0ZXh0MSA9IFwidGhpcyBpcyBibGFoIGRlZmF1bHRcIlxuICBsZXQgdGV4dDIgPSB0ZXh0XG4gIHJldHVybiB0ZXh0MSArPSB0ZXh0MlxufTtcbmV4cG9ydCB7d2ViU2VydmVyU3RhdHVzLGJsYWh9O1xuIiwibW9kdWxlLmV4cG9ydHMgPSB7XG4gIHRlbXBEYXRhMDogKCkgPT4ge1xuICAgIGxldCBkYXRhID0gXCJcIjtcbiAgICByZXR1cm4gZGF0YTtcblxuICB9LFxuICB0ZW1wRGF0YTE6ICgpID0+IHtcbiAgICBsZXQgZGF0YSA9IFwiXCI7XG4gICAgcmV0dXJuIGRhdGE7XG4gIH0sXG4gIHRlbXBEYXRhMjogKCkgPT4ge1xuICAgIGxldCBkYXRhID0gXCJcIjtcbiAgICByZXR1cm4gZGF0YTtcbiAgfSxcbiAgdGVtcERhdGEzOiAoKSA9PiB7XG4gICAgbGV0IGRhdGEgPSBcIlwiO1xuICAgIHJldHVybiBkYXRhO1xuICB9XG59XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFJhbmRvbSB9IGZyb20gJ21ldGVvci9yYW5kb20nO1xuaW1wb3J0IEl0ZW1zIGZyb20gJy4uL2ltcG9ydHMvYXBpL0l0ZW1zJztcbmltcG9ydCBJdGVtc1BydGcgZnJvbSAnLi4vaW1wb3J0cy9hcGkvcHJ0Zyc7XG5pbXBvcnQgSXRlbXNBcGljRGV2aWNlcyBmcm9tICcuLi9pbXBvcnRzL2FwaS9hcGljJztcbmltcG9ydCBJdGVtc1RyYW5zZmVyUmF0ZSBmcm9tICcuLi9pbXBvcnRzL2FwaS90cmFuc2ZlclJhdGUnO1xuaW1wb3J0IEl0ZW1zUHJpbWVIb3N0cyBmcm9tICcuLi9pbXBvcnRzL2FwaS9wcmltZSc7XG5pbXBvcnQgSXRlbXNXZWJTZXJ2ZXJTdGF0dXMgZnJvbSAnLi4vaW1wb3J0cy9hcGkvd2Vic2VydmVyU3RhdHVzJztcbmltcG9ydCB0ZW1wRGF0YSBmcm9tICcuL3RlbXBEYXRhJztcblxuaW1wb3J0IHsgd2ViU2VydmVyU3RhdHVzLCBibGFoIH0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2ZXIvd2ViU2VydmVyU3RhdHVzJztcbmltcG9ydCB7IGFwaWNEZXZpY2VzfSBmcm9tICcuLi9pbXBvcnRzL3NlcnZlci9hcGljRGV2aWNlcyc7XG5cbmltcG9ydCAnLi4vaW1wb3J0cy9hcGkvd2Vic2VydmVyU3RhdHVzJztcbmltcG9ydCAnLi4vaW1wb3J0cy9zZXJ2ZXIvYWNjb3VudHMnO1xuaW1wb3J0ICcuLi9pbXBvcnRzL2FwaS9yZXF1ZXN0JztcbmltcG9ydCAnLi4vaW1wb3J0cy9hcGkvcHJ0Zyc7XG5pbXBvcnQgJy4uL2ltcG9ydHMvYXBpL3RyYW5zZmVyUmF0ZSc7XG5pbXBvcnQgJy4uL2ltcG9ydHMvYXBpL2FwaWMnO1xuaW1wb3J0ICcuLi9pbXBvcnRzL2FwaS9wcmltZSc7XG5cblxuXG53ZWJTZXJ2ZXJTdGF0dXMoTWV0ZW9yLnNldHRpbmdzLndlYlNlcnZlckxpc3QpO1xuTWV0ZW9yLnB1Ymxpc2goJ3dlYlNlcnZlclN0YXR1cycsIGZ1bmN0aW9uKCkge1xuXG4gIGxldCBjbGllbnRJZCA9IGZhbHNlO1xuICBsZXQgY291bnRlciA9IDA7XG4gIGNvbnN0IHNlbGYgPSB0aGlzO1xuICBjb25zdCBjbGllbnRJZGVudCA9IHtcbiAgICBjbGllbnRJcDogXCJcIixcbiAgICBjbGllbnRJZDpmYWxzZSxcbiAgICBzZXRJcDogZnVuY3Rpb24oaXApe1xuICAgICAgaWYgKHRoaXMuY2xpZW50SWQgPT09IGZhbHNlKXtcbiAgICAgICAgdGhpcy5jbGllbnRJZCA9IGlwK1wiIDogXCIrUmFuZG9tLmlkKCk7XG4gICAgICAgIC8vY29uc29sZS5sb2coXCJkYXRhXCIsdGhpcy5jbGllbnRJZCk7XG4gICAgICAgIHJldHVybiB0aGlzLmNsaWVudElkO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy9jb25zb2xlLmxvZyhcImRhdGFcIix0aGlzLmNsaWVudElkKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuY2xpZW50SWQ7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGNvbnN0IGNvdW50Q29sbGVjdGlvbnMgPSAoKT0+e1xuICAgIHJldHVybiBJdGVtc1dlYlNlcnZlclN0YXR1cy5maW5kKCkuY291bnQoKTtcbiAgfVxuICBjb25zdCBtaW5pTW9uZ28gPSAoKT0+e1xuICAgIHJldHVybiBJdGVtc1dlYlNlcnZlclN0YXR1cy5maW5kKCk7XG4gIH1cblxuICBjb25zb2xlLmxvZyhcIkl0ZW1zV2ViU2VydmVyU3RhdHVzIENvdW50OiBcIixjb3VudENvbGxlY3Rpb25zKCkpO1xuXG4gIGNvbnN0IHBvbGwgPSAoKSA9PiB7XG4gICAgcmV0dXJuIG1pbmlNb25nbygpO1xuICB9XG4gIGNvbnN0IGludGVydmFsSWQgPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoKCk9PntcbiAgICBjb3VudGVyKys7XG4gICAgY29uc29sZS5sb2coXCJJdGVtc1dlYlNlcnZlclN0YXR1cyBEYXRhIFB1Ymxpc2ggb24gY2xpZW50ICVzIENvdW50ZXI6ICVzXCIsY2xpZW50SWRlbnQuc2V0SXAodGhpcy5jb25uZWN0aW9uLmNsaWVudEFkZHJlc3MpLGNvdW50ZXIpO1xuICAgIHJldHVybiBwb2xsKCk7XG4gIH0sMzAwMDAwKVxuICBzZWxmLm9uU3RvcCgoKT0+e1xuICAgIGNvbnNvbGUubG9nKFwiVGVybWluYXRpbmcgSXRlbXNXZWJTZXJ2ZXJTdGF0dXMgUHVibGlzaCBvbiBjbGllbnQgJXMgQ291bnRlciBBZnRlcjogJXNcIixjbGllbnRJZGVudC5zZXRJcCh0aGlzLmNvbm5lY3Rpb24uY2xpZW50QWRkcmVzcyksY291bnRlcik7XG4gICAgTWV0ZW9yLmNsZWFySW50ZXJ2YWwoaW50ZXJ2YWxJZClcbiAgfSlcbiAgcmV0dXJuIHBvbGwoKVxufSk7XG5cblxuXG5cblxuXG5cblxuXG5cblxuXG4vL3B1Ymxpc2ggdXNlciBkYXRhIGluIG1pbmkgbW9uZ29cbk1ldGVvci5wdWJsaXNoKCdjdXJyZW50VXNlcicsIGZ1bmN0aW9uKCkge1xuICByZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmQoe19pZDogdGhpcy51c2VySUR9LCB7XG4gICAgZmllbGRzOiB7XG4gICAgICByb2xlczogMVxuICAgIH1cbiAgfSk7XG59KTtcblxuXG5NZXRlb3IucHVibGlzaCgncHJpbWVIb3N0cycsIGZ1bmN0aW9uKCkge1xuICBsZXQgY291bnRDb2xsZWN0aW9ucyA9IEl0ZW1zUHJpbWVIb3N0cy5maW5kKCkuY291bnQoKTtcbiAgbGV0IHRpbWVOb3cgPSBNYXRoLnJvdW5kKG5ldyBEYXRlKCkuZ2V0VGltZSgpIC8gMTAwMCk7XG4gIGxldCBkYXRlVGltZSA9IG5ldyBEYXRlKCk7XG4gIGxldCBiYXNlVXJsID0gTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUucHJpbWUudU5hbWUgPyBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5wcmltZS5iYXNlVXJsIDogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaXNjb0FwaWNFTS5iYXNlVXJsO1xuICBsZXQgdU5hbWUgPSBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5wcmltZS51TmFtZSA/IE1ldGVvci5zZXR0aW5ncy5wcml2YXRlLnByaW1lLnVOYW1lIDogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaXNjb0FwaWNFTS51TmFtZTtcbiAgbGV0IHVQYXNzID0gTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUucHJpbWUudU5hbWUgPyBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5wcmltZS51UGFzcyA6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2lzY29BcGljRU0udVBhc3M7XG4gIGxldCBwcmltZUxvb2t1cFVybiA9ICcvd2ViYWNzL2FwaS92MS9kYXRhL0NsaWVudHMuanNvbj8uZnVsbD10cnVlJnNlY3VyaXR5UG9saWN5U3RhdHVzPWVxKFwiRkFJTEVEXCIpJi5tYXhSZXN1bHRzPTQwMCc7XG4gIGxldCBkZXZpY2VzVXJsID0gYmFzZVVybCArIHByaW1lTG9va3VwVXJuO1xuICBsZXQgcHJpbWVPcHRpb25zID0ge1xuICAgIGhlYWRlcnM6IHsgJ2F1dGhvcml6YXRpb24nOiB1TmFtZStcIiBcIit1UGFzcywgXCJhY2NlcHRcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfVxuICB9O1xuICBsZXQgaHR0cFJldHVybiA9IE1ldGVvci5jYWxsKCdwcmltZUh0dHBSZXF1ZXN0JywgXCJHRVRcIixkZXZpY2VzVXJsLHByaW1lT3B0aW9ucyk7XG4gIC8vbGV0IGFwaWNUaWNrZXQgPSBodHRwVGlja2V0LmRhdGEucmVzcG9uc2Uuc2VydmljZVRpY2tldDtcbiAgbGV0IHByaW1lSG9zdHMgPSBodHRwUmV0dXJuLmNvbnRlbnRcbiAgLy9jb25zb2xlLmxvZyhodHRwUmV0dXJuKVxuICAvLyBmb3Igd2hhdGV2ZXIgcmVhc29uIGl0J3MgcmV0dXJuZWQgYXMgYSBzdHJpbmcgZnJvbSBwcmltZS4uLlxuICBwcmltZUhvc3RzID0gSlNPTi5wYXJzZShodHRwUmV0dXJuLmNvbnRlbnQpXG4gIGlmIChjb3VudENvbGxlY3Rpb25zIDw9IDApe1xuICAgIHByaW1lSG9zdHMucXVlcnlSZXNwb25zZS5lbnRpdHkubWFwKChkYXRhKT0+e1xuICAgICAgSXRlbXNQcmltZUhvc3RzLmluc2VydCh7XG4gICAgICAgICAgaG9zdERhdGE6IHtcbiAgICAgICAgICAgIGRhdGFPYmo6IGRhdGEsXG4gICAgICAgICAgICByZXF1ZXN0VGltZTogdGltZU5vdyxcbiAgICAgICAgICAgIGRhdGVUaW1lOiBkYXRlVGltZVxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfSlcbiAgICByZXR1cm4gSXRlbXNQcmltZUhvc3RzLmZpbmQoKVxuICB9IGVsc2Uge1xuICAgIGxldCBjdXJyZW50VGltZUVwb2NoID0gTWF0aC5yb3VuZChuZXcgRGF0ZSgpLmdldFRpbWUoKS8xMDAwKTtcbiAgICAvLyByZXR1cm5zIHRoZSBvbGRlc3QgREIgaXRlbXMgZXBvY2ggdGltZXN0YW1wXG4gICAgbGV0IG9sZGVzdERvY3VtZW50ID0gSXRlbXNQcmltZUhvc3RzLmZpbmQoe30se3NvcnQ6e1wiaG9zdERhdGEucmVxdWVzdFRpbWVcIjogLTF9LGZpZWxkczp7XCJob3N0RGF0YS5yZXF1ZXN0VGltZVwiOiAxLF9pZDowfSxsaW1pdDoxfSkuZmV0Y2goKTtcbiAgICBsZXQgb2xkZXN0RG9jdW1lbnRFcG9jaCA9IG9sZGVzdERvY3VtZW50WzBdLmhvc3REYXRhLnJlcXVlc3RUaW1lO1xuICAgIGlmIChjdXJyZW50VGltZUVwb2NoIC0gb2xkZXN0RG9jdW1lbnRFcG9jaCA+IDEyMCkge1xuICAgICAgSXRlbXNQcmltZUhvc3RzLnJlbW92ZSh7XCJob3N0RGF0YS5yZXF1ZXN0VGltZVwiOiB7XCIkbHRlXCIgOiBNYXRoLnJvdW5kKG5ldyBEYXRlKCkuZ2V0VGltZSgpLzEwMDAgLSAzMCkgfX0pO1xuICAgICAgY29uc29sZS5sb2coXCJQcmltZSBEZXZpY2VzIERCIFNUQUxFIFJlcXVlc3RpbmcgTkVXIGRhdGFcIilcbiAgICAgIHByaW1lSG9zdHMucXVlcnlSZXNwb25zZS5lbnRpdHkubWFwKChkYXRhKT0+e1xuICAgICAgICBJdGVtc1ByaW1lSG9zdHMuaW5zZXJ0KHtcbiAgICAgICAgICAgIGhvc3REYXRhOiB7XG4gICAgICAgICAgICAgIGRhdGFPYmo6IGRhdGEsXG4gICAgICAgICAgICAgIHJlcXVlc3RUaW1lOiB0aW1lTm93LFxuICAgICAgICAgICAgICBkYXRlVGltZTogZGF0ZVRpbWVcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgIH0pXG4gICAgICByZXR1cm4gSXRlbXNQcmltZUhvc3RzLmZpbmQoKVxuICAgIH1cbiAgICByZXR1cm4gSXRlbXNQcmltZUhvc3RzLmZpbmQoKVxuICB9XG59KTtcblxuXG5cblxuXG5cbmFwaWNEZXZpY2VzKCk7XG5cbk1ldGVvci5wdWJsaXNoKCdhcGljRGV2aWNlcycsIGZ1bmN0aW9uKCkge1xuICBsZXQgY2xpZW50SWQgPSBmYWxzZTtcbiAgbGV0IGNvdW50ZXIgPSAwO1xuICBjb25zdCBzZWxmID0gdGhpcztcbiAgY29uc3QgY2xpZW50SWRlbnQgPSB7XG4gICAgY2xpZW50SXA6IFwiXCIsXG4gICAgY2xpZW50SWQ6ZmFsc2UsXG4gICAgc2V0SXA6IGZ1bmN0aW9uKGlwKXtcbiAgICAgIGlmICh0aGlzLmNsaWVudElkID09PSBmYWxzZSl7XG4gICAgICAgIHRoaXMuY2xpZW50SWQgPSBpcCtcIiA6IFwiK1JhbmRvbS5pZCgpO1xuICAgICAgICAvL2NvbnNvbGUubG9nKFwiZGF0YVwiLHRoaXMuY2xpZW50SWQpO1xuICAgICAgICByZXR1cm4gdGhpcy5jbGllbnRJZDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vY29uc29sZS5sb2coXCJkYXRhXCIsdGhpcy5jbGllbnRJZCk7XG4gICAgICAgIHJldHVybiB0aGlzLmNsaWVudElkO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBjb25zdCBjb3VudENvbGxlY3Rpb25zID0gKCk9PntcbiAgICByZXR1cm4gSXRlbXNBcGljRGV2aWNlcy5maW5kKCkuY291bnQoKTtcbiAgfVxuICBjb25zdCBtaW5pTW9uZ28gPSAoKT0+e1xuICAgIHJldHVybiBJdGVtc0FwaWNEZXZpY2VzLmZpbmQoXG4gICAgICB7fSxcbiAgICAgIHtmaWVsZHM6e1xuICAgICAgICBcInNpdGVEYXRhLmRhdGFPYmouZmFtaWx5XCI6MSxcbiAgICAgICAgXCJzaXRlRGF0YS5kYXRhT2JqLmhvc3RuYW1lXCI6IDEsXG4gICAgICAgIFwic2l0ZURhdGEuZGF0YU9iai5yb2xlXCI6IDEsXG4gICAgICAgIFwic2l0ZURhdGEuZGF0YU9iai5sYXN0VXBkYXRlZFwiOjEsXG4gICAgICAgIFwic2l0ZURhdGEuZGF0YU9iai5tYW5hZ2VtZW50SXBBZGRyZXNzXCI6MSxcbiAgICAgICAgXCJzaXRlRGF0YS5kYXRhT2JqLnNvZnR3YXJlVmVyc2lvblwiOjEsXG4gICAgICAgIFwic2l0ZURhdGEuZGF0YU9iai51cFRpbWVcIjoxLFxuICAgICAgICBcInNpdGVEYXRhLmRhdGFPYmouaW50ZXJmYWNlQ291bnRcIjoxLFxuICAgICAgICBcInNpdGVEYXRhLmRhdGFPYmouc2VyaWVzXCI6MSxcbiAgICAgICAgXCJzaXRlRGF0YS5kYXRhT2JqLnNlcmlhbE51bWJlclwiOjEsXG4gICAgICAgIFwic2l0ZURhdGEuZGF0YU9iai5yZWFjaGFiaWxpdHlTdGF0dXNcIjoxLFxuICAgICAgICBcInNpdGVEYXRhLmRhdGFPYmoubm9ybWFsaXplSG9zdE5hbWVcIjoxLFxuICAgICAgICBcInNpdGVEYXRhLmRhdGFPYmouaWRcIjoxLFxuICAgICAgICBcInNpdGVEYXRhLmRhdGFPYmoudmxhbkRldGFpbFwiOjEsXG4gICAgICAgIFwic2l0ZURhdGEuZGF0YU9iai5yZWFjaGFiaWxpdHlGYWlsdXJlUmVhc29uXCI6MSxcbiAgICAgICAgXCJzaXRlRGF0YS5kYXRhT2JqLmludGVyZmFjZURldGFpbFwiOjEsXG4gICAgICAgIFwic2l0ZURhdGEuZGF0YU9iai5saWNlbnNlRGV0YWlsXCI6MSxcbiAgICAgICAgXCJzaXRlRGF0YS5kYXRhT2JqLmNvbW1hbmRSdW5uZXJcIjoxXG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBjb25zb2xlLmxvZyhcImFwaWNEZXZpY2VzIENvdW50OiBcIixjb3VudENvbGxlY3Rpb25zKCkpO1xuXG4gIGNvbnN0IHBvbGwgPSAoKSA9PiB7XG4gICAgcmV0dXJuIG1pbmlNb25nbygpO1xuICB9XG4gIGNvbnN0IGludGVydmFsSWQgPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoKCk9PntcbiAgICBjb3VudGVyKys7XG4gICAgY29uc29sZS5sb2coXCJBcGljIERhdGEgUHVibGlzaCBvbiBjbGllbnQgJXMgQ291bnRlcjogJXNcIixjbGllbnRJZGVudC5zZXRJcCh0aGlzLmNvbm5lY3Rpb24uY2xpZW50QWRkcmVzcyksY291bnRlcik7XG4gICAgcmV0dXJuIHBvbGwoKTtcbiAgfSwzMDAwMDApXG4gIHNlbGYub25TdG9wKCgpPT57XG4gICAgY29uc29sZS5sb2coXCJUZXJtaW5hdGluZyBBcGljIFB1Ymxpc2ggb24gY2xpZW50ICVzIENvdW50ZXIgQWZ0ZXI6ICVzXCIsY2xpZW50SWRlbnQuc2V0SXAodGhpcy5jb25uZWN0aW9uLmNsaWVudEFkZHJlc3MpLGNvdW50ZXIpO1xuICAgIE1ldGVvci5jbGVhckludGVydmFsKGludGVydmFsSWQpXG4gIH0pXG4gIHJldHVybiBwb2xsKClcbn0pO1xuXG5cblxuXG5cblxuXG5cblxuTWV0ZW9yLnB1Ymxpc2goJ3NpdGVDaXJjdWl0SW5mbycsIGZ1bmN0aW9uKCkge1xuICBsZXQgY291bnRDb2xsZWN0aW9ucyA9IEl0ZW1zVHJhbnNmZXJSYXRlLmZpbmQoKS5jb3VudCgpO1xuICBjb25zb2xlLmxvZyhNZXRlb3IuY2FsbCgnZ2V0RGF0ZUlTTycpKTtcblxuICBpZiAoY291bnRDb2xsZWN0aW9ucyA8PSAwKXtcbiAgICBsZXQgc2l0ZXNPYmogPSB0ZW1wRGF0YTtcbiAgICAvL2RlYnVnXG4gICAgLy9jb25zb2xlLmxvZyhzaXRlc09iai50ZW1wRGF0YTAoKSlcbiAgICBsZXQgdGVtcCA9IHNpdGVzT2JqLnRlbXBEYXRhMCgpO1xuICAgIGxldCB0aW1lTm93ID0gTWF0aC5yb3VuZChuZXcgRGF0ZSgpLmdldFRpbWUoKSAvIDEwMDApO1xuICAgIGxldCBkYXRlVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgLy9jb25zb2xlLmxvZyhuZXdEYXRhLnNlbnNvcnNbdmFsdWVdLm9iamlkKVxuICAgIC8vY29uc29sZS5sb2codHlwZW9mKG5ld0RhdGEuc2Vuc29yc1t2YWx1ZV0ub2JqaWQpKVxuICAgIC8vY29uc29sZS5sb2coXCJEQVRBIElEIFwiLGRhdGEuX2lkKVxuICAgIHRlbXAubWFwKChkYXRhKT0+e1xuICAgICAgSXRlbXNUcmFuc2ZlclJhdGUuaW5zZXJ0KHtcbiAgICAgICAgICBzaXRlRGF0YToge1xuICAgICAgICAgICAgZGF0YU9iajogZGF0YSxcbiAgICAgICAgICAgIHJlcXVlc3RUaW1lOiB0aW1lTm93LFxuICAgICAgICAgICAgZGF0ZVRpbWU6IGRhdGVUaW1lXG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9KTtcbiAgLy8gcmV0dXJuIHJlYWR5IHRvIGxvYWQgcGFnZSwgZG9lcyBub3QgY2hlY2sgZGF0YSB2YWxpZGl0eVxuICByZXR1cm4gSXRlbXNUcmFuc2ZlclJhdGUuZmluZCgpXG59IGVsc2Uge1xuICByZXR1cm4gSXRlbXNUcmFuc2ZlclJhdGUuZmluZCgpO1xufVxuXG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ3BydGdEZXZpY2VMaXN0JywgZnVuY3Rpb24oKSB7XG4gIGxldCBjb3VudENvbGxlY3Rpb25zID0gSXRlbXNQcnRnLmZpbmQoKS5jb3VudCgpO1xuICBjb25zb2xlLmxvZyhjb3VudENvbGxlY3Rpb25zKTtcbiAgLypcbiAgICBkYXRhIGNvbnRhaW5zIHRoZSBlbnRpcmUgcmV0dXJuIG9iamVjdFxuICAgIGRhdGEuY29udGVudCBjb250YWlucyB0aGUgY29udGVudHNcbiAgICBoZWFkZXJzIGNvbnRhaW5zIHRoZSBoZWFkZXJzXG4gICAgZGF0YS5kYXRhLnNlbnNvcnMgY29udGFpbnMgYW4gYXJyYXkgb2Ygb2JqZWN0c1xuICAgIGRhdGEuc3RhdHVzQ29kZSBjb250YWlucyBzdGF0dXMgY29kZVxuICAgIHBydGcgZGF0YSByZXR1cm5zIHRoZSBmb2xsb3dpbmc6XG4gICAgc3RhdHVzQ29kZTogMjAwLFxuICAgIGNvbnRlbnQ6ICd7XCJwcnRnLXZlcnNpb25cIjpcIjE3LjIuMzAuMTc2N1wiLFwidHJlZXNpemVcIjo3MTksXCJzZW5zb3JzXCI6W119XG4gICovXG4gIGxldCB0eXBlID0gXCJHRVRcIjtcbiAgbGV0IGJhc2VVcmwgPSBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5wcnRnUmVzdC5iYXNlVXJsO1xuICBsZXQgdU5hbWUgPSBNZXRlb3Iuc2V0dGluZ3MucHJpdmF0ZS5wcnRnUmVzdC51TmFtZTtcbiAgbGV0IHVQYXNzID0gTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUucHJ0Z1Jlc3QudVBhc3M7XG4gIGxldCB1Q3JlZHMgPSBcIiZ1c2VybmFtZT1cIit1TmFtZStcIiZwYXNzaGFzaD1cIit1UGFzcztcbiAgbGV0IHVybCA9IGJhc2VVcmwrXCIvYXBpL3RhYmxlLmpzb24/Y29udGVudD1zZW5zb3JzJm91dHB1dD1qc29uJmNvbHVtbnM9b2JqaWQscHJvYmUsZ3JvdXAsZGV2aWNlLHNlbnNvcixzdGF0dXMsbWVzc2FnZSxsYXN0dmFsdWUscHJpb3JpdHksZmF2b3JpdGUmY291bnQ9MjAwMDBcIit1Q3JlZHM7XG4gIGxldCBvcHRpb25zO1xuICBsZXQgYWdlbnQ7XG4gIGNvbnN0IHB1Ymxpc2hlZEtleXMgPSB7fTtcbiAgaWYoY291bnRDb2xsZWN0aW9ucyA8PSAwKXtcbiAgICBjb25zb2xlLmxvZyhcIkhJVCBDT1VOVCBDT0xMRUNUSU9OIEZBSUxVUkUgPD0gMFwiKVxuICAgIGNvbnN0IHBvbGwgPSAoKSA9PiB7XG4gICAgICAvLyBMZXQncyBhc3N1bWUgdGhlIGRhdGEgY29tZXMgYmFjayBhcyBhbiBhcnJheSBvZiBKU09OIGRvY3VtZW50cywgd2l0aCBhbiBfaWQgZmllbGQsIGZvciBzaW1wbGljaXR5XG4gICAgICBjb25zdCBkYXRhID0gSFRUUC5nZXQodXJsLCBvcHRpb25zKTtcbiAgICAgIGxldCBuZXdEYXRhID0gSlNPTi5wYXJzZShkYXRhLmNvbnRlbnQpO1xuICAgICAgLy9jb25zb2xlLmxvZyhcIkRBVEFBQUEgIE5FV1wiLG5ld0RhdGEpXG4gICAgICAvL2NvbnNvbGUubG9nKFwiU0VOU09SU1wiLG5ld0RhdGEuc2Vuc29ycylcbiAgICAgIC8vY29uc29sZS5sb2coXCJUUkVFXCIsbmV3RGF0YS50cmVlc2l6ZSlcbiAgICAgIC8vY29uc29sZS5sb2coXCJQVUJMSVNIRUQgS0VZU1wiLHB1Ymxpc2hlZEtleXMpXG4gICAgICBuZXdEYXRhLnNlbnNvcnMubWFwKChkYXRhLHZhbHVlKSA9PiB7XG4gICAgICAgIGxldCBuZXdVcmkgPSBiYXNlVXJsK1wiL2NoYXJ0LnBuZz90eXBlPWdyYXBoJmdyYXBoaWQ9MCZ3aWR0aD05MjUmaGVpZ2h0PTMwMCZpZD1cIituZXdEYXRhLnNlbnNvcnNbdmFsdWVdLm9iamlkK3VDcmVkcztcbiAgICAgICAgbGV0IHRpbWVOb3cgPSBNYXRoLnJvdW5kKG5ldyBEYXRlKCkuZ2V0VGltZSgpIC8gMTAwMCk7XG4gICAgICAgIGxldCBkYXRlVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgIC8vY29uc29sZS5sb2cobmV3RGF0YS5zZW5zb3JzW3ZhbHVlXS5vYmppZClcbiAgICAgICAgLy9jb25zb2xlLmxvZyh0eXBlb2YobmV3RGF0YS5zZW5zb3JzW3ZhbHVlXS5vYmppZCkpXG4gICAgICAgIC8vY29uc29sZS5sb2coXCJEQVRBIElEIFwiLGRhdGEuX2lkKVxuICAgICAgICBkYXRhLmdyYXBoID0gbmV3VXJpO1xuICAgICAgICBJdGVtc1BydGcuaW5zZXJ0KHtcbiAgICAgICAgICAgIHBydGdEYXRhOiB7XG4gICAgICAgICAgICAgIGRhdGFPYmo6IGRhdGEsXG4gICAgICAgICAgICAgIHJlcXVlc3RUaW1lOiB0aW1lTm93LFxuICAgICAgICAgICAgICBkYXRlVGltZTogZGF0ZVRpbWVcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH07XG4gICAgcG9sbCgpO1xuICAgIC8vdGhpcy5yZWFkeSgpO1xuICAgIHJldHVybiBJdGVtc1BydGcuZmluZCh7fSx7c29ydDp7XCJwcnRnRGF0YS5kYXRhT2JqLmdyb3VwXCI6IDEsXCJwcnRnRGF0YS5kYXRhT2JqLmRldmljZVwiOiAxfX0pO1xuICB9IGVsc2Uge1xuICAgIGNvbnNvbGUubG9nKFwiSElUIENPTExFQ1RJT04gRVhJU1RTISEhXCIpXG4gICAgLy8gZ2V0cyB0aGUgY3VycmVudCB0aW1lIGVwb2NoXG4gICAgbGV0IGN1cnJlbnRUaW1lRXBvY2ggPSBNYXRoLnJvdW5kKG5ldyBEYXRlKCkuZ2V0VGltZSgpLzEwMDApO1xuICAgIC8vIHJldHVybnMgdGhlIG9sZGVzdCBEQiBpdGVtcyBlcG9jaCB0aW1lc3RhbXBcbiAgICBsZXQgb2xkZXN0RG9jdW1lbnQgPSBJdGVtc1BydGcuZmluZCh7fSx7c29ydDp7XCJwcnRnRGF0YS5yZXF1ZXN0VGltZVwiOiAtMX0sZmllbGRzOntcInBydGdEYXRhLnJlcXVlc3RUaW1lXCI6IDEsX2lkOjB9LGxpbWl0OjF9KS5mZXRjaCgpO1xuICAgIC8vIHNldHMgdmFyIHRvIGJlIG9ubHkgdGhlIGVwb2NoXG4gICAgbGV0IG9sZGVzdERvY3VtZW50RXBvY2ggPSBvbGRlc3REb2N1bWVudFswXS5wcnRnRGF0YS5yZXF1ZXN0VGltZTtcbiAgICBjb25zb2xlLmxvZyhcIkRvY3VtZW50IEVwb2NoXCIsb2xkZXN0RG9jdW1lbnRFcG9jaCxcIiA9PSBcIixcIkVsYXBzZWQgVGltZVwiLGN1cnJlbnRUaW1lRXBvY2ggLSBvbGRlc3REb2N1bWVudEVwb2NoKTtcbiAgICBpZihjdXJyZW50VGltZUVwb2NoIC0gb2xkZXN0RG9jdW1lbnRFcG9jaCA+IDM2MDApe1xuICAgICAgY29uc29sZS5sb2coXCJISVQgQ09MTEVDVElPTiBFWElTVFMhISEgQlVUIElTIE9MRCEhISFcIilcbiAgICAgIC8vIHJlbW92ZXMgb2xkIERCIGNvbGxlY3Rpb24gZG9jdW1lbnRzXG4gICAgICBJdGVtc1BydGcucmVtb3ZlKHtcInBydGdEYXRhLnJlcXVlc3RUaW1lXCI6IHtcIiRsdGVcIiA6IE1hdGgucm91bmQobmV3IERhdGUoKS5nZXRUaW1lKCkvMTAwMCAtIDMwKSB9fSlcbiAgICAgIGNvbnN0IHBvbGwgPSAoKSA9PiB7XG4gICAgICAgIC8vIExldCdzIGFzc3VtZSB0aGUgZGF0YSBjb21lcyBiYWNrIGFzIGFuIGFycmF5IG9mIEpTT04gZG9jdW1lbnRzLCB3aXRoIGFuIF9pZCBmaWVsZCwgZm9yIHNpbXBsaWNpdHlcbiAgICAgICAgY29uc3QgZGF0YSA9IEhUVFAuZ2V0KHVybCwgb3B0aW9ucyk7XG4gICAgICAgIGxldCBuZXdEYXRhID0gSlNPTi5wYXJzZShkYXRhLmNvbnRlbnQpO1xuICAgICAgICAvL2NvbnNvbGUubG9nKFwiREFUQUFBQSAgTkVXXCIsbmV3RGF0YSlcbiAgICAgICAgLy9jb25zb2xlLmxvZyhcIlNFTlNPUlNcIixuZXdEYXRhLnNlbnNvcnMpXG4gICAgICAgIC8vY29uc29sZS5sb2coXCJUUkVFXCIsbmV3RGF0YS50cmVlc2l6ZSlcbiAgICAgICAgLy9jb25zb2xlLmxvZyhcIlBVQkxJU0hFRCBLRVlTXCIscHVibGlzaGVkS2V5cylcbiAgICAgICAgbmV3RGF0YS5zZW5zb3JzLm1hcCgoZGF0YSx2YWx1ZSkgPT4ge1xuICAgICAgICAgIGxldCBuZXdVcmkgPSBiYXNlVXJsK1wiL2NoYXJ0LnBuZz90eXBlPWdyYXBoJmdyYXBoaWQ9MCZ3aWR0aD05MjUmaGVpZ2h0PTMwMCZpZD1cIituZXdEYXRhLnNlbnNvcnNbdmFsdWVdLm9iamlkK3VDcmVkcztcbiAgICAgICAgICBsZXQgdGltZU5vdyA9IE1hdGgucm91bmQobmV3IERhdGUoKS5nZXRUaW1lKCkgLyAxMDAwKTtcbiAgICAgICAgICBsZXQgZGF0ZVRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgIC8vY29uc29sZS5sb2cobmV3RGF0YS5zZW5zb3JzW3ZhbHVlXS5vYmppZClcbiAgICAgICAgICAvL2NvbnNvbGUubG9nKHR5cGVvZihuZXdEYXRhLnNlbnNvcnNbdmFsdWVdLm9iamlkKSlcbiAgICAgICAgICAvL2NvbnNvbGUubG9nKFwiREFUQSBJRCBcIixkYXRhLl9pZClcbiAgICAgICAgICBkYXRhLmdyYXBoID0gbmV3VXJpO1xuICAgICAgICAgIEl0ZW1zUHJ0Zy5pbnNlcnQoe1xuICAgICAgICAgICAgICBwcnRnRGF0YToge1xuICAgICAgICAgICAgICAgIGRhdGFPYmo6IGRhdGEsXG4gICAgICAgICAgICAgICAgcmVxdWVzdFRpbWU6IHRpbWVOb3csXG4gICAgICAgICAgICAgICAgZGF0ZVRpbWU6IGRhdGVUaW1lXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICAgIH07XG4gICAgICBwb2xsKCk7XG4gICAgICAvL3RoaXMucmVhZHkoKTtcbiAgICAgIHJldHVybiBJdGVtc1BydGcuZmluZCh7fSx7c29ydDp7XCJwcnRnRGF0YS5kYXRhT2JqLmdyb3VwXCI6IDEsXCJwcnRnRGF0YS5kYXRhT2JqLmRldmljZVwiOiAxfX0pO1xuICAgIH0gZWxzZSB7XG4gICAgICAvL3RoaXMucmVhZHkoKTtcbiAgICAgIHJldHVybiBJdGVtc1BydGcuZmluZCh7fSx7c29ydDp7XCJwcnRnRGF0YS5kYXRhT2JqLmdyb3VwXCI6IDEsXCJwcnRnRGF0YS5kYXRhT2JqLmRldmljZVwiOiAxfX0pO1xuICAgIH1cbiAgfVxufSk7XG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gIC8vIGNvZGUgdG8gcnVuIG9uIHNlcnZlciBhdCBzdGFydHVwXG59KTtcbiJdfQ==
